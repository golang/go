# Current LoGOs native CI evidence

The unit job passed in [run 43927955055](https://github.com/gosuda/LoGOs/actions/runs/43927955055) for PR head `bdc5987c526a9e9aa1b43975290f69a2370ae37a`. This records only the completed unit job; the separate scripts, upstream, and corpus gates were still pending or running when this evidence was collected.

GitHub checked out synthetic merge `df9692747da8b773c8714f5497a5d0f61f06e956`. Its full tree exactly matches the PR head: `b1eca92a0c54e14b8e37974c6516a882d13d1442`. Its native source subtree is `61483affd1671d27e29a1a1aadc5299ba675f789`. The Git commit, root tree, and empty head-to-merge file delta are retained in [checkout-identities.json](checkout-identities.json).

The successful steps include the fresh toolchain build, smoke checks, unit packages, compiler fixtures, formatting, vet, lint, race tests for ld/work/test, and generator/shape controls. Both negative controls produced their required named failures and then the restored candidate tests passed. The FAIL records inside the raw log belong to those intentional controls:

- Restored environment canonicalization failed `TestLogosTestExperimentEnv/default` and `TestLogosTestExperimentCache/logos`.
- An identity generator transformation failed `TestGenerate` with the expected `check.conf.Logos` difference.
- Fresh runs without the overlays then passed both affected packages.

[unit.raw.log](unit.raw.log) contains the complete connector-returned job log, [unit-job.json](unit-job.json) contains the exact API job record, and [unit.summary.json](unit.summary.json) records the installed tool hashes and acceptance scope. No source or repository file was changed during collection.
