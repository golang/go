# Completed upstream CI audit

Run [43927955055](https://github.com/gosuda/LoGOs/actions/runs/43927955055), job [133512372425](https://github.com/gosuda/LoGOs/actions/runs/43927955055/job/133512372425), completed with failure at 2026-11-16 19:51:25 UTC. It was allowed to finish; no cancellation, source edit, test edit, or timeout adjustment was made during this audit.

## Identity and raw evidence

The PR head was `bdc5987c526a9e9aa1b43975290f69a2370ae37a`, with tree `b1eca92a0c54e14b8e37974c6516a882d13d1442` and source tree `61483affd1671d27e29a1a1aadc5299ba675f789`. The job actually checked out GitHub's merge commit `df9692747da8b773c8714f5497a5d0f61f06e956`; the existing [checkout proof](checkout-identities.json) records that its full tree equals the PR head tree.

[upstream.raw.log](upstream.raw.log) preserves the returned job log exactly: 575,111 UTF-8 bytes, SHA-256 `4e32724648b62e16bd63d0cf76f3395d83fdffdead2eef2e7018ff14e782c733`. All 575,109 decoded characters were independently read back and compared with the API response. [Completed jobs](upstream-completed-jobs.json), [final workflow run](native-run-final.json), and [machine-readable analysis](upstream.summary.json) accompany it. Historical unit/scripts snapshots remain unchanged.

## Observed failures

Only two package result lines report failure:

| Package | Reported duration | Evidence |
| --- | ---: | --- |
| cmd/compile/internal/logos | 192.075 s | Three Wasm root tests fail at Node host startup |
| cmd/go | 542.698 s | Shared script context expires; 676 script failure lines |

The three Wasm roots are `TestWasmProgramRunsUnderNode` (both resume-point profiles), `TestWasmWrongMayYieldTraps` (the correct-facts baseline), and `TestWasmYieldFreeSourcesRunUnderNode` (both logos and plain_go). Every shown failure contains `Error: total length of command line and environment variables exceeds limit`, at `lib/wasm/wasm_exec.js:545`, before guest execution.

Of the 676 script failure lines, 673 explicitly say `context deadline exceeded`. The other three are `logos_std_stackbuf.txt:24` and `logos_simd_tail_once.txt:12`, with SIGQUIT stacks and exit status 2, and `logos_stackbuf_cgo_unsafe.txt:18`, with exit status 1 and no stderr at the same deadline. The last one remains unclassified beyond its timing. Many scripts failed at line zero after the shared context had expired. The first listed script's intended invalid-array/operator checks matched successfully before its following plain-Go build was interrupted. No failed semantic assertion preceding this cascade was found.

The Wasm package failure precedes the script cascade in the raw log. No other package result reports failure. The `-k` run continued through the final `cmd/internal/testdir` result (PASS, 524.140 s) to its failed overall result. Some gates have explicit prerequisite skips; this is not a claim that every possible test ran.

## Timeout: observed command versus source inference

The workflow echoes `./run.bash --no-rebuild -k`. It does not echo the full generated internal `go test` argv.

The exact-head [dist source](source/dist-test.go.txt) starts with short mode enabled (119–126) and timeout scale one (187–193). Its standard package batch begins with a three-minute timeout, but `cmd/cgo/internal/testshared` or `internal/godebugs` sets that value to zero (574–596). Both packages appear in the completed batch. `buildArgs` omits the timeout flag at zero timeout and default scale (427–437), so Go's default ten-minute package timeout applies. This is not a nine-minute go-test timeout.

The exact-head [script harness](source/script-test.go.txt), 67–90, reserves two cleanup grace periods, each five percent of the remaining deadline. That leaves approximately 540 seconds for its common script context and explains the observed 542.698-second package result. This source-derived reconstruction does not replace an observed full argv.

## Why the unit package PASS does not establish the same Wasm profile

The exact-head [workflow](source/logos-workflow.yml.txt), 75–92, installs Node 26.13.1 and the three oracle roots only outside the unit job. The unit job's package output is nonverbose, so it does not show individual Wasm runs or prerequisite skips. Its Node version and the exact inherited environment at the Wasm child were not recorded.

The [Wasm test helper](source/wasm-test.go.txt), 160–172, copies the command environment except six Go target/control variables. `runWasmNode`, 201–209, passes that resulting environment to Node. The Node host copies `process.env` into the guest. The shared runtime stages padded argument/environment strings and pointer entries in a fixed 8 KiB area before starting the guest. This is a guest staging bound, not the operating system's exec limit.

The upstream profile adds the oracle-root variables, a Node PATH entry, and the environment changes from [run.bash](source/run.bash.txt) and dist, including a repeated GOROOT/bin PATH prefix and the default GOTRACEBACK value. These known differences explain why the profiles are not equivalent. The existing logs do not identify the exact variable that crossed the boundary, and do not establish a Node 26 defect. There is no `testing.Short` branch in these Wasm tests.

## Review boundary

This audit changes evidence files only. It proposes no weakened assertion, changed timeout, or reduced test selection. Host/environment setup and scheduling require a separate reviewed change and a fresh hosted run.
