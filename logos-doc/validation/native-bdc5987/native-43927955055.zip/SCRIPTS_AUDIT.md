# Native script CI: exact failure and independent successes

The scripts job [133512372234](https://github.com/gosuda/LoGOs/actions/runs/43927955055/job/133512372234) completed with failure on PR71 head `bdc5987c526a9e9aa1b43975290f69a2370ae37a`. Its checkout and installed binary hashes match the unit job already recorded in this directory.

The broad script suite ran for 1265.083 seconds. Its only reported failed script was `TestScript/logos_cgo_shared`. The LoGOs c-shared build succeeded and produced both `liblogos.so` and `liblogos.h`. The subsequent external C consumer compile failed because the selected `cc` rejected `-std=c23`, suggesting `-std=c2x`. The fixture clears `CC`, finds the first available executable from `cc`, `gcc`, `clang`, and invokes that compiler with literal `-std=c23`. This failure therefore identifies a C compiler prerequisite introduced by the ubuntu24 resource-pool retry; it does not establish a LoGOs code-generation or runtime defect.

The following independent installed subprocess gate still ran and passed in 28.577 seconds:

```sh
go test -count=1 -race -parallel=1 -timeout 20m cmd/go -run 'Script/^logos_(cap_xtest_owner|test_experiment_env|test_plugin_experiment|test_cache_experiment)$'
```

This includes the unchanged inherited-environment cache fixture. The observed hashes were:

| Binary | SHA256 |
| --- | --- |
| go and logos | `28208831b0b9e37ff296118f2ea4d2666487d0af0154341e89002a190822a808` |
| compile | `a2b3a7f9353f5b0e2f7cfdd3007f85b1d5bd92ae3b74eb4dcc7a38f2dc73bb66` |
| link | `a3b952057f0b04b13d7af70aed216dc41c59fc1278f5418af4f99e17b5373ce1` |

Recommended workflow repair: supply and verify a C23-capable `cc` on PATH while preserving the frozen cgo script and its C/Python consumer assertions. Setting `CC` alone cannot affect this fixture because it clears the variable and selects `cc` itself. No workflow or test change was made during this audit.

- [Raw completed script log](scripts.raw.log), SHA256 `30e2474c946b239912926c1837a40b319f893d695c34dbb2888eb996f56b0584`
- [Completed script job snapshot](scripts-completed-jobs.json)
- [Unit and checkout proof](README.md)

The separate full upstream gate was still running at the last observation (2026-11-16 19:29:17 UTC). Its result is not claimed here.
