# Native upstream audit: run 43967559240

Upstream job `133650879399` completed with failure at `2026-11-16T22:59:51Z` for
head `f4242fed9cf0707a4103a0adbdb82e866bcabd69`. The only failed package was
`cmd/compile/internal/types2`, whose new zero-array test fixture called the
nonexistent `Interface.Complete` method twice. The independent full testdir and
cmd/go partitions both passed.

## Complete partition and results

The single unfiltered inventory contains 666 unique registered dist names. Its
SHA-256 is `5b4fb09e6d180e745995ec1d7ac4f614750b9633c996894acf07a59812dcdfd4`.
The three selected sets are pairwise disjoint and their union equals that exact
inventory. The inventory and executions use the same `run.bash` entry point and
compact environment wrapper.

| Partition | Registered names | Timeout scale | Driver exit | Console capture exit | Result |
| --- | ---: | ---: | ---: | ---: | --- |
| Complement | 664 | 1 | 1 | 0 | Failed only at the types2 fixture build |
| Full testdir, `cmd/internal/testdir:0_1` | 1 | 2 | 0 | 0 | Passed; package reported 465.806 seconds |
| `cmd/go` | 1 | 4 | 0 | 0 | Passed; package reported 1,141.122 seconds |

The exact filters are retained in the profile files and partition receipt:

```text
complement: !^(cmd/go|cmd/internal/testdir:(0|[1-9][0-9]*)_([1-9][0-9]*))$
testdir:    ^cmd/internal/testdir:(0|[1-9][0-9]*)_([1-9][0-9]*)$
cmd/go:     ^cmd/go$
```

The complement keeps the default timeout scale. The dedicated testdir profile
provides a 20-minute package timeout, and cmd/go provides 36 minutes. These are
bounded profiles for the isolated partitions; no fixture, assertion, or selected
dist name was removed. The counts above describe registered dist names, not
individual Go test identities.

## Retained failure

`complement.log` contains exactly the same fixture API errors seen in the unit
job, followed by `FAIL cmd/compile/internal/types2 [build failed]`:

```text
referencefree_zero_array_logos_test.go:19:44: NewInterfaceType(nil, nil).Complete undefined (type *Interface has no field or method Complete, but does have field complete)
referencefree_zero_array_logos_test.go:99:47: NewInterfaceType(nil, embeds).Complete undefined (type *Interface has no field or method Complete, but does have field complete)
```

No timeout or other failing package appears in the retained complement output.
The original failure remains a failure. The later API-only fixture correction
belongs to the separate corrected run and is not substituted into this evidence.

## Source and tool stability

The before/after source receipts are byte-identical and record:

- Head `f4242fed9cf0707a4103a0adbdb82e866bcabd69`.
- Source tree `ee5ae95824022485b74d4e3186a1540ef7124f76`.
- Test tree `a64f88184df739e681c29c83e059d44ab6fda7bd`.

Both source/test status captures are empty. All six installed executable hashes
(`go`, `logos`, `compile`, `link`, `asm`, and `cgo`) are identical before and after
all three partitions. Those exact hashes and the independent inventory proof
are recorded in [independent-upstream-audit.json](independent-upstream-audit.json).

The complete decoded [upstream.raw.log](upstream.raw.log) is 125,641 bytes with
SHA-256 `a8fb5571fe13d4cca119d620f4d4003ebdc95994478fb94ec801916bd8904eec`.
Original artifact `14279313631` is
[logos-upstream-43967559240-1.zip](logos-upstream-43967559240-1.zip), 24,676 bytes,
SHA-256 `86b27550079cb441c157bacb49cf75818ffcb836565292831ccf943ee08001d6`.
All extracted member hashes are retained in
[upstream-artifact-receipt.json](upstream-artifact-receipt.json).

No local Go execution or source edit was used to produce or package this audit.
