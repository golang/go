# Native script audit: run 43967559240

Scripts job `133650879963` completed successfully at candidate
`f4242fed9cf0707a4103a0adbdb82e866bcabd69`, source tree
`ee5ae95824022485b74d4e3186a1540ef7124f76`.

The full `Script/^logos_` command passed in 984.839 seconds. The separate installed
subprocess race command passed in 26.453 seconds. The raw log retains both exact
commands and their ordinary Go package results; these broad commands do not
provide a per-test JSON inventory.

## Strict inline-capability proof

The frozen inline-capability script has a separate exact JSON gate:

| Phase | Named runs | Named passes | Named failures | Exit |
| --- | ---: | ---: | ---: | ---: |
| Archived linker | 2 | 0 | 2 | 1 |
| Candidate linker | 2 | 2 | 0 | 0 |

The two identities are `TestScript` and
`TestScript/logos_cap_inline_context`. There are no skips, duplicate identities,
or build failures. Both stderr files are empty. The archived-linker failure
contains the required safe-dependency-to-`syscall.Socket` witness in the child
test's output. This script also retains the callback and directly inlined socket
denial controls in its frozen body.

The old installed linker hash is
`678df2fb08471d22501096beaed91e7f332e972f2118f760b368afca4bbed73d`.
It differs from the candidate and matches the during-negative receipt. All four
installed tool hashes were restored exactly before candidate acceptance. The
candidate hashes match the unit-job receipts in [UNIT_AUDIT.md](UNIT_AUDIT.md).
Source before/after receipts are identical, both diff files are empty, and the
runner finishes with `exit=0`, `phase=accepted`, `link_replaced=0`.

[independent-scripts-audit.json](independent-scripts-audit.json) records the
independently checked counters, package outcomes, witness, and restoration.

## Retained originals

- [scripts.raw.log](scripts.raw.log): complete decoded job log, 44,157 UTF-8 bytes,
  SHA256 `81971cbb791e792663ad2ac223ff75b41d3693d024cdab8d80e964b81312a828`.
  Every character was read back against the connector's complete result.
- [logos-scripts-43967559240-1.zip](logos-scripts-43967559240-1.zip): original
  artifact `14278775879`, 16,823 bytes,
  SHA256 `d5010dd41ea4ab7e3e4fe4e65104e6fcc5d4a933fb4335b22f26e67946dc856d`.
  The size and digest match GitHub's metadata. Every extracted file was read back
  and hashed in [scripts-artifact-receipt.json](scripts-artifact-receipt.json).

No running job was canceled and no source was changed during this audit.
