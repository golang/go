# Original native evidence bundle: run 43967559240

This bundle preserves the completed original native run at
`f4242fed9cf0707a4103a0adbdb82e866bcabd69`, root tree
`42454f406f1032e1b5c9265b97e4b430eb8c4a36`. Its final overall conclusion is
**failure**. The unit job and upstream complement failed because the newly added
zero-array classification fixture used two nonexistent compiler-internal
`Interface.Complete` calls. The original tests, errors, rejected reports, and
passing results are retained together.

## Final job outcomes

| Job | ID | Conclusion | Completion time, UTC |
| --- | --- | --- | --- |
| Unit | `133650880035` | Failure | 2026-11-16 22:29:58 |
| Scripts | `133650879963` | Success | 2026-11-16 22:32:42 |
| Upstream | `133650879399` | Failure | 2026-11-16 22:59:51 |

The unit helper audit accepts 16 of 18 phases. The old-type overlay and candidate
classification phases both fail to build, execute zero named tests, and remain
rejected. The other phases retain their exact positive or negative inventories,
including the accepted two-failure mutation control and 15 passing candidate
mutation-fact identities. See [UNIT_AUDIT.md](UNIT_AUDIT.md).

The complete LoGOs script subset and installed subprocess race command pass.
The inline-capability proof retains its exact two-name archived-linker failure
and two-name candidate success, with installed linker restoration checked.
See [SCRIPTS_AUDIT.md](SCRIPTS_AUDIT.md).

The upstream inventory has 666 unique dist names. Its complement selects 664,
full testdir selects one, and cmd/go selects one; the sets are disjoint and
complete. The complement fails only at the same fixture build. Testdir passes
in 465.806 seconds at scale 2, and cmd/go passes in 1,141.122 seconds at scale 4.
Source/test trees and all six installed executable hashes remain unchanged.
See [UPSTREAM_AUDIT.md](UPSTREAM_AUDIT.md).

The corrected candidate `6c53eb629a0f572db7ce157372005e0fa2089d1d`, run
`43972750963`, is separate. It was still ongoing when this bundle was prepared.
No completion claim or corrected output is substituted for this original run.

## Complete retained inputs

The payload contains all three complete raw job logs, final run/job/artifact API
metadata, earlier status captures, exact source/helper copies and their receipts,
the inventories frozen before result inspection, all three original artifact
ZIPs, every extracted artifact file, and all independent audit reports. No
original payload file is omitted.

| Original artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| `logos-unit-43967559240-1.zip` | 72,894 | `b38104026644aeba2d57b3bb531c17f0c6274a83ad17de6d4f69f3bb1d75b475` |
| `logos-scripts-43967559240-1.zip` | 16,823 | `d5010dd41ea4ab7e3e4fe4e65104e6fcc5d4a933fb4335b22f26e67946dc856d` |
| `logos-upstream-43967559240-1.zip` | 24,676 | `86b27550079cb441c157bacb49cf75818ffcb836565292831ccf943ee08001d6` |

## Verification and deterministic reproduction

`SHA256SUMS` lists every other payload file in sorted relative-path order.
`repack.py` rejects missing, additional, duplicate, escaping, symlinked, or
hash-mismatched inputs before writing an archive. From the extracted directory:

```sh
uv run --no-project python repack.py
uv run --no-project python repack.py --output ../native-43967559240-repacked.tar.gz
```

The archive has a single `native-43967559240/` path prefix. File order is sorted;
each regular file has mode 0644, uid/gid/mtime zero, and empty user/group names.
The PAX tar stream is wrapped in gzip with no filename and mtime zero. Original
ZIP contents and raw log bytes are preserved unchanged inside that normalized
container.

Every archive member and its normalized metadata are checked after creation.
A second independent repack is compared byte-for-byte with the first. The
outside-archive receipt records the final archive size and SHA-256, Python and
zlib versions, payload count, and verification results. The older native bundle
and all repository files remain untouched.
