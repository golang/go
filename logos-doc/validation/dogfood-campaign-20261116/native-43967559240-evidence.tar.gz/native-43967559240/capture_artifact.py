# pyright: strict
"""Retain and verify an original ZIP returned by the GitHub artifact connector."""

from __future__ import annotations

import argparse
import hashlib
import json
import stat
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath


class Arguments(argparse.Namespace):
    artifact_id: int
    name: str
    group: str
    sha256: str
    size: int
    download_url: str


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifact-id", type=int, required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument(
        "--group", choices=("unit", "scripts", "upstream"), required=True
    )
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--size", type=int, required=True)
    parser.add_argument("--download-url", required=True)
    args = parser.parse_args(namespace=Arguments())
    base = Path(__file__).resolve().parent
    if Path(args.name).name != args.name:
        raise ValueError("artifact name must be a basename")
    with urllib.request.urlopen(args.download_url, timeout=60) as response:
        payload: bytes = response.read(20_000_001)
    digest = hashlib.sha256(payload).hexdigest()
    if len(payload) > 20_000_000 or len(payload) != args.size or digest != args.sha256:
        raise ValueError("download does not match the GitHub artifact size and digest")
    archive = base / args.name
    with archive.open("xb") as stream:
        stream.write(payload)
    output = base / f"{args.group}-artifact"
    output.mkdir(exist_ok=False)
    entries: list[dict[str, str | int]] = []
    with zipfile.ZipFile(archive) as bundle:
        infos = bundle.infolist()
        if len(infos) > 1000 or sum(item.file_size for item in infos) > 100_000_000:
            raise ValueError("unexpected ZIP expansion")
        seen: set[str] = set()
        for item in infos:
            name = PurePosixPath(item.filename)
            if (
                name.is_absolute()
                or ".." in name.parts
                or item.filename in seen
                or stat.S_ISLNK(item.external_attr >> 16)
            ):
                raise ValueError("unsafe or duplicate ZIP entry")
            seen.add(item.filename)
            target = output.joinpath(*name.parts)
            if item.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            content = bundle.read(item)
            with target.open("xb") as stream:
                stream.write(content)
            if target.read_bytes() != content:
                raise ValueError("extracted file readback mismatch")
            entries.append(
                {
                    "path": item.filename,
                    "bytes": len(content),
                    "sha256": hashlib.sha256(content).hexdigest(),
                }
            )
    record: dict[str, object] = {
        "artifact_id": args.artifact_id,
        "name": args.name,
        "run_id": 43967559240,
        "head": "f4242fed9cf0707a4103a0adbdb82e866bcabd69",
        "bytes": len(payload),
        "sha256": digest,
        "matches_github_digest": True,
        "entries": entries,
    }
    with (base / f"{args.group}-artifact-receipt.json").open("x") as stream:
        stream.write(json.dumps(record, indent=2) + "\n")
    print(json.dumps({key: value for key, value in record.items() if key != "entries"}))


if __name__ == "__main__":
    main()
