# Native unit audit: run 43967559240

The unit job failed because the new zero-array classification fixture does not
compile. Every other applicable unit-job check passed. The failed classification
phases did not execute any named test; they are not valid regression evidence.

## Exact candidate and capture

- Head: `f4242fed9cf0707a4103a0adbdb82e866bcabd69`.
- Root tree: `42454f406f1032e1b5c9265b97e4b430eb8c4a36`.
- Source tree: `ee5ae95824022485b74d4e3186a1540ef7124f76`.
- Unit job: `133650880035`, completed with failure at `2026-11-16T22:29:58Z`.
- Complete decoded job log: [unit.raw.log](unit.raw.log), 120,145 UTF-8 bytes,
  SHA256 `066e07b5802c678901f8e6d70edc1389577afad80ffefde274ee75c5aad4831e`.
  Every character was read back and compared with the complete connector result.
- Original artifact: `14276199722`,
  [logos-unit-43967559240-1.zip](logos-unit-43967559240-1.zip), 72,894 bytes,
  SHA256 `b38104026644aeba2d57b3bb531c17f0c6274a83ad17de6d4f69f3bb1d75b475`.
  This matches GitHub's artifact digest. All 90 extracted files were read back;
  their hashes are in [unit-artifact-receipt.json](unit-artifact-receipt.json).

## Concrete failure

Both `old-type-proof.jsonl` and `types.jsonl` contain these compiler errors:

```text
referencefree_zero_array_logos_test.go:19:44: NewInterfaceType(nil, nil).Complete undefined (type *Interface has no field or method Complete, but does have field complete)
referencefree_zero_array_logos_test.go:99:47: NewInterfaceType(nil, embeds).Complete undefined (type *Interface has no field or method Complete, but does have field complete)
```

The fixture used the public `go/types` completion API in compiler `types2`.
`types2.NewInterfaceType` already returns the complete empty interface or sets
`complete = true` before returning a nonempty interface. Type-set computation
remains lazy. Removing the two nonexistent method calls is the source-supported
fixture correction; no expected value, test identity, assertion, or production
expression needs changing. That correction is a separate candidate and is not
treated as executed in this run.

The helper correctly rejected both package build failures. The old mutation-fact
overlay still produced its required named failure, and the candidate's 15 named
mutation-fact tests all passed. This validates that narrower proof, while the 67
classification identities remain unexecuted in this candidate.

Exact failed evidence is under
[unit-artifact/logos-regression-evidence/zero-array](unit-artifact/logos-regression-evidence/zero-array).
The original report remains `accepted: false`, `complete: true`.

## Independently counted regression events

Counts below are named run/result identities, including parent tests. For a
negative control, the required failure is the successful proof outcome. Every
accepted phase has exact counters, its expected package result and exit status,
empty stderr, matching captured hashes, and no skipped or duplicated identity.

| Group and phase | Expected names | Runs | Passes | Failures | Proof result |
| --- | ---: | ---: | ---: | ---: | --- |
| Tagged method: old codec | 2 | 2 | 0 | 2 | Accepted negative |
| Tagged method: old package guard | 1 | 1 | 0 | 1 | Accepted negative |
| Tagged method: facts | 72 | 72 | 72 | 0 | Passed |
| Tagged method: compiler | 17 | 17 | 17 | 0 | Passed |
| Tagged package: old predicate | 2 | 2 | 0 | 2 | Accepted negative |
| Tagged package: candidate | 150 | 150 | 150 | 0 | Passed |
| Wasm runtime | 7 | 7 | 7 | 0 | Passed |
| Field offset: old rule | 2 | 2 | 0 | 2 | Accepted negative |
| Field offset: candidate | 50 | 50 | 50 | 0 | Passed |
| SIMD imports: old import configuration | 2 | 2 | 0 | 2 | Accepted negative |
| SIMD imports: old rewriter | 2 | 2 | 0 | 2 | Accepted negative |
| SIMD imports: work, with race detector | 11 | 11 | 11 | 0 | Passed |
| SIMD imports: midway | 7 | 7 | 7 | 0 | Passed |
| SIMD imports: compiler | 19 | 19 | 19 | 0 | Passed |
| Zero array: old type predicate | 3 | 0 | 0 | 0 | Build failure; rejected |
| Zero array: old mutation predicate | 2 | 2 | 0 | 2 | Accepted negative |
| Zero array: type classifications | 67 | 0 | 0 | 0 | Build failure; rejected |
| Zero array: candidate facts | 15 | 15 | 15 | 0 | Passed |

The pre-result inventories are retained in
[expected-new-slice-inventories.json](expected-new-slice-inventories.json) and
[expected-existing-inventories.json](expected-existing-inventories.json).
[independent-unit-audit.json](independent-unit-audit.json) records every counter
and reproduces all 18 helper acceptance decisions, including the two rejections.

## Other completed checks

The broad unit command, LoGOs/LSP race command, runtime metrics, arena/region/GC
tests, formatting, vet, and lint passed. The compiler-fixture invocation passed
in 353.714 seconds. The separate linker/work/test race gate and Go type generator
gate passed. Seven Python helper invocations passed 411 cases in total.

The environment and generator mutation step intentionally records `FAIL` output
from the two old implementations, verifies those specific failures, and then
passes the restored candidates. Those lines are expected negative evidence.
They are distinct from the zero-array fixture build failure that failed the job.

## Source and installed tools

All six helper groups' before/after identity receipts are identical, at the head,
root tree, and source tree above. Every new frozen input and observed file hash
matches the inventory saved before examining the run results. The helper and
workflow bytes used for that inventory match their published Git blobs in
[source-receipt.json](source-receipt.json).

| Installed file | SHA256 |
| --- | --- |
| `bin/go` and `bin/logos` | `3191301308102ad4dd2ca9d6c51551f3acea9cb4f1dde3964eef9b359daeea20` |
| `pkg/tool/linux_amd64/compile` | `5a3d240773d4fbdc77ed5c7327a169c44edbaa7df7e4e9e70d68b04eaf6550ed` |
| `pkg/tool/linux_amd64/link` | `acfd602e8bb3a5e5472067fa8c3805d5a7c6b3ab27a9e94f41e68d01d2c8b6bf` |

No local Go execution, branch update, source edit, or test-oracle change was used
to produce this audit.
