# Corpus run 43950476822: completed with one acceptance blocker

The [hosted corpus run](https://github.com/gosuda/LoGOs/actions/runs/43950476822)
completed all 196 corpus cells and all separate runtime controls. The corpus
acceptor rejected one unexpected cell: `tools/logos`. That build used the original
strict capability policy and reported unauthorized network and process paths.
The run does not establish a fully accepted corpus. The proposed
`policies/tools-build.toml` remains provisional until its own hosted build passes.

## Identity and integrity

| Item | Recorded identity |
| --- | --- |
| Run / job / attempt | `43950476822` / `133591313740` / `1` |
| Corpus head | `7d5446cca8e5b65800732c27bee2354ce8ad1461` |
| Native source tree | `df267333b1d5c5727e2477215a6807cae52f8e18` |
| Final artifact | `dogfood-43950476822-1`, ID `14272668107` |
| Final ZIP | 1,781,426 bytes; SHA-256 `1208291b9243c65cf2ef4625ddf105fe5b2ec49a5fd03cb8cbe2dba7a0f2aafc` |
| Early artifact | `tools-probe-43950476822-1`, ID `14271570518` |
| Early ZIP | 18,926 bytes; SHA-256 `f28b83d3d7b7a57a1fa84f945bb0a0aaf451841bc596f1aeac5d935e019cc89b` |
| Native go and logos | SHA-256 `55e6db54867b99b19f6e6f820e872e6339c29b2835bb7ff500dcb42bf9b95d4f` |
| Native compiler | SHA-256 `0d4d73bf90c0db65971ad63c7dd6b3518a6b3a062d9f4d6735d652bc3efde9f4` |
| Native linker | SHA-256 `5175844b844d061ab94197916f4963803e1d369fc7b52baea86d06c602cefbfa` |
| Stock Go driver | SHA-256 `de0ae3e082ce7599eae4fb69fa2ef1e43b8f31ffd3fce62cdf81930aa9005050` |
| gglint source | `a95099aae13ff7ffb4b3825bd63f8510bd184c69` |
| gglint executable | SHA-256 `3adff5060505683489f771dd0a43a75fa28ff0ed5b36a40c4716659088d96c39` |

The original final ZIP is preserved. Its 1,133 entries were checked for unsafe
paths, duplicate paths, and symlinks before extraction. The seven completed
reports reference 764 distinct stdout/stderr files; every recorded hash matches
the extracted bytes. `RECORDED_LOGS.sha256` lists them. `FINAL_AUDIT.json` records
the report hashes, exact runtime profiles, commands, and event counts. Raw JSON
streams were parsed again without executing Go, and their event sets match the
runtime reports. Native before/after receipts in the backend report agree.

## Corpus result

The 28 inputs each have seven recorded cells. The status counts are 80 `pass`,
10 `clean`, 98 `findings`, one `candidate-failed`, four `load-failed`, two
`uncompared`, and one `upstream-failed`. Findings are retained diagnostics, not a
claim that all packages are clean.

Seven nonpositive cells belong to the declared `decorder` baseline control.
Its pinned dependency `golang.org/x/tools@v0.20.0` fails stock Go 1.27.4 with
`invalid array length -delta * delta (constant -256 of type int64)` in
`internal/tokeninternal/tokeninternal.go:64`. Candidate compilation is therefore
uncompared and lint loading fails. These cells are not successful analysis.

The only other nonpositive cell is `tools/logos`. The full runner exited 1, its
console capture exited 0, and the unchanged acceptor rejected that exact cell.
The stock and fork Go builds of the same tools source passed.

## Runtime controls

All counts below apply independently to stock Go, fork Go, and LoGOs. Every
listed backend has identical run/pass event multisets across those drivers,
zero test-level skips, and zero test failures.

| Profile | Named run/pass events per driver | Required evidence |
| --- | ---: | --- |
| xxhash assembly core | 159 | `TestAll` and the unchanged root package suite |
| xxhash purego core | 159 | Same source, explicit `purego` tag |
| xxhash cgo/plugin | 223 | Includes `dynamic/TestDynamic` |
| SQLite with cgo | 3 | `TestOpen`, `TestClose`, `TestInsert` |
| modernc SQLite | 15 | Seven selected top-level tests and eight exact subtests |
| purego FFI | 8 | The frozen eight named FFI tests, no skips |

The plugin comparison uses inherited `GOEXPERIMENT=none` for all three drivers,
LoGOs `-O=1`, and the separately pinned `[build] arena = false` configuration only
in the LoGOs private copy. It does not establish compatibility between
unconfigured mixed-driver defaults. The plugin configuration hash is
`2ae10a1fe10a8e72ac145fc13e7692747bd06c626ec91a403e9c19d4a4a30e21`.

The modernc runtime comparison uses its separately reviewed LoGOs permission
profile; stock and fork copies remain pristine. Semantic and C ABI fixtures pass
six driver cells. LoGo native execution, ejection, and stock-Go execution of the
ejected result pass. Native lint matches the exact expected diagnostics on both
runs; its two named runtime controls pass under all three drivers. These runtime
results are separate from the compile/lint matrix.

## Strict tools evidence and proposed next profile

The tools source is `golang.org/x/tools@v0.52.0`, revision
`16517d951552611e7bd358c48ee1051fd0e57b0c`, module sum
`h1:ryxg4U63oaUYk7uOLTF37n43f4qgtGvqV4Ioit1BaEs=`. The original policy hash is
`005ba0707611025ef364004190601f0f103ab28ab97da9a6acd81e034d7f4d3f`.
Both early and full strict captures contain the same 42-error multiset: 36
network and six process errors. Both are truncated by the linker error limit.
The full stderr hash is
`3b68bf4fd24eabb13c008f8c7daafbd33c9f69d2808de296dc4053c27091af94`;
the early stderr hash is
`f17aa775d75242f461630680225642406030f3c81bbfec436b0609164ada4073`.

The old capture from run 43928753813 had 44 errors. Four errgroup network errors
are absent from the fresh capture; one telemetry network and one configstore
process error are newly visible. Error limits prevent an exhaustive comparison.
The old impossible shared-inline path and the new source-backed paths remain
separate evidence. No errgroup grant is proposed.

The reviewed provisional build profile preserves the three original unsafe
grants and adds process permission for two exact telemetry packages plus network
permission for 14 exact packages. Some paths use the conservative interface and
reflection edges required by SPEC 11.1. The permission proposal records those
paths explicitly; it does not claim that compilation executed them. It changes
neither the capability analyzer nor upstream sources. Its SHA-256 is
`c57b54d9a78993eac2b2614730cfdf05b12e47c1dbbc77c243f16887d67d7def`.

The next replay must retain the original strict probe and add the separate
`logos build -ldflags=-e ./...` diagnostic capture. Any additional package exposed
by the unlimited trace requires its own path/source review. The complete corpus
acceptor and runtime assertions stay unchanged. No local Go command was run for
this audit, and these results belong only to the source and binaries recorded
above; they are not evidence for later native source revisions.
