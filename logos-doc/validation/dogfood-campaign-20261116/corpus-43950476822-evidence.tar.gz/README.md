# Historical corpus evidence and the next strict diagnostic gate

This bundle preserves completed hosted run 43950476822 at source
`df267333b1d5c5727e2477215a6807cae52f8e18`, head
`7d5446cca8e5b65800732c27bee2354ce8ad1461`. Read `audit/FINAL_AUDIT.md` first.
The full 196-cell corpus remains rejected only at tools/logos. All separately
recorded runtime controls passed. The original failed reports and raw streams
are retained inside the original, checksum-verified artifact ZIPs.

The reviewed tools build profile is provisional until a hosted build using it
passes. It does not replace the original strict policy. The next unlimited
strict probe has Python-only validation here; it has not run the native build.
No local Go command was executed for the audit or helper verification.

The helper source snapshot is local commit
`3b67ee8e2e56baf7a5c3cbde3bfc2d9b697ae7f5`. Its sequence is the separate reviewed
profile `837978b`, frozen tests c074901, malformed-status freeze e7c37ce, and
implementation `3b67ee8`. The source tree remains df267333. Parent integration may
assign new Git commit identities; compare the file hashes in MANIFEST.json.

`helper/proof/before-helper.log` records an absent new Python module at the
initial test freeze. It is not native regression evidence. The malformed-status
log is an observed Python RED with eight failed cases. The final contract suite
passes 241 tests plus 27 subtests; 74 cases belong to the new helper. Two retained
mutants fail their named tests. Strict Pyright, Ruff, formatting, and actionlint
with ShellCheck pass. Full details and log hashes are in VERIFICATION.json.

MANIFEST.json binds every other entry by SHA-256 and byte count. The outer tar
uses sorted regular-file entries, fixed uid/gid/mode, and zero timestamps; gzip
also has a zero timestamp and no stored filename. The adjacent receipt binds the
compressed archive. Neither caches, work copies, repositories, nor executables
are included. Source inputs and logs retain their original recorded paths.
