# Tools capability profile proposal

Status: source-reviewed proposal, not installed in the repository and not accepted by a successful build. No local Go command ran for this review.

## Observed result and identity

Hosted run `43950476822`, attempt 1, uses head `7d5446cca8e5b65800732c27bee2354ce8ad1461`; its reviewed `src` tree is `df267333b1d5c5727e2477215a6807cae52f8e18`. Artifact `14271570518` is preserved as `tools-probe-43950476822-1.zip`. The ZIP is 18,926 bytes and matches the API digest `f28b83d3d7b7a57a1fa84f945bb0a0aaf451841bc596f1aeac5d935e019cc89b`. Member paths and types were checked before extraction.

The early artifact contains a completed three-stage build probe. Stock Go passes in 27.259 seconds; the fork Go driver passes in 28.552 seconds; LoGOs exits 1 in 35.218 seconds. None timed out. This is compile/link evidence; the probe does not execute the packages' tests or reported call paths. The full 196-cell replay is separate and remains in progress.

All 20 stdout/stderr hashes recorded by the probe were checked against the downloaded files. The runner remains `c2f2d0635450cc854c4fc7b4cf4a813d0b2e11a355bc960899bb85618efe9929`. Both candidate drivers are `55e6db54867b99b19f6e6f820e872e6339c29b2835bb7ff500dcb42bf9b95d4f`; stock Go is `de0ae3e082ce7599eae4fb69fa2ef1e43b8f31ffd3fce62cdf81930aa9005050`.

The input remains `golang.org/x/tools@v0.52.0`, revision `16517d951552611e7bd358c48ee1051fd0e57b0c`, module sum `h1:ryxg4U63oaUYk7uOLTF37n43f4qgtGvqV4Ioit1BaEs=`. The original policy remains SHA-256 `005ba0707611025ef364004190601f0f103ab28ab97da9a6acd81e034d7f4d3f`. Its saved bytes match both the preserved first failure and the current repository policy. The LoGOs effective source digest remains `h1:t4DoHbhx0AwhPW26pHg34MLv7v7rI03D4g+5MXGzVlU=`. The local module sources used below were rehashed against the pinned sums, including x/net, x/sync, telemetry, and Goldmark.

The report's nested `versions.*.toolchain` receipts record both candidate identities at source revision `7d5446cca8e5b65800732c27bee2354ce8ad1461`, with clean source status and compiler-source digest `h1:bDC+JKZq1e1qN0Nzt1bbXHWfnCZTQJW34zhsqgVQf5k=`. Their compiler SHA-256 is `0d4d73bf90c0db65971ad63c7dd6b3518a6b3a062d9f4d6735d652bc3efde9f4`; linker SHA-256 is `5175844b844d061ab94197916f4963803e1d369fc7b52baea86d06c602cefbfa`. The standalone source/tool text receipts are absent from the early ZIP, but these nested receipts already provide their required identities. This corrects the earlier draft's mistaken statement that compiler/linker identity had to wait for the final artifact.

## Change from the preserved failure

The old stderr contains 44 capability errors. The fresh stderr, SHA-256 `f17aa775d75242f461630680225642406030f3c81bbfec436b0609164ada4073`, contains 42: 36 network and six process errors. The four previously reported errgroup network errors are absent from this capture. Two additional diagnostics are visible: telemetry reaching syscall.Connect and configstore reaching syscall.StartProcess. Four errgroup reflection warnings remain, all through SetLimit; this proposal grants errgroup no capability.

The count is not a completeness argument. Both runs stop some links at the error limit. In this run, cmd/deadcode and cmd/present each emit 21 errors followed by `link: too many errors`. `diagnostic-comparison.json` preserves the multiset difference; `new-capability-paths.json` preserves every captured chain and source line.

## Why these permissions are supported

[SPEC 11.1](https://github.com/gosuda/LoGOs/blob/7d5446cca8e5b65800732c27bee2354ce8ad1461/logos-doc/SPEC.md#L1699) requires synthetic edges for interface calls and reflective method lookup. The visible residual network paths traverse those conservative edges. They do not establish that the concrete values in this application perform network operations. The proposal accepts the existing analysis contract and names only the observed packages.

| Exact package or group | Captured source path | Reason for the proposed grant |
| --- | --- | --- |
| `golang.org/x/telemetry` | `start.go:178`, with `exec.Command` at 189 and `cmd.Start` at 236 | Direct process creation supports exec. Its captured net chain goes through Cmd.Start failure cleanup, `closeDescriptors([]io.Closer)`, and an HTTP Close implementation. |
| `golang.org/x/telemetry/internal/configstore` | `download.go:46`, `exec.Command("go", "mod", "download", ...)` at 54, `cmd.Run` at 59 | Direct process creation supports exec. Its captured net chain goes through Cmd.Wait and the same io.Closer fanout. |
| `golang.org/x/telemetry/internal/counter` | `counter.go:26` debugPrintf calls `fmt.Fprintf(os.Stderr, ...)` | Captured io.Writer fanout reaches TLS Write and connection cleanup. This is a conservative path, not proof of network use by its concrete stderr. |
| `golang.org/x/telemetry/internal/crashmonitor` | `monitor.go:36` Child calls `io.ReadAll(os.Stdin)` | Captured io.Reader fanout reaches TLS Read and connection cleanup. |
| `golang.org/x/telemetry/internal/mmap` | `mmap_unix.go:16` mmapFile calls File.Stat | Captured File.wrapErr error-method fanout reaches UnmarshalTypeError.Error, reflect.Type.String, Scope.String, and fmt.Fprintf. |
| `golang.org/x/telemetry/internal/telemetry` | `dir.go:124` Dir.Mode calls os.ReadFile | Captured file/error/String/Writer path reaches the same conservative network branch. |
| `golang.org/x/telemetry/internal/upload` | package initialization calls regexp.MustCompile | Captured error/String/Writer fanout reaches network sinks. The package also directly uses http.Post in `upload.go:93`; that direct use is separate source evidence, not the shortest captured chain. |
| `github.com/yuin/goldmark/ast` | `ast/block.go:473` HTMLBlock.Dump calls fmt.Printf | Captured Fprintf io.Writer fanout reaches an HTTP chunk writer and connection cleanup. |
| `github.com/yuin/goldmark/parser`, `github.com/yuin/goldmark/util` | package initialization calls regexp.MustCompile | Captured Error/String/Fprintf fanout reaches the same HTTP path. |
| `github.com/yuin/goldmark/renderer` | `renderer/renderer.go:135` Render flushes its writer | Captured bufio.Writer.Flush io.Writer fanout reaches an HTTP chunk writer. |
| `github.com/yuin/goldmark/renderer/html` | `renderer/html/html.go:447` renderAutoLink writes through its writer interface | Captured io.Writer fanout reaches an HTTP chunk writer. |
| `github.com/yuin/goldmark/text` | `text/reader.go:528` matchReader calls FindReaderSubmatchIndex | Captured RuneReader/Reader and HTTP reader/writer fanout reaches network sinks. |
| `golang.org/x/net/websocket` | `websocket.go:221` Conn.Write uses a payload writer and closes it | Captured Close fanout reaches an HTTP client connection. The package also owns real websocket connection I/O and DialContext in `dial.go:13`; no wildcard module grant is needed. |

The standard-library boundaries were checked in the reviewed native source: Fprintf invokes `io.Writer.Write` (`src/fmt/print.go:214`); closeDescriptors invokes `io.Closer.Close` (`src/os/exec/exec.go:620`); Cmd.Start and Wait call it at 662/666 and 968. File.wrapErr's Error call is guarded by a mutable test-hook variable, not a compile-time constant. UnmarshalTypeError.Error invokes `reflect.Type.String`, and Scope.String invokes Fprintf. These support the conservative paths without reintroducing the repaired shared inline-owner node.

## Concrete integration proposal

1. Install the proposed TOML as `misc/logos-dogfood/policies/tools-build.toml`. Keep all three original unsafe grants and add only the two exact exec packages and 14 exact net packages shown in that file. Do not change severity defaults or add a wildcard.
2. Change only the tools row's policy path and digest in `corpus-ci.json`. Keep its other source/profile fields, the runner, and the acceptor unchanged.
3. Keep `policies/tools.toml` byte-identical. Point the retained strict early probe at `corpus-permissions.json`, whose tools row exactly matches the original strict row. `corpus.json` omits the three unsafe grants and would be a different probe.
4. Capture a separately recorded `logos build -ldflags=-e ./...` under the original strict policy and the same frozen source/resource inputs. It removes diagnostic truncation only. Preserve its command, status, raw streams, source/policy hashes, and installed tool hashes. Require each additional owner to undergo the same source review; do not call the currently proposed list exhaustive.
5. Require the unchanged positive build acceptance and runtime/matrix gates on the new profile. Record the unlimited probe's source and executable identities before and after its command in its own uploaded report.

The proposal has not changed the repository or the running workflow. The original failed witness remains available alongside this fresh strict failure.
