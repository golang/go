# Accepted corpus run 43967842639

The complete hosted corpus job succeeded on head
`3b2073eb98e488c411f52ba7cd723e8622c8cdfe`, native source tree
`ee5ae95824022485b74d4e3186a1540ef7124f76`. Its 196 primary cells satisfy the
unchanged acceptance contract: 189 successful build or valid lint cells across
27 positive cases, plus seven explicitly declared failed-load controls for
decorder. Every separate runtime step also succeeded.

These results apply to that exact revision. The later corrected corpus head
`090bac0f2dbb1a1105d4bcb156fc31ed7c025177` has a separate run and separate
evidence. Its fixture API correction does not retroactively change this run.

## Corpus coverage and outcomes

The frozen manifest has 28 profiles from 26 distinct pinned inputs: 24 real
sources and two local fixtures. It covers GitHub, GitLab, Codeberg, SourceHut,
and Googlesource. The curated profile labels are seven popular, 11 reference,
and ten stress cases; they are selection labels, not an objective quality
ranking of entire projects.

The profiles cover Go-only code, assembly, the `purego` build tag, purego FFI,
cgo, modernc, a cgo-disabled stub, and generated Go. The matrix compiles each
input with stock Go, the plain fork, and LoGOs, then runs native lint and
gglint's basic, standard, and strict modes. It repeats every successful lint
cell once, producing 108 repeat checks.

| Assessment | Primary cells |
| --- | ---: |
| Successful build | 81 |
| Valid lint report with findings | 98 |
| Valid clean lint report | 10 |
| Declared upstream compilation failure | 1 |
| Candidate build without a successful upstream baseline | 2 |
| Declared lint loading failure | 4 |
| Total | 196 |

The seven incomplete cells all belong to decorder. Its pinned dependency
`golang.org/x/tools@v0.20.0/internal/tokeninternal/tokeninternal.go:64:9` fails
with `invalid array length -delta * delta (constant -256 of type int64)`.
That input remains an explicit upstream incompatibility control. It is not
counted as successfully analyzed code.

The full report hash is
`c036d83f18488cbf5ede30eb3104440b37a6dcd5e53fe336866207b5debddf82`.
The acceptance result binds that hash and the unchanged checker hash
`56146fab4da8433c4607381190ecc502493092bb4be645d2c2480bb41d387396`.

## Actual backend execution

The independent audit parsed the raw JSON test streams. Every row below has
the same nonempty package-qualified run/pass multiset across all three
drivers, with no failed or skipped named test. SQLite also matches exact
expected test names and packages; counts alone do not establish acceptance.

| Runtime profile | Stock Go | Plain fork | LoGOs |
| --- | ---: | ---: | ---: |
| xxhash assembly core | 159 | 159 | 159 |
| xxhash purego-tag core | 159 | 159 | 159 |
| xxhash cgo plugin | 223 | 223 | 223 |
| mattn SQLite cgo | 3 | 3 | 3 |
| modernc SQLite | 15 | 15 | 15 |
| purego FFI | 8 | 8 | 8 |

Counts are observed named test runs and passes, including subtests, within
each invocation. They are not counts of distinct tests across the entire
table.

The xxhash plugin profile includes `dynamic/TestDynamic`. All three drivers
inherit explicit `GOEXPERIMENT=none`; the LoGOs host uses `-O=1` and its own
private `[build] arena = false` configuration. The configuration SHA256 is
`2ae10a1fe10a8e72ac145fc13e7692747bd06c626ec91a403e9c19d4a4a30e21`.
The oracle and plain fork copies remain pristine. This validates the stated
compatible profile; it does not claim that unconfigured driver defaults can
interchange plugin objects.

The cgo SQLite tests are `TestOpen`, `TestClose`, and `TestInsert`. Modernc runs
seven named roots: `TestNamedParameters`, `TestMemDB`, `TestBinding`,
`TestBeginMode`, `TestMultiStmtQueryStringRoundtrip`,
`TestExecReturningMultiRow`, and `TestMutexWakeOnce`. Its remaining eight
events are `TestBinding/DB`, `TestBinding/Prepare`, and the deferred, immediate,
and exclusive modes under both delete and wal journals. Only the LoGOs copy
receives the reviewed runtime capability policy, SHA256
`5666c90bc1f25d5f0d7d0e5b53e80c2fa8e7ebe341286f7d7b0b1c5651513096`.

The eight observed purego FFI tests are `TestCallGoFromSharedLib`,
`TestNestedDlopenCall`, `TestNewCallbackFloat64AndIntMix`,
`TestNewCallbackInt64ResultWithStackArgs`, `TestRegisterFunc_StackAlignment`,
`TestRegisterFunc_StackCallback`, `TestSimpleDlsym`, and `TestSyscallN`.

## Semantic fixtures, language parity, and native lint

The semantic and C ABI fixtures have six successful package-level driver
cells. Each exact invocation is:

```text
<recorded driver> test -count=1 -short -timeout=595s ./...
```

The drivers are the distinct stock Go executable, the plain fork executable,
and the LoGOs executable. All six stderr streams are empty. The raw stdout
lines are:

| Fixture / driver | Raw package result |
| --- | --- |
| Semantics / stock | `ok  \texample.com/logos-dogfood/semantics\t0.003s` |
| Semantics / fork | `ok  \texample.com/logos-dogfood/semantics\t0.002s` |
| Semantics / LoGOs | `ok  \texample.com/logos-dogfood/semantics\t0.002s` |
| C ABI / stock | `ok  \texample.com/logos-dogfood/cgo\t0.002s` |
| C ABI / fork | `ok  \texample.com/logos-dogfood/cgo\t0.002s` |
| C ABI / LoGOs | `ok  \texample.com/logos-dogfood/cgo\t0.002s` |

The table escapes tabs for readability; `FINAL_AUDIT.json` retains the exact
command arrays and raw strings, including their final newline. These commands
did not use `-json` or `-v`, so the logs contain no observed per-test events.
The independently rehashed fixture source defines seven semantic roots and
one C ABI root. That static inventory is recorded separately and is not added
to the observed named-event totals above.

The LoGo program, its successful ejection, and the stock-Go execution of the
ejected program all passed. Both executions printed exactly
`language semantics ok\n`. The audit independently rehashed the retained
ejected tree against its report digest.

Native lint produced the exact expected three diagnostics on both passes:
two `correctness::unclosed_io_closer` findings and one
`correctness::infinite_recursion` finding, with exact spans, messages, and
provenance. The accompanying runtime stream has exactly
`TestExecutedCloseForms` and `TestShadowedPanicReturnsTypedNil` running and
passing under each of the three drivers.

## Tools policy and retained strict failure

The reviewed `tools-build.toml` profile now has an observed successful
`logos build ./...` result, alongside successful stock and plain-fork builds.
Its policy SHA256 is
`c57b54d9a78993eac2b2614730cfdf05b12e47c1dbbc77c243f16887d67d7def`.
It preserves the three old unsafe grants and adds only the reviewed two exec
and 14 network package grants. It adds no errgroup grant.

The original strict policy remains byte-identical and still denies the build.
The separate unlimited diagnostic capture records 48 errors and 78 warnings,
without the diagnostic limit. All six additional errors exposed beyond the
limited trace are `syscall.Connect` paths owned by packages already covered by
the reviewed profile. They retain the previously reviewed conservative
interface or error-method reachability. They do not establish observed runtime
network activity. The complete strict failure, both before/after identities,
and two independent early audits remain in `early/` and in the original ZIPs.

## Source and evidence integrity

The read-only audit verified 952 distinct stdout/stderr streams referenced by
the eight replay reports and source preparation: 770 replay streams and 182
preparation streams. It checked 476 recorded process results for true integer
exit codes, absence of timeout, and absence of process-launch errors. It also
checked 18 native identity receipts against the source revision, clean source
status, compiler-source digest, and installed compile/link/asm/cgo identities.
The runtime before/after source and executable receipts are unchanged.

The independently built gglint revision is
`4456e61c4dbdf636fca2b5bd77787873e2d1c1e8`; its build information and source
receipt agree. Its executable SHA256 is
`3ab00d1c9df087cb673cb9014801fc82a4157b9ba14fc02a8afda81f2a4db989`.
The independent diagnostic delta review is recorded separately in
`INDEPENDENT_LINT_AUDIT.md` and `INDEPENDENT_LINT_AUDIT.json`.

That review found no added diagnostics. Exactly 13 strict gglint `chanblock`
findings disappear at source-confirmed direct communications in selects with
a default case. This includes Chi's change from 102 to 101 strict findings;
its deferred send remains reported. Native Protobuf lint removes exactly the
two same-object field-offset findings, from 482 to 480, while retaining every
other record. All other complete normalized diagnostic multisets are unchanged.

| Retained artifact | Identity |
| --- | --- |
| Complete run / job | `43967842639` / `133651861115` |
| Complete artifact | `14280721259`, 1,795,492 bytes, 1,145 entries |
| Complete ZIP SHA256 | `ceee588ceca35faddd80ccecd1d9b45bf8cdc4c01c2e134a30276ec72417a2ce` |
| Early artifact | `14277662877`, 37,893 bytes, 37 entries |
| Early ZIP SHA256 | `a08759c86f63804a1e04a1c48a33b6c15779a5cc2ca39e2a4c2dac028565037b` |
| Complete job log | 81,368 UTF-8 bytes |
| Complete job log SHA256 | `f41155b208ed96f27c5c456d52631aed23b4475cb9fa95aa097584867558b18b` |

The original ZIPs match GitHub's published artifact digests and were checked
for unsafe paths, duplicate names and symlinks before extraction. Raw artifacts
and failed strict-policy reports are retained unchanged. No local Go command
was executed during this audit.

The results establish the stated Linux/amd64 build, lint, and selected runtime
coverage. They do not establish whole-project runtime correctness for every
real input, coverage of unsupported languages, or successful analysis of the
declared incompatible decorder input.
