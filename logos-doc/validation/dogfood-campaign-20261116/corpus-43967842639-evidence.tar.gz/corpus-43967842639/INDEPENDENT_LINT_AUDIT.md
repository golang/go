# Independent lint audit: corpus run 43967842639

## Disposition

Accepted for the retained lint evidence and the source-backed changes described below. No new diagnostic regression was found. This audit executed Python and read Git/source files; it did not execute Go, change source, alter the downloaded artifact, or control a hosted job.

The baseline is run `43950476822`. The candidate is run `43967842639`, job `133651861115`, at LoGOs commit `3b2073eb98e488c411f52ba7cd723e8622c8cdfe`, source tree `ee5ae95824022485b74d4e3186a1540ef7124f76`. Its rebuilt gglint source is `4456e61c4dbdf636fca2b5bd77787873e2d1c1e8`, tree `dfb46c72af5ce9695844c5d567cbb8aab1568183`.

The corrected corpus run `43972897190` remains a separate pending comparison. Its production code, corpus pins and profiles, runner, acceptance checker, workflow, and gglint pin are byte-identical to this candidate. The only source-tree change is the two-call API correction in the compiler test fixture. Its completed normalized diagnostic arrays must therefore match this run unless a concrete discrepancy explains otherwise.

## Raw evidence and completeness

- Independently hashed artifact `14280721259`: `dogfood-43967842639-1.zip`, 1,795,492 bytes, SHA-256 `ceee588ceca35faddd80ccecd1d9b45bf8cdc4c01c2e134a30276ec72417a2ce`. Every one of its 1,145 extracted files matches its original ZIP member.
- Both baseline and candidate reports contain the exact 196-cell matrix: 28 cases, 26 source inputs, three build stages, native lint, and all three gglint modes. All case rows are finished.
- All 112 primary lint cells were parsed from raw streams. The 108 positive lint cells each have a separate repeat with identical invocation, input identity, exit status, and normalized full diagnostic multiset. This covers 220 lint invocations including the four explicit incomplete controls.
- All 608 primary/repeat stdout and stderr hashes in each report were independently recomputed. Diagnostic schemas, optional gglint fields, nested fix/related information, native spans/provenance/fixes, duplicate JSON keys, exact config notices, and exit-status consistency were checked. Every positive cell has zero duplicate diagnostics.
- Every invocation was checked against its case patterns, tags, cgo setting, mode, readonly/offline Go flags, private source directory, full test-loading configuration, and Go driver precedence. The recorded profile is jobs 2, GOMAXPROCS 2, GOMEMLIMIT 2 GiB, and a 600-second command limit. The job log and resource-profile receipt also record inherited GOGC 50.
- Decorder remains incomplete in all four lint cells. Its one actual loader error is the pinned x/tools v0.20.0 `tokeninternal` negative-array-length error. The native stream also retains its ordinary complexity finding. These cells have exit 1 and are not relabeled as successful analysis. The three associated build failures remain visible in the complete matrix.

Candidate status counts are 81 build passes, 98 lint cells with findings, 10 clean lint cells, four load-failed lint cells, one upstream-failed build, and two uncompared builds. Findings remain findings; these counts do not establish that third-party code is defect-free.

## Exact diagnostic changes

There are no added diagnostics. Exactly six lint cells differ from the baseline:

| Case and mode | Before | After | Removed findings |
| --- | ---: | ---: | --- |
| Chi, gglint strict | 102 | 101 | `middleware/throttle.go:95:17` |
| modernc SQLite, gglint strict | 775 | 773 | `stmt.go:101:9`, `stmt.go:294:9` |
| TOML, gglint strict | 125 | 124 | `lex.go:82:16` |
| x/tools, gglint strict | 3,970 | 3,963 | Seven direct communications listed below |
| modernc libc, gglint strict | 5,634 | 5,632 | `libc_musl.go:357:8`, `libc_musl.go:475:14` |
| Protobuf, native lint | 482 | 480 | `internal/impl/presence.go:110:8`, `:137:8` |

All 13 gglint removals are `chanblock` findings on the direct communication clause of a select with a default case. Read-only source inspection confirmed this at every location. The x/tools locations are `go/ssa/task.go:40:7`, `internal/gopathwalk/walk.go:315:10`, `internal/jsonrpc2_v2/conn.go:121:7`, `:270:8`, `:394:7`, `:404:7`, and `internal/jsonrpc2_v2/net.go:102:7`.

The source inventories were independently rehashed in full, with exact Git or module-origin pins checked: Chi 111 files, SQLite 2,022 files, TOML 1,064 files, x/tools 1,624 files, libc 4,230 files, and Protobuf 649 files. Their h1 values match the corpus receipts. The JSON audit retains every removed diagnostic, source-file SHA-256, and the reviewed source context.

The narrow scope is visible in the remaining diagnostics: Chi's deferred send at `middleware/throttle.go:97` and the x/tools nested deferred receive at `internal/gopathwalk/walk.go:321` are still reported. The outer select/default does not suppress those independent body operations. Chi basic remains 3 findings and standard remains 52.

Protobuf loses exactly the two frozen `correctness::arena_pointer_escape` records for same-object field-offset subtraction. Full field equality was checked, including message, rule, severity, byte offsets 3993 and 5196, and 36-byte spans. The other 480 native records are unchanged as a multiset. All Protobuf gglint records are unchanged. Protobuf already passed all three build stages in the baseline and also passes them here; this is a native-lint precision correction.

Every other lint cell has an identical complete normalized multiset. All 28 upstream source identities and package-selection settings are unchanged. The only case-profile change is the explicitly reviewed x/tools replay policy (`policies/tools-build.toml`, SHA-256 `c57b54d9a78993eac2b2614730cfdf05b12e47c1dbbc77c243f16887d67d7def`). Its native build now passes. This policy change is recorded separately from the lint precision changes.

## Rebuilt gglint and stock Go provenance

The raw hosted job records exact detached checkout of `4456e61c4dbdf636fca2b5bd77787873e2d1c1e8`, tree verification, dependency download, clean-worktree checks before and after the build, and:

```sh
go build -mod=readonly -trimpath -o "$RUNNER_TEMP/gglint" ./cmd/gglint
```

The shell runs with `-e -o pipefail`. The build produces no diagnostics. `go version -m` reports Go 1.27.4, the expected revision, `vcs.modified=false`, and trimpath. All 49 downloaded module/version/checksum pairs match the committed gglint `go.sum`; all 48 linked dependencies match those download receipts.

The corpus binary SHA-256 is `3ab00d1c9df087cb673cb9014801fc82a4157b9ba14fc02a8afda81f2a4db989`, consistently recorded in the raw job log, binary checksum receipt, and replay report. This is the freshly rebuilt corpus executable. The executable itself is not included in this artifact, so this audit verifies its retained hash records rather than rehashing an absent binary.

The stock Go driver and its asm, cgo, compile, and link executables were independently rehashed locally against the verified official Go 1.27.4 installation. All five hashes match the corpus tool receipts. The raw job log SHA-256 is `f41155b208ed96f27c5c456d52631aed23b4475cb9fa95aa097584867558b18b`.

## Reproduction and files

`audit_lint.py` performs the raw-schema, invocation, hash, repeat, expected-removal, source-inventory, and dependency-receipt checks. It also supports `--expect-equal` for the later corrected-run comparison. Strict Pyright, full Ruff, and Ruff formatting pass.

```sh
uv run --offline --no-project --no-config --python 3.12 --no-python-downloads \
  python audit_lint.py \
  --baseline ../corpus-43950476822-final/artifact/_temp/logos-corpus-evidence \
  --candidate full/artifact/_temp/logos-corpus-evidence \
  --workspace /workspace/scratch/d8d410ec882d \
  --output INDEPENDENT_LINT_AUDIT.json
```

Run that command from this evidence directory. `INDEPENDENT_LINT_AUDIT.json` contains the full candidate normalized arrays, both reports' checked raw-stream hashes, exact deltas, source contexts, and tool receipts. `INDEPENDENT_LINT_AUDIT.sha256` pins the report, audit code, and this note. Artifact bytes and both source branches remain unchanged.
