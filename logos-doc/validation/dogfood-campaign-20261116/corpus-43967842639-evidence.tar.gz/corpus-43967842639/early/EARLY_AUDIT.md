# Early tools audit: run 43967842639

The unlimited strict-policy capture is complete. It adds six network sink
diagnostics for packages already covered by the reviewed build profile. It
introduces no new package grant requirement. This is a diagnostic result; the
positive build profile remains pending until the separate corpus replay accepts
its `tools/logos` build.

## Exact identity

| Item | Value |
| --- | --- |
| PR head | `3b2073eb98e488c411f52ba7cd723e8622c8cdfe` |
| Repository tree | `0cd74a537f57e4c9c4bf983efba09bfe2918b5e2` |
| Native source tree | `ee5ae95824022485b74d4e3186a1540ef7124f76` |
| Run / job / attempt | `43967842639` / `133651861115` / `1` |
| Artifact | `14277662877`, `tools-probe-43967842639-1` |
| ZIP SHA256 | `a08759c86f63804a1e04a1c48a33b6c15779a5cc2ca39e2a4c2dac028565037b` |
| ZIP size / entries | 37,893 bytes / 37 entries |
| Pinned x/tools | `v0.52.0`, commit `16517d951552611e7bd358c48ee1051fd0e57b0c` |
| Pristine module digest | `h1:ryxg4U63oaUYk7uOLTF37n43f4qgtGvqV4Ioit1BaEs=` |
| Strict effective digest | `h1:t4DoHbhx0AwhPW26pHg34MLv7v7rI03D4g+5MXGzVlU=` |
| Original strict policy SHA256 | `005ba0707611025ef364004190601f0f103ab28ab97da9a6acd81e034d7f4d3f` |
| Reviewed build profile SHA256 | `c57b54d9a78993eac2b2614730cfdf05b12e47c1dbbc77c243f16887d67d7def` |

The ZIP matches GitHub's artifact digest. Its paths were checked for traversal,
symlinks and duplicates before extraction. The original ZIP is retained.

## Baseline and capture verification

The baseline contains exactly three `build ./...` commands in the verified
private tools copy. The stock oracle and plain fork both exited zero with empty
stdout and stderr. The stock driver has a distinct executable path, GOROOT and
SHA256. The LoGOs strict-policy build exited one with capability diagnostics.
The runner and console capture exits were respectively one and zero.

The unlimited command is exactly `logos build -ldflags=-e ./...`, with its own
verified private source copy and the same strict policy. It exited one in
19.46 seconds without timeout or process error. The report correctly records
`complete: true` and `build_succeeded: false`; it does not accept the corpus.

The independent audit checked the baseline report hash, profile, source and
effective-source digests, exact commands and working directories, stage-specific
PATH and cache, and the complete recorded environment. Both phases use two
workers, a 600-second deadline, `GOMAXPROCS=2`, `GOMEMLIMIT=2GiB`, and inherited
`GOGC=50`. Module resolution is offline. All 26 distinct recorded stdout/stderr
files match their report hashes. The before and after source revision, clean
source status, source digest, and six installed native executable identities
match. The audit itself ran only Python and read-only Git commands.

| Executable | SHA256 |
| --- | --- |
| Stock go | `de0ae3e082ce7599eae4fb69fa2ef1e43b8f31ffd3fce62cdf81930aa9005050` |
| Fork go and logos | `3ff28734518c56ed7b43513e1dd600eae4a25aa4e554a3c9caa71449625c1465` |
| compile | `5a3d240773d4fbdc77ed5c7327a169c44edbaa7df7e4e9e70d68b04eaf6550ed` |
| link | `acfd602e8bb3a5e5472067fa8c3805d5a7c6b3ab27a9e94f41e68d01d2c8b6bf` |
| asm | `6937a512953e8bf2f49b2d4663f95993779b299aecc00d09121e05de3001dd6a` |
| cgo | `43d5894c3e2bc4c1737610c7a9d555de581b7bdfd9825083c4f662dfcefef6c3` |

## Complete strict trace

| Capture | Warnings | Network errors | Exec errors | Error limit reached |
| --- | ---: | ---: | ---: | --- |
| Original strict command | 78 | 36 | 6 | Yes |
| Unlimited strict command | 78 | 42 | 6 | No |

The original strict stderr is byte-identical to run 43950476822's early strict
stderr: SHA256 `f17aa775d75242f461630680225642406030f3c81bbfec436b0609164ada4073`.
The unlimited stderr has SHA256
`1469924ce9075834d6972638233aafdd45fac29c9d45181c4f4a7715a8f8872a`.
Every existing diagnostic remains present. The six additional errors name
`syscall.Connect` and these packages:

- `golang.org/x/telemetry/internal/configstore`
- `golang.org/x/telemetry/internal/counter`
- `golang.org/x/telemetry/internal/crashmonitor`
- `golang.org/x/telemetry/internal/mmap`
- `golang.org/x/telemetry/internal/telemetry`
- `golang.org/x/telemetry/internal/upload`

Each added chain shares its existing `net.sysSocket` diagnostic's full prefix
through `net.socket`, from 26 to 40 frames. The additional tail is
`net.(*netFD).dial` → `net.(*netFD).connect` → `syscall.Connect`.
The exact-source review confirms that `net.socket` calls `fd.dial`, that
`fd.dial` calls `fd.connect`, and that the Unix `connectFunc` is initialized to
`syscall.Connect`. File identities and excerpts are retained in
`SOURCE_TAIL_REVIEW.json`.

Earlier parts of these paths retain the already reviewed conservative interface
and error-method edges. Configstore reaches a `Closer` through `os/exec.Cmd.Wait`;
counter uses `fmt.Fprintf`; crashmonitor uses `io.ReadAll`; mmap, telemetry and
upload reach formatting through error or string methods. The capability
contract requires synthetic interface and reflective reachability edges. These
reports do not establish that a particular runtime invocation opens a socket.

All 48 error identities are covered by the existing exact-package build profile.
There is no errgroup denial, no new blamed package, and no reason to broaden the
profile from this trace. The original strict policy, runner and acceptance
checker remain unchanged.

## Retained evidence

`EARLY_AUDIT.json` contains the machine-readable outcome. `RECORDED_LOGS.sha256`
lists the independently rehashed streams. `NEW_CONNECT_PATHS.txt` preserves all
six complete newly exposed call chains. `audit_early.py` records the reproducible
read-only checks. `DOWNLOAD.json` records the ZIP identity and extraction bounds.

Full 196-cell acceptance, runtime comparisons and final source stability must be
assessed from the later complete artifact. They were still running when this
early audit was written.
