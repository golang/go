# pyright: strict
"""Verify this evidence inventory and optionally reproduce its deterministic archive."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import re
import tarfile
from pathlib import Path, PurePosixPath


def verified_files(root: Path) -> tuple[Path, ...]:
    files: dict[str, Path] = {}
    for path in root.rglob("*"):
        if path.is_symlink():
            raise ValueError(f"symlink in evidence: {path}")
        if path.is_file() and path != root / "SHA256SUMS":
            files[path.relative_to(root).as_posix()] = path
    expected: dict[str, str] = {}
    for line in (root / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        digest, separator, relative = line.partition("  ")
        name = PurePosixPath(relative)
        if (
            not separator
            or re.fullmatch(r"[0-9a-f]{64}", digest) is None
            or name.is_absolute()
            or ".." in name.parts
            or name.as_posix() != relative
            or relative in expected
        ):
            raise ValueError("invalid checksum entry")
        expected[relative] = digest
    if set(expected) != set(files) or list(expected) != sorted(expected):
        raise ValueError("evidence inventory differs")
    for relative, path in files.items():
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected[relative]:
            raise ValueError(f"evidence hash differs: {relative}")
    return tuple(files[name] for name in sorted(files)) + (root / "SHA256SUMS",)


def archive(root: Path, files: tuple[Path, ...], output: Path) -> None:
    if output.is_relative_to(root):
        raise ValueError("archive must be outside the evidence directory")
    with (
        output.open("xb") as raw,
        gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed,
        tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as bundle,
    ):
        for path in sorted(files, key=lambda entry: entry.relative_to(root).as_posix()):
            data = path.read_bytes()
            name = f"native-43972750963/{path.relative_to(root).as_posix()}"
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = 0o644
            entry.uid = entry.gid = entry.mtime = 0
            entry.uname = entry.gname = ""
            bundle.addfile(entry, io.BytesIO(data))


class Arguments(argparse.Namespace):
    output: Path | None


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(namespace=Arguments())
    root = Path(__file__).resolve().parent
    files = verified_files(root)
    print(f"Verified {len(files) - 1} evidence files.")
    if args.output is not None:
        output = args.output.resolve()
        archive(root, files, output)
        data = output.read_bytes()
        print(f"{len(data)} bytes; SHA256 {hashlib.sha256(data).hexdigest()}")


if __name__ == "__main__":
    main()
