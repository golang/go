"""Audit downloaded capability-script events and installed-linker restoration."""

from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import cast

from audit_unit import CRASH, HEAD, ROOT, SRC, Json, obj, read, sha, string

BASE = ROOT / "scripts-artifact/logos-regression-evidence/cap-inline"
NAMES = ("TestScript", "TestScript/logos_cap_inline_context")
WITNESS = (
    "Transitive dependency 'example.com/inlinecapdep/safe' reaches 'syscall.Socket'"
)


def hashes(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    for line in path.read_text().splitlines():
        digest, name = line.split(maxsplit=1)
        assert len(digest) == 64 and name not in result
        result[name] = digest
    return result


def audit_phase(label: str) -> dict[str, Json]:
    expected = "fail" if label == "negative" else "pass"
    stdout = BASE / f"{label}.json"
    stderr = BASE / f"{label}.stderr.log"
    check = read(BASE / f"{label}.check.json")
    exit_code = int((BASE / f"{label}.status.txt").read_text())
    assert exit_code == (1 if label == "negative" else 0)
    assert check["accepted"] is True and check["exit"] == exit_code
    assert check["mode"] == label
    assert check["stdout_sha256"] == sha(stdout)
    assert check["stderr_sha256"] == sha(stderr)
    assert not stderr.read_bytes()
    counts: dict[str, Counter[str]] = {
        action: Counter() for action in ("run", "pass", "fail", "skip")
    }
    active: set[str] = set()
    output: dict[str, list[str]] = defaultdict(list)
    started = False
    finished = False
    for line in stdout.read_text().splitlines():
        event = obj(cast("Json", json.loads(line)))
        assert event["Package"] == "cmd/go"
        assert "FailedBuild" not in event and not finished
        action = string(event["Action"])
        assert action in {"start", "run", "output", "pass", "fail", "pause", "cont"}
        name = string(event.get("Test", ""))
        if "OutputType" in event:
            assert action == "output"
            assert event["OutputType"] in ("", "frame", "error", "error-continue")
        if action == "start":
            assert not started and not name
            started = True
            continue
        assert started
        if action == "output":
            assert not name or name in active
            output[name].append(string(event["Output"]))
            continue
        if not name:
            assert action == expected and not active
            finished = True
            continue
        assert name in NAMES
        if action == "run":
            assert name not in active and counts["run"][name] == 0
            active.add(name)
        elif action in {"pass", "fail"}:
            assert name in active
            active.remove(name)
        else:
            assert name in active
            continue
        counts[action][name] += 1
    assert started and finished and not active
    assert counts["run"] == counts[expected] == Counter(NAMES)
    assert not counts["pass" if expected == "fail" else "fail"]
    assert not counts["skip"]
    assert not CRASH.search(
        "".join(text for parts in output.values() for text in parts)
    )
    if label == "negative":
        assert WITNESS in "".join(output[NAMES[1]])
    assert obj(check["named_results"]) == dict(Counter(NAMES))
    return {
        "phase": label,
        "exit": exit_code,
        "events": {
            key: {name: number for name, number in value.items()}
            for key, value in counts.items()
        },
        "package_results": [expected],
        "negative_witness_in_child": True if label == "negative" else None,
        "stderr_bytes": 0,
        "hashes_match": True,
        "event_lifetimes_valid": True,
        "accepted": True,
    }


def main() -> None:
    phases = [audit_phase(label) for label in ("negative", "candidate")]
    expected_source = f"{HEAD}\n{SRC}\n"
    assert (BASE / "source-before.txt").read_text() == expected_source
    assert (BASE / "source-after.txt").read_text() == expected_source
    for name in ("source.diff.txt", "source-after.diff.txt"):
        assert not (BASE / name).read_bytes()
    before = hashes(BASE / "tools-before.sha256")
    assert before == hashes(BASE / "tools-restored.sha256")
    unit = read(ROOT / "unit-artifact/logos-regression-evidence/zero-array/before.json")
    unit_hashes = obj(unit["sha256"])
    assert len(before) == 4
    for name, digest in before.items():
        relative = name.removeprefix("/home/runner/work/LoGOs/LoGOs/")
        assert unit_hashes[relative] == digest
    old = tuple(hashes(BASE / "old-link.sha256").values())
    during = tuple(hashes(BASE / "link-during-negative.sha256").values())
    assert len(old) == 1 and old == during
    assert old[0] != unit_hashes["pkg/tool/linux_amd64/link"]
    assert (BASE / "old-link-build.status.txt").read_text().strip() == "0"
    assert not (BASE / "old-link-build.stderr.log").read_bytes()
    assert (BASE / "runner.status.txt").read_text().strip() == "0"
    assert (
        BASE / "summary.txt"
    ).read_text() == "exit=0\nphase=accepted\nlink_replaced=0\n"
    verify = read(BASE / "verify.check.json")
    assert verify["mode"] == "verify"
    assert read(BASE / "verify-after.check.json") == verify | {"mode": "verify-after"}
    assert verify["accepted"] is True
    assert verify["frozen_sha256"] == (
        "0a2ed87e4b0e9af5b05ffd6fbac0c7cf4bbdf78a094e160ec6cd76725531b6ee"
    )
    verified = obj(verify["verified"])
    assert len(verified) == 11
    original = read(ROOT / "expected-inline-frozen-hashes.json")
    assert verify == original
    report: dict[str, Json] = {
        "run_id": 43972750963,
        "job_id": 133668874024,
        "head": HEAD,
        "phases": list(phases),
        "source_unchanged": True,
        "tools_restored": True,
        "tools_match_unit": True,
        "frozen_input_hashes_unchanged": True,
        "verified_input_count": len(verified),
        "old_link": old[0],
        "candidate_link": unit_hashes["pkg/tool/linux_amd64/link"],
    }
    target = ROOT / "independent-scripts-audit.json"
    text = json.dumps(report, indent=2) + "\n"
    if target.exists():
        assert target.read_text() == text
    else:
        target.write_text(text)
    print(json.dumps({"accepted_phases": 2, "report_sha256": sha(target)}))


if __name__ == "__main__":
    main()
