# Corrected full upstream audit

Job **133668873658** in [run 43972750963](https://github.com/gosuda/LoGOs/actions/runs/43972750963) completed successfully at **2026-11-16T23:32:31Z**. The exact candidate is `6c53eb629a0f572db7ce157372005e0fa2089d1d`, source tree `6a650366141c23a154f6e0b153767527e520a58f`, fixture tree `a64f88184df739e681c29c83e059d44ab6fda7bd`.

## Complete retained evidence

The complete [raw job log](upstream.raw.log) is 125,004 UTF-8 bytes, SHA-256 `6a8b646dca166280ee2eba46096a997f6b905246e1ce1537471af1bb088ea4fc`. Every decoded character was read back against the API response; [the receipt](upstream-log-receipt.json) records that comparison.

The original [artifact ZIP](logos-upstream-43972750963-1.zip), artifact ID **14282698579**, is 24,505 bytes, SHA-256 `e75b50770f3f8e51f750424552bab3c75cc169a367e6119e82af7851be46571e`. Its size and digest match GitHub metadata. [The artifact receipt](upstream-artifact-receipt.json) records all extracted payload hashes.

The exact logs, inventory, profiles, numeric process exits, source receipts and six executable hashes are retained under [the upstream artifact directory](upstream-artifact/logos-regression-evidence/upstream/). [The independent audit](independent-upstream-audit.json), SHA-256 `b8d1d280930f138e98772c6c36b2f4b2a72898f9374abc708af84a610ffaef12`, reproduces the acceptance checks from those records. [Its script](audit_upstream.py) executes no Go command or original CI checker.

## Complete three-way partition

The unfiltered dist inventory has **666 unique registered names**. Its SHA-256 is `5b4fb09e6d180e745995ec1d7ac4f614750b9633c996894acf07a59812dcdfd4`, identical to the original f424 inventory. The top-level inventory and the partition helper's retained copy are byte-identical. The independently computed partition sets are pairwise disjoint and their union is exactly the complete inventory.

| Partition | Registered names | Timeout scale | Driver exit | Console-capture exit | Timing |
|---|---:|---:|---:|---:|---|
| Complement | 664 | 1 | 0 | 0 | Actions step: 1,082 seconds |
| Complete testdir shard set | 1 (`cmd/internal/testdir:0_1`) | 2 | 0 | 0 | Go package: 437.206 seconds; Actions step: 439 seconds |
| Complete command driver | 1 (`cmd/go`) | 4 | 0 | 0 | Go package: 1,169.836 seconds; Actions step: 1,173 seconds |

The complement does not emit a single aggregate Go-process duration. Its 1,082 seconds are the difference between the recorded Actions step timestamps, 22:47:26 and 23:05:28 UTC, at the API's one-second resolution. They must not be presented as an independently measured aggregate process duration.

The filters are recorded verbatim in the profile files and matched independently against the full inventory:

```text
complement: !^(cmd/go|cmd/internal/testdir:(0|[1-9][0-9]*)_([1-9][0-9]*))$
testdir:    ^cmd/internal/testdir:(0|[1-9][0-9]*)_([1-9][0-9]*)$
cmd/go:     ^cmd/go$
```

Each command is the genuine `./run.bash --no-rebuild -k` invocation through the compact environment wrapper. The complement keeps scale 1. Testdir retains the approved 20-minute package budget and 25-minute step budget; cmd/go retains the 36-minute package budget and 45-minute step budget. The workflow installs the three upstream oracle toolchains and explicit Node version before the fresh build. No fake builder identity, per-test exclusion, or retry was added for this completed run.

Every partition ends with `ALL TESTS PASSED (some were excluded)`. The parenthesized text is expected for each filtered dist invocation: the other two partitions are outside that invocation. The verified union covers all 666 registered names. These ordinary dist logs retain default platform and short-test semantics; they do not enumerate every internal subtest skip, and this audit makes no cross-platform coverage claim.

The complete `cmd/compile/internal/types2` package passes in **9.921 seconds** in the complement. This closes the original fixture API build failure under the full package selection, in addition to the exact 67-name classification and 15-name facts controls in the unit job. No failed package, build failure, crash diagnostic or timeout appears in the three retained partition logs.

## Before/after identity

Both source receipts contain exactly:

```text
6c53eb629a0f572db7ce157372005e0fa2089d1d
6a650366141c23a154f6e0b153767527e520a58f
a64f88184df739e681c29c83e059d44ab6fda7bd
```

Both root-relative `src`/`test` status files are empty. All six installed executable hashes are identical before and after the complete partition sequence:

| Executable | SHA-256 |
|---|---|
| `bin/go` and `bin/logos` | `3191301308102ad4dd2ca9d6c51551f3acea9cb4f1dde3964eef9b359daeea20` |
| `pkg/tool/linux_amd64/compile` | `5a3d240773d4fbdc77ed5c7327a169c44edbaa7df7e4e9e70d68b04eaf6550ed` |
| `pkg/tool/linux_amd64/link` | `acfd602e8bb3a5e5472067fa8c3805d5a7c6b3ab27a9e94f41e68d01d2c8b6bf` |
| `pkg/tool/linux_amd64/asm` | `6937a512953e8bf2f49b2d4663f95993779b299aecc00d09121e05de3001dd6a` |
| `pkg/tool/linux_amd64/cgo` | `35240213dfd039f64f70579315d22c4ab247d985f608cb9f094ffb2637cc870b` |

The four common tools also match the corrected unit and scripts jobs. All six match the original f424 run, consistent with the source difference being confined to the two test-fixture API calls.
