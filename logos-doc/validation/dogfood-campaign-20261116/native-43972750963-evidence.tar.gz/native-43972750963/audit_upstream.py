"""Audit complete recorded dist partitions without executing any Go command."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

from audit_scripts import hashes
from audit_unit import CRASH, HEAD, ROOT, SRC, Json, arr, obj, read, sha, string

BASE = ROOT / "upstream-artifact/logos-regression-evidence/upstream"
TEST_TREE = "a64f88184df739e681c29c83e059d44ab6fda7bd"
TESTDIR_FILTER = r"^cmd/internal/testdir:(0|[1-9][0-9]*)_([1-9][0-9]*)$"
COMPLEMENT_FILTER = r"!^(cmd/go|cmd/internal/testdir:(0|[1-9][0-9]*)_([1-9][0-9]*))$"
INVENTORY_SHA = "5b4fb09e6d180e745995ec1d7ac4f614750b9633c996894acf07a59812dcdfd4"


@dataclass(frozen=True)
class Partition:
    key: str
    prefix: str
    pattern: str
    scale: int
    timeout: int | None


PARTITIONS = (
    Partition("cmd_go", "cmd-go", "^cmd/go$", 4, 36),
    Partition("testdir", "testdir", TESTDIR_FILTER, 2, 20),
    Partition("complement", "complement", COMPLEMENT_FILTER, 1, None),
)


def fields(path: Path) -> dict[str, str]:
    pairs = [line.split("=", maxsplit=1) for line in path.read_text().splitlines()]
    assert all(len(pair) == 2 for pair in pairs)
    result = {pair[0]: pair[1] for pair in pairs}
    assert len(result) == len(pairs)
    return result


def main() -> None:
    inventory = BASE / "all-tests.txt"
    assert inventory.read_bytes() == (BASE / "partition/inventory.txt").read_bytes()
    assert sha(inventory) == INVENTORY_SHA
    names = inventory.read_text().splitlines()
    assert len(names) == len(set(names)) == 666
    catalog = read(BASE / "partition/partition.json")
    assert catalog["schema"] == 2
    assert catalog["inventory_sha256"] == INVENTORY_SHA
    assert catalog["all_names"] == names
    assert catalog["complete_union"] is True and catalog["disjoint"] is True
    assert catalog["execution_claimed"] is False
    command_names = {name for name in names if name == "cmd/go"}
    testdir_names = {name for name in names if re.fullmatch(TESTDIR_FILTER, name)}
    assert command_names == {"cmd/go"}
    assert testdir_names == {"cmd/internal/testdir:0_1"}
    selections = {
        "cmd_go": command_names,
        "testdir": testdir_names,
        "complement": set(names) - command_names - testdir_names,
    }
    assert set[str]().union(*selections.values()) == set(names)
    assert sum(map(len, selections.values())) == len(names)
    results: list[Json] = []
    for partition in PARTITIONS:
        recorded = obj(catalog[partition.key])
        selected = [string(item) for item in arr(recorded["names"])]
        assert len(selected) == len(set(selected))
        assert set(selected) == selections[partition.key]
        assert recorded["filter"] == partition.pattern
        assert recorded["timeout_scale"] == partition.scale
        profile = fields(BASE / f"{partition.prefix}-profile.txt")
        expected = {"filter": partition.pattern, "timeout_scale": str(partition.scale)}
        if partition.timeout is not None:
            expected["package_timeout_minutes"] = str(partition.timeout)
        assert profile == expected
        exits = fields(BASE / f"{partition.prefix}-exit.txt")
        assert exits == {"driver": "0", "console_capture": "0"}
        path = BASE / f"{partition.prefix}.log"
        log = path.read_text()
        assert log.count("ALL TESTS PASSED") == 1
        failures = re.findall(r"^FAIL[ \t]+([^ \t\r\n]+)(?:[ \t]|$)", log, re.MULTILINE)
        assert not failures
        assert not CRASH.search(log)
        results.append(
            {
                "partition": partition.key,
                "names": list(selected),
                "count": len(selected),
                "profile": {key: value for key, value in profile.items()},
                "exits": {key: int(value) for key, value in exits.items()},
                "failed_packages": [],
                "all_tests_passed_summary": True,
                "log_sha256": sha(path),
            }
        )
    source = f"{HEAD}\n{SRC}\n{TEST_TREE}\n"
    assert (BASE / "source-before.txt").read_text() == source
    assert (BASE / "source-after.txt").read_text() == source
    assert not (BASE / "source-before.status.txt").read_bytes()
    assert not (BASE / "source-after.status.txt").read_bytes()
    tools = hashes(BASE / "tools-before.sha256")
    assert tools == hashes(BASE / "tools-after.sha256")
    assert len(tools) == 6
    unit = read(ROOT / "unit-artifact/logos-regression-evidence/zero-array/before.json")
    unit_tools = obj(unit["sha256"])
    expected_tools = {
        "bin/go": string(unit_tools["bin/go"]),
        "bin/logos": string(unit_tools["bin/logos"]),
        "pkg/tool/linux_amd64/compile": string(
            unit_tools["pkg/tool/linux_amd64/compile"]
        ),
        "pkg/tool/linux_amd64/link": string(unit_tools["pkg/tool/linux_amd64/link"]),
        "pkg/tool/linux_amd64/asm": (
            "6937a512953e8bf2f49b2d4663f95993779b299aecc00d09121e05de3001dd6a"
        ),
        "pkg/tool/linux_amd64/cgo": (
            "35240213dfd039f64f70579315d22c4ab247d985f608cb9f094ffb2637cc870b"
        ),
    }
    assert tools == expected_tools
    report: dict[str, Json] = {
        "run_id": 43972750963,
        "job_id": 133668873658,
        "head": HEAD,
        "source_tree": SRC,
        "test_tree": TEST_TREE,
        "inventory_count": len(names),
        "inventory_sha256": INVENTORY_SHA,
        "complete_union": True,
        "pairwise_disjoint": True,
        "partitions": results,
        "source_test_trees_unchanged": True,
        "source_test_status_empty": True,
        "installed_tools_unchanged": True,
        "installed_tools_match_original_and_unit": True,
        "tool_sha256": {name: digest for name, digest in tools.items()},
        "scope": "The complete recorded Linux/amd64 dist selection, using default short-test semantics.",
    }
    target = ROOT / "independent-upstream-audit.json"
    text = json.dumps(report, indent=2) + "\n"
    if target.exists():
        assert target.read_text() == text
    else:
        target.write_text(text)
    print(json.dumps({"accepted_partitions": 3, "report_sha256": sha(target)}))


if __name__ == "__main__":
    main()
