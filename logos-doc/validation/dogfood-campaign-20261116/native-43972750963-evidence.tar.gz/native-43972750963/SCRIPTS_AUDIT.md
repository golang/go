# Corrected native scripts audit

Job **133668874024** in [run 43972750963](https://github.com/gosuda/LoGOs/actions/runs/43972750963) completed successfully at **2026-11-16T23:17:40Z**, using exact head `6c53eb629a0f572db7ce157372005e0fa2089d1d` and source tree `6a650366141c23a154f6e0b153767527e520a58f`.

The complete [raw log](scripts.raw.log) is 46,027 UTF-8 bytes, SHA-256 `cc4d7a2e206a357bd2076cf6ba3482df823560d1bfa7f9a5067ba5b4921bc1e7`. Its decoded text was fully read back against the GitHub API response; [the receipt](scripts-log-receipt.json) retains the result. The original artifact, ID **14281113330**, is [logos-scripts-43972750963-1.zip](logos-scripts-43972750963-1.zip), 16,888 bytes, SHA-256 `e449417bfc194a7320445841e5b204f06fe4f9a1937bb803912d9f7195e2aaf1`. Size and digest match GitHub metadata, and every extracted file was rehashed; see [the artifact receipt](scripts-artifact-receipt.json).

## Completed command scopes

| Scope | Recorded command | Result |
|---|---|---|
| Complete LoGOs script subset | `go test -count=1 -timeout 60m cmd/go -run 'Script/^logos_'` through the compact environment wrapper | Pass, 1,636.836 seconds |
| Installed subprocess behavior | `go test -count=1 -race -parallel=1 -timeout 20m cmd/go -run 'Script/^logos_(cap_xtest_owner\|test_experiment_env\|test_plugin_experiment\|test_cache_experiment)$'` through the same wrapper | Pass, 30.402 seconds |
| Inline capability attribution | Archived-linker negative followed by installed-candidate positive, both under the frozen helper | Exact inventories accepted |

The first two commands use ordinary Go package summaries. Their complete commands and successful package results are retained in the log; this audit does not invent per-script JSON inventories for those summaries.

## Independent inline-capability proof

[The independent audit](independent-scripts-audit.json) and [its reproducible script](audit_scripts.py) verify the two exact named tests: `TestScript` and `TestScript/logos_cap_inline_context`.

- The archived linker produces exactly two named runs and two named failures, package failure, and process exit 1. The expected child reports `Transitive dependency 'example.com/inlinecapdep/safe' reaches 'syscall.Socket'`.
- The candidate produces exactly two named runs and two named passes, package success, and process exit 0.
- Both streams have valid event lifetimes, empty stderr, matching capture hashes, and no skipped, duplicated, missing or unexpected test identities. Neither contains a build failure or crash diagnostic.
- The before/after frozen-file receipts verify the same 11 input hashes and manifest digest `0a2ed87e4b0e9af5b05ffd6fbac0c7cf4bbdf78a094e160ec6cd76725531b6ee`. Their expected phase labels are `verify` and `verify-after`; all other fields match exactly. [The comparison catalog](expected-inline-frozen-hashes.json) is a byte-identical copy of the original f424 artifact's accepted verification receipt, SHA-256 `2d8b49b9eb231adfbb52174e5adf94032857aa627efee376cfa02323e7fde20e`.

The archived linker SHA-256 is `678df2fb08471d22501096beaed91e7f332e972f2118f760b368afca4bbed73d`. The installed-negative receipt matches it, and the candidate linker differs: `acfd602e8bb3a5e5472067fa8c3805d5a7c6b3ab27a9e94f41e68d01d2c8b6bf`.

The archived-linker build succeeds with empty stderr. All four installed executable hashes are restored before candidate acceptance and match the unit job's hashes. Before/after source receipts contain the exact head and source tree above; both source-diff files are empty. The runner exits 0, records `phase=accepted`, and records `link_replaced=0`.

The audit script's strict Pyright and Ruff checks pass. The only local analysis adjustment was recognizing that the before/after verification receipts intentionally use different `mode` labels. No CI payload, fixture, production file, or source branch was changed during this audit.
