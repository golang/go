# Corrected native unit audit

The unit job **133668874185** in [run 43972750963](https://github.com/gosuda/LoGOs/actions/runs/43972750963) completed successfully at **2026-11-16T23:02:00Z**. This audit concerns the exact PR76 head `6c53eb629a0f572db7ce157372005e0fa2089d1d`, root tree `616b5421bc6912783762783b2ca681cacd50c105`, and source tree `6a650366141c23a154f6e0b153767527e520a58f`. It does not substitute for the separately recorded scripts or upstream jobs.

## Evidence identity

The complete [raw job log](unit.raw.log) is 119,896 UTF-8 bytes, SHA-256 `22ae17893191d4fb3f9ef74bd119eab96593200b8d056fb2262c6c557ef72936`. Every decoded character was read back and compared with the GitHub job-log API result; see [the receipt](unit-log-receipt.json).

The original [artifact ZIP](logos-unit-43972750963-1.zip), artifact ID **14279513848**, is 78,697 bytes, SHA-256 `2d17b4e8030c5709bdcc2d7ba853957dd9a14f2952a91bf0b21e152543b620e3`. Size and SHA match GitHub metadata. Every extracted file was read back and hashed; [the artifact receipt](unit-artifact-receipt.json) records those identities.

## Exact regression inventories

[The independent audit](independent-unit-audit.json) verifies all 18 recorded phases against catalogs prepared from the exact source before acceptance. It compares complete name multisets, individual event lifetimes, package identities and terminal results, child-owned negative diagnostics, process exits, empty stderr, capture hashes, and the race flag. It rejects skips, extra or duplicate names, build failures, missing events, and crash output. [The replay script](audit_unit.py) reads evidence only and does not execute Go or the original CI helper. Its strict Pyright and Ruff checks passed.

Counts below include named parent tests. They are phase inventories, not a count of distinct leaf cases across the entire job.

| Suite | Phase | Exact named runs and outcomes | Process exit |
|---|---|---:|---:|
| Tagged methods | Old codec | 2 failures | 1 |
| Tagged methods | Old package guard | 1 failure | 1 |
| Tagged methods | Candidate facts | 72 passes | 0 |
| Tagged methods | Candidate compiler/import controls | 17 passes | 0 |
| Tagged package facts | Old predicate | 2 failures | 1 |
| Tagged package facts | Candidate | 150 passes | 0 |
| Wasm under Node | Candidate | 7 passes | 0 |
| Field offsets | Old rule | 2 failures | 1 |
| Field offsets | Candidate | 50 passes | 0 |
| SIMD imports | Old import configuration | 2 failures | 1 |
| SIMD imports | Old rewriter | 2 failures | 1 |
| SIMD imports | Candidate work package, race enabled | 11 passes | 0 |
| SIMD imports | Candidate midway package | 7 passes | 0 |
| SIMD imports | Candidate compiler/consumer cases | 19 passes | 0 |
| Zero arrays | Old reference-free predicate | 3 failures | 1 |
| Zero arrays | Old mutation proof | 2 failures | 1 |
| Zero arrays | Candidate type classification | 67 passes | 0 |
| Zero arrays | Candidate mutation facts | 15 passes | 0 |

The negative zero-array type witness is `LogosReferenceFree([0]func()) = false, want true`. The negative mutation witness is `ReturnZero: ParamMutated="1" ReceiverMutated=false, want "0" false`. Both occur in the expected named child. The candidate runs preserve the original expected types and masks. [The dedicated zero-array audit](independent-zero-array-audit.json) also checks all 55 replacement-manifest inputs.

## Source and installed tools

All six regression suites recorded identical before/after source and tool receipts. Their head, root tree and source tree equal the exact identifiers above. All new frozen inputs and observed production files match the independent pre-result catalogs. Receipts with a tracked-status field record an empty status. The tagged-package receipt uses its own explicit source-and-tool schema.

| Installed tool | SHA-256 |
|---|---|
| `bin/go` and `bin/logos` | `3191301308102ad4dd2ca9d6c51551f3acea9cb4f1dde3964eef9b359daeea20` |
| `pkg/tool/linux_amd64/compile` | `5a3d240773d4fbdc77ed5c7327a169c44edbaa7df7e4e9e70d68b04eaf6550ed` |
| `pkg/tool/linux_amd64/link` | `acfd602e8bb3a5e5472067fa8c3805d5a7c6b3ab27a9e94f41e68d01d2c8b6bf` |

These four installed binaries also match the original f424 run. [The exact source-tree patch](source-only.patch) changes only two `.Complete()` suffixes in `referencefree_zero_array_logos_test.go`. Compiler `types2.NewInterfaceType` already returns a completed interface; the removed method belongs to the public `go/types` API and does not exist in compiler `types2`. No production code, test values, expected masks, or test names changed. The original failed evidence remains in the separate f424 bundle and in the fixture compatibility freeze.

## Other completed unit gates

The raw job log records the following successful gates:

- The declared LoGOs package set under `go test -count=1 -short`; its compiler package took 104.814 seconds. This package selection does not itself include `cmd/compile/internal/types2`; the explicit 67-name type gate above supplies that focused coverage.
- Race tests for `logos/...` and the language server, runtime metrics, and arena tests under both the race-enabled arena profile and the `nogreenteagc` profile.
- All LoGOs compiler fixtures through `cmd/internal/testdir -run 'Test/logos/'`, 355.336 seconds.
- Formatting, vet and pinned golangci-lint, which reported **0 issues**.
- Race tests for linker, work and test packages, respectively 35.093, 1.138 and 1.034 seconds; generator/source-shape controls passed in 0.064 seconds.
- The inherited-environment negative overlay produced the expected default-environment and cache failures. Its saved JSON stream contains 17 named runs, 10 named failures and 7 named passes. The generator identity transformation produced the expected `TestGenerate` failure and the leaked `check.conf.Logos` fragment. Restored positive tests passed for both packages, in 0.006 and 0.063 seconds. The original overlay recipes and process-failure checks remain in the raw log; the artifact retains their overlay maps and event streams.
- Seven Python helper test invocations passed 52, 91, 25, 207, 8, 2 and 53 cases, respectively, for 438 cases across those invocations. Their type/style checks and ShellCheck also passed.

This audit establishes the outcomes of the recorded Linux/amd64 CI commands. It does not infer unobserved platforms or turn intentional negative results into candidate failures.
