"""Independently audit recorded unit evidence; never invoke Go or a CI helper."""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import TypeAlias, cast

Json: TypeAlias = None | bool | int | float | str | list["Json"] | dict[str, "Json"]
ROOT = Path(__file__).resolve().parent
HEAD = "6c53eb629a0f572db7ce157372005e0fa2089d1d"
TREE = "616b5421bc6912783762783b2ca681cacd50c105"
SRC = "6a650366141c23a154f6e0b153767527e520a58f"
GROUPS = {
    "field-offset-lint": "field-offset",
    "simd-transitive-imports": "simd-imports",
    "zero-array-reference-free": "zero-array",
}
TOOLS = (
    "bin/go",
    "bin/logos",
    "pkg/tool/linux_amd64/compile",
    "pkg/tool/linux_amd64/link",
)
CRASH = re.compile(
    r"(?mi)^(?:panic:|fatal error:|runtime:|signal:|SIG[A-Z0-9]+:)|"
    r"\[build failed\]|test timed out"
)


def obj(value: Json) -> dict[str, Json]:
    assert isinstance(value, dict), value
    return value


def arr(value: Json) -> list[Json]:
    assert isinstance(value, list), value
    return value


def string(value: Json) -> str:
    assert isinstance(value, str), value
    return value


def read(path: Path) -> dict[str, Json]:
    return obj(cast("Json", json.loads(path.read_text())))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


@dataclass(frozen=True)
class Phase:
    group: str
    label: str
    package: str
    names: tuple[str, ...]
    negative: tuple[str, str] | None
    race: bool


def phase(data: dict[str, Json], group: str) -> Phase:
    negative = data.get("negative")
    pair = None
    if negative is not None:
        parts = arr(negative)
        assert len(parts) == 2
        pair = (string(parts[0]), string(parts[1]))
    names = tuple(string(item) for item in arr(data["names"]))
    assert names and len(names) == len(set(names))
    return Phase(
        group,
        string(data["label"]),
        string(data["package"]),
        names,
        pair,
        data.get("race") is True,
    )


def audit_phase(expected: Phase, base: Path) -> dict[str, Json]:
    directory = base / expected.group
    stdout = directory / f"{expected.label}.jsonl"
    stderr = directory / f"{expected.label}.stderr.txt"
    status = read(directory / f"{expected.label}.status.json")
    assert status["stdout_sha256"] == sha(stdout)
    assert status["stderr_sha256"] == sha(stderr)
    assert stderr.read_bytes() == b""
    assert status["timed_out"] is False
    assert status["exit_code"] == (1 if expected.negative else 0)
    assert status["accepted"] is True
    command = tuple(string(item) for item in arr(status["command"]))
    assert expected.package in command and "-json" in command and "-count=1" in command
    assert ("-race" in command) == expected.race
    counts: dict[str, Counter[str]] = {
        action: Counter() for action in ("run", "pass", "fail", "skip")
    }
    output: dict[str, list[str]] = defaultdict(list)
    active: set[str] = set()
    started = False
    finished = False
    package_results: list[str] = []
    for line in stdout.read_text().splitlines():
        event = obj(cast("Json", json.loads(line)))
        assert "FailedBuild" not in event
        assert event["Package"] == expected.package
        assert not finished, event
        action = string(event["Action"])
        assert action in {"start", "run", "output", "pass", "fail", "pause", "cont"}
        name = string(event.get("Test", ""))
        if "OutputType" in event:
            assert action == "output"
            assert event["OutputType"] in ("", "frame", "error", "error-continue")
        if action == "start":
            assert not started and not name
            started = True
            continue
        assert started
        if action == "output":
            assert not name or name in active
            output[name].append(string(event["Output"]))
            continue
        if not name:
            assert action in {"pass", "fail"} and not active
            package_results.append(action)
            finished = True
            continue
        assert name in expected.names
        if action == "run":
            assert counts["run"][name] == 0 and name not in active
            active.add(name)
        elif action in {"pass", "fail"}:
            assert name in active
            active.remove(name)
        else:
            assert name in active
            continue
        counts[action][name] += 1
    assert started and finished and not active
    outcome = "fail" if expected.negative else "pass"
    inventory = Counter(expected.names)
    assert counts["run"] == inventory
    assert counts[outcome] == inventory
    assert not counts["pass" if expected.negative else "fail"]
    assert not counts["skip"]
    assert package_results == [outcome]
    assert not CRASH.search(
        "".join(text for parts in output.values() for text in parts)
    )
    if expected.negative:
        name, diagnostic = expected.negative
        assert diagnostic in "".join(output[name]), expected
    return {
        "group": expected.group,
        "phase": expected.label,
        "expected_named_tests": len(expected.names),
        "named_events": {
            key: {name: number for name, number in value.items()}
            for key, value in counts.items()
        },
        "package_starts": 1,
        "package_results": list(package_results),
        "exit_code": status["exit_code"],
        "timed_out": False,
        "stderr_bytes": 0,
        "hashes_match": True,
        "diagnostic_matches": True,
        "event_lifetimes_valid": True,
        "race": expected.race,
        "accepted": True,
    }


def main() -> None:
    base = ROOT / "unit-artifact/logos-regression-evidence"
    existing = read(ROOT / "expected-existing-inventories.json")
    new = read(ROOT / "expected-new-slice-inventories.json")
    assert existing["head"] == new["head"] == HEAD
    phases = [
        phase(obj(item), string(obj(item)["group"])) for item in arr(existing["phases"])
    ]
    inputs: dict[str, dict[str, Json]] = {}
    for item in arr(new["slices"]):
        data = obj(item)
        group = GROUPS[string(data["slice"])]
        phases.extend(phase(obj(value), group) for value in arr(data["phases"]))
        inputs[group] = obj(data["inputs"]) | obj(data["observed"])
    assert len(phases) == 18
    results = [audit_phase(expected, base) for expected in phases]
    identities: dict[str, Json] = {}
    common_tools: dict[str, Json] | None = None
    for group in sorted({item.group for item in phases}):
        before = read(base / group / "before.json")
        assert before == read(base / group / "after.json")
        source = obj(before["source"]) if group == "tagged-package" else before
        assert source["head"] == HEAD and source["tree"] == TREE
        assert source["source_tree"] == SRC
        if "tracked_status" in source:
            assert source["tracked_status"] == ""
        hashes = obj(before["tools"] if group == "tagged-package" else before["sha256"])
        tool_hashes = {path: hashes[path] for path in TOOLS}
        if common_tools is None:
            common_tools = tool_hashes
        assert tool_hashes == common_tools
        for path, digest in inputs.get(group, {}).items():
            assert hashes[path] == digest, (group, path)
        identities[group] = {
            "head": HEAD,
            "tree": TREE,
            "source_tree": SRC,
            "before_equals_after": True,
            "tool_sha256": tool_hashes,
        }
    report: dict[str, Json] = {
        "run_id": 43972750963,
        "job_id": 133668874185,
        "head": HEAD,
        "all_helper_acceptance_claims_reproduced": True,
        "all_regression_phases_accepted": True,
        "phases": list(results),
        "identities": identities,
        "new_inputs_match_pre_result_catalog": True,
        "scope": "Recorded evidence only; no Go or original acceptance helper executed.",
    }
    target = ROOT / "independent-unit-audit.json"
    text = json.dumps(report, indent=2) + "\n"
    if target.exists():
        assert target.read_text() == text
    else:
        target.write_text(text)
    print(json.dumps({"accepted_phases": len(results), "report_sha256": sha(target)}))


if __name__ == "__main__":
    main()
