# Corrected native evidence bundle: run 43972750963

**The exact corrected native candidate passes all three jobs and the independent evidence audit.** [Run 43972750963](https://github.com/gosuda/LoGOs/actions/runs/43972750963) completed successfully at 2026-11-16 23:32:31 UTC for [PR76](https://github.com/gosuda/LoGOs/pull/76).

| Identity | Value |
|---|---|
| Head | `6c53eb629a0f572db7ce157372005e0fa2089d1d` |
| Root tree | `616b5421bc6912783762783b2ca681cacd50c105` |
| Source tree | `6a650366141c23a154f6e0b153767527e520a58f` |
| Top-level fixture tree | `a64f88184df739e681c29c83e059d44ab6fda7bd` |
| Run attempt | 1 |

## Completed acceptance

| Job | ID | Result | Completion time, UTC | Audit |
|---|---|---|---|---|
| Unit | `133668874185` | Success | 23:02:00 | [Unit audit](UNIT_AUDIT.md) |
| Scripts | `133668874024` | Success | 23:17:40 | [Scripts audit](SCRIPTS_AUDIT.md) |
| Upstream | `133668873658` | Success | 23:32:31 | [Upstream audit](UPSTREAM_AUDIT.md) |

All 18 exact unit regression phases pass their intended acceptance checks. The zero-array old-code controls produce exactly 3 and 2 named failures; the corrected classification and mutation-facts candidates produce exactly 67 and 15 named passes. The field-offset, SIMD import, tagged package/method and explicit Wasm inventories also match exactly. Intentional archived-code failures remain visible in their raw event streams and are distinguished from candidate outcomes.

The complete LoGOs script subset passes, followed by the installed subprocess race checks. The inline-capability proof retains exactly two archived-linker failures and two candidate passes, with the expected child-owned diagnostic and verified linker restoration.

The full upstream inventory contains 666 unique registered names. The three disjoint partitions contain 664 complement names, one complete testdir shard and one complete cmd/go entry. All driver and console-capture exits are zero; all partitions report success. Source and fixture identities remain unchanged, and all six executable hashes match before and after. The complete types2 package passes, closing the earlier fixture build failure.

## Original failure remains separate

The original f424 run `43967559240` remains a failed run, preserved in its own deterministic bundle. Its zero-array fixture used two nonexistent compiler-internal `.Complete()` calls. The corrected source-tree delta is [the exact two-call suffix removal](source-only.patch); production code, test names, type expectations and mutation-mask assertions remain unchanged. Installed binaries match the original run byte-for-byte. No corrected result is substituted into the original archive.

## Retained provenance

This payload includes all three complete decoded API job logs, final run/job/artifact API metadata, original artifact ZIPs, every extracted artifact file, pre-result expected inventories, exact selected helper/source copies with remote Git-blob verification, independent audit reports and replay scripts, and before/after source/test/tool receipts. Raw logs were read back against their complete API text. Every ZIP size and digest matches GitHub metadata, and every extracted payload was read back and hashed.

| Original artifact | ID | Bytes | SHA-256 |
|---|---:|---:|---|
| `logos-unit-43972750963-1.zip` | 14279513848 | 78,697 | `2d17b4e8030c5709bdcc2d7ba853957dd9a14f2952a91bf0b21e152543b620e3` |
| `logos-scripts-43972750963-1.zip` | 14281113330 | 16,888 | `e449417bfc194a7320445841e5b204f06fe4f9a1937bb803912d9f7195e2aaf1` |
| `logos-upstream-43972750963-1.zip` | 14282698579 | 24,505 | `e75b50770f3f8e51f750424552bab3c75cc169a367e6119e82af7851be46571e` |

The independent reviewer recounted all 18 unit JSONL streams, checked unit/scripts raw logs and ZIP receipts, verified final completion timestamps, and compared the source patch against the exact Git-tree diff. The recorded unit and scripts audit documents passed that read-only review. All three local evidence replay scripts pass strict Pyright and Ruff checks and execute no Go command.

## Reproduce the evidence audit

From the extracted bundle directory, with Python 3.12 available:

```sh
PYTHONDONTWRITEBYTECODE=1 uv run --no-project --no-config --python 3.12 --no-python-downloads python audit_unit.py
PYTHONDONTWRITEBYTECODE=1 uv run --no-project --no-config --python 3.12 --no-python-downloads python audit_scripts.py
PYTHONDONTWRITEBYTECODE=1 uv run --no-project --no-config --python 3.12 --no-python-downloads python audit_upstream.py
uv run --no-project --no-config --python 3.12 --no-python-downloads python repack.py
uv run --no-project --no-config --python 3.12 --no-python-downloads python repack.py --output ../native-43972750963-repacked.tar.gz
```

The audit scripts compare any existing report with their recomputed result instead of overwriting it. `SHA256SUMS` covers every other payload file in sorted relative-path order. The repacker verifies that manifest and rejects unexpected, missing, escaping, duplicate, symlinked or hash-mismatched inputs.

The archive uses the single `native-43972750963/` prefix, sorted regular-file entries, mode 0644, zero uid/gid/mtime, empty owner names, and gzip with no filename and zero mtime. The outside-archive receipt records complete member/readback verification and a byte-identical independent repack, including the Python and zlib versions. The archive contains the original ZIP and log bytes unchanged within that normalized container.

Acceptance is scoped to the recorded Linux/amd64 native CI commands and their default platform/short-test behavior. Corpus acceptance is recorded separately, and this bundle makes no claim to have executed unobserved platforms or every repository on every Git service.
