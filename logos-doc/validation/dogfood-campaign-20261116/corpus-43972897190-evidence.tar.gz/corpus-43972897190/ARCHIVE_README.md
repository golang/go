# Corpus evidence archive

Run: 43972897190
Head: `090bac0f2dbb1a1105d4bcb156fc31ed7c025177`
Source tree: `6a650366141c23a154f6e0b153767527e520a58f`

This archive retains both original GitHub artifact ZIPs, their unchanged
extracted contents, the complete UTF-8 job log, source/tool receipts, all reports,
and independent audits. Read FINAL_AUDIT.md and INDEPENDENT_LINT_AUDIT.md first.
The original strict capability denial remains retained. Decorder remains an
explicit incomplete-analysis control. Semantic/C ABI fixture results are
package-level summaries; their source-defined names are not claimed as observed
named events. Later source revisions have separate evidence.

MANIFEST.json lists every other file's size and SHA256. From this directory,
the retained stream and peer-audit manifests can also be checked with:

```sh
sha256sum --check RECORDED_LOGS.sha256
(cd early && sha256sum --check RECORDED_LOGS.sha256)
sha256sum --check INDEPENDENT_LINT_AUDIT.sha256
```

Audit programs retain their original workspace assumptions for re-performing
source comparisons. The raw files and checksum verification are self-contained.
No private work directories, caches, Git checkout metadata, or native executable
binaries are included. Ejected Go source is retained as language-parity evidence.

Tar entries are sorted and use mode0644, uid/gid0, empty owner names, and mtime0.
The gzip timestamp and embedded filename are normalized. Packaging verified all
source bytes again, read back every member, and reproduced the same archive bytes.
