# Accepted corrected corpus run 43972897190

The complete hosted corpus job succeeded on head
`090bac0f2dbb1a1105d4bcb156fc31ed7c025177`, root tree
`bef78b17491bafdaf72f6926cc1482a6d7ff814b`, and native source tree
`6a650366141c23a154f6e0b153767527e520a58f`. The unchanged acceptance contract
accepted all 196 primary cells: 189 successful builds or valid lint reports
across 27 positive cases, plus seven explicitly declared incomplete controls
for decorder. Every separate runtime and parity step also passed.

This is an independently rebuilt and executed result for the corrected head.
Its complete normalized lint diagnostics and its observed named runtime
inventories equal accepted run `43967842639`. The earlier run remains
separately archived on its own source tree; neither result is substituted for
the other.

## Source scope and coverage

The only change under `src/` between the two accepted corpus heads removes two
nonexistent `.Complete()` calls from the synthetic types2 zero-array fixture.
`metadata/SOURCE_DELTA.json` retains the exact GitHub comparison and patch.
Production code, corpus profiles, package patterns, tags, cgo settings, runner,
acceptance checker, reviewed policies, workflow, and gglint pin are unchanged.
The new source receipts identify the corrected head and source digest. All six
recorded native executable hashes equal the preceding run's hashes.

The frozen manifest contains 28 profiles from 26 distinct pinned inputs:
24 real sources and two local fixtures. Hosts include GitHub, GitLab,
Codeberg, SourceHut, and Googlesource. The curated profile labels are seven
popular, 11 reference, and ten stress cases. These are selection labels,
not objective quality rankings of whole projects.

The profiles cover Go-only code, assembly, the `purego` build tag, purego FFI,
cgo, modernc, a cgo-disabled stub, and generated Go. Each matrix case is built
with stock Go, the plain fork, and LoGOs, then analyzed by native lint and
gglint's basic, standard, and strict modes. Every successful lint cell is
repeated, for 108 repeat checks.

| Assessment | Primary cells |
| --- | ---: |
| Successful build | 81 |
| Valid lint report with findings | 98 |
| Valid clean lint report | 10 |
| Declared upstream compilation failure | 1 |
| Candidate build without a successful upstream baseline | 2 |
| Declared lint loading failure | 4 |
| Total | 196 |

All seven incomplete cells are decorder. Its pinned dependency
`golang.org/x/tools@v0.20.0/internal/tokeninternal/tokeninternal.go:64:9` fails
with `invalid array length -delta * delta (constant -256 of type int64)`.
It remains a declared upstream incompatibility control and is not counted as
successfully compiled or completely analyzed code.

The main report SHA256 is
`cd71c87c797b9ee552d386068cee57ba6d0302b1b09fb1effde5630b668b5248`.
The acceptance file binds that report and the unchanged checker SHA256
`56146fab4da8433c4607381190ecc502493092bb4be645d2c2480bb41d387396`.
Its own SHA256 is
`90b7782eae82cbc975c3eb226f8cb615d9f86dbde9bf825e9dcfe565501244bc`.

## Observed backend execution

The audit independently parsed the raw JSON streams. Each row has identical,
nonempty package-qualified run/pass multisets under all three drivers, with no
failed or skipped named test. SQLite and FFI also match their exact expected
test names and packages; the checks do not rely on counts alone.

| Runtime profile | Stock Go | Plain fork | LoGOs |
| --- | ---: | ---: | ---: |
| xxhash assembly core | 159 | 159 | 159 |
| xxhash purego-tag core | 159 | 159 | 159 |
| xxhash cgo plugin | 223 | 223 | 223 |
| mattn SQLite cgo | 3 | 3 | 3 |
| modernc SQLite | 15 | 15 | 15 |
| purego FFI | 8 | 8 | 8 |
| Native-lint runtime controls | 2 | 2 | 2 |

Counts are observed named runs and passes, including subtests, within each
invocation. `CROSS_RUN_RUNTIME_AUDIT.json` records exact equality with run
`43967842639` for all 21 invocations, their commands, working directories,
environments, and complete named inventories. The combined 1,707 runs and
1,707 passes include repeated profiles and drivers; they are not 1,707 unique
tests. `compare_runtime.py` reproduces that comparison without executing Go.

The plugin profile includes `github.com/cespare/xxhash/v2/dynamic/TestDynamic`.
All three drivers inherit `GOEXPERIMENT=none`. The LoGOs host alone receives
`-O=1` and a private `[build] arena = false` configuration, SHA256
`2ae10a1fe10a8e72ac145fc13e7692747bd06c626ec91a403e9c19d4a4a30e21`.
The stock and plain-fork source copies remain pristine. This result validates
the explicit compatible profile; it makes no claim that unconfigured driver
defaults produce interchangeable plugins.

The cgo SQLite tests are `TestOpen`, `TestClose`, and `TestInsert`. Modernc
executes `TestNamedParameters`, `TestMemDB`, `TestBinding`, `TestBeginMode`,
`TestMultiStmtQueryStringRoundtrip`, `TestExecReturningMultiRow`, and
`TestMutexWakeOnce`, together with `TestBinding/DB`, `TestBinding/Prepare`,
and deferred, immediate, and exclusive modes under delete and wal journals.
Only the LoGOs copy receives the reviewed runtime capability policy, SHA256
`5666c90bc1f25d5f0d7d0e5b53e80c2fa8e7ebe341286f7d7b0b1c5651513096`.

The eight FFI tests are `TestCallGoFromSharedLib`, `TestNestedDlopenCall`,
`TestNewCallbackFloat64AndIntMix`, `TestNewCallbackInt64ResultWithStackArgs`,
`TestRegisterFunc_StackAlignment`, `TestRegisterFunc_StackCallback`,
`TestSimpleDlsym`, and `TestSyscallN`.

## Semantic fixtures, language parity, and native lint

The semantic and C ABI fixtures have six successful package-level driver
cells. Every exact command is:

```text
<recorded stock, plain-fork, or LoGOs driver> test -count=1 -short -timeout=595s ./...
```

All six stderr streams are empty. The observed package results are:

| Fixture | Stock Go stdout | Plain fork stdout | LoGOs stdout |
| --- | --- | --- | --- |
| Semantics | `ok  \texample.com/logos-dogfood/semantics\t0.003s` | `ok  \texample.com/logos-dogfood/semantics\t0.003s` | `ok  \texample.com/logos-dogfood/semantics\t0.003s` |
| C ABI | `ok  \texample.com/logos-dogfood/cgo\t0.002s` | `ok  \texample.com/logos-dogfood/cgo\t0.002s` | `ok  \texample.com/logos-dogfood/cgo\t0.002s` |

The table escapes tabs; `FINAL_AUDIT.json` preserves exact command arrays and
raw strings, including the final newline. The commands omit `-json` and `-v`,
so these logs do not record individual named test runs or passes. The rehashed
source defines seven semantic roots and one C ABI root. That static inventory
is stored separately and is excluded from the observed named totals above.

The LoGo program executed successfully, ejection succeeded, and stock Go
executed the ejected source successfully. Both executions printed exactly
`language semantics ok\n`. The retained ejected tree was independently
rehashed and equals the preceding accepted run's tree digest.

Native lint returned exactly three expected diagnostics on both passes:
two `correctness::unclosed_io_closer` findings and one
`correctness::infinite_recursion` finding, including exact spans, messages,
and provenance. Each driver's runtime stream records exactly
`TestExecutedCloseForms` and `TestShadowedPanicReturnsTypedNil` running and
passing.

## Strict tools failure and reviewed build profile

The reviewed `tools-build.toml` profile passed `logos build ./...`, alongside
successful stock and plain-fork builds. Its SHA256 remains
`c57b54d9a78993eac2b2614730cfdf05b12e47c1dbbc77c243f16887d67d7def`.
It preserves the three old unsafe grants and adds only the reviewed two exec
and 14 network package grants. No errgroup grant was added.

The original strict policy remains byte-identical and still denies the build.
The separate `logos build -ldflags=-e ./...` capture retains 48 errors and
78 warnings without diagnostic truncation. Its complete 126 diagnostic blocks,
including full ownership paths, equal the original accepted run's multiset;
only block order differs. The six additional errors exposed by removing the
limit are `syscall.Connect` paths in packages already covered by the reviewed
profile. They use the previously reviewed conservative interface or
error-method reachability and do not establish runtime network activity.

The original failed strict build, its successful stock/plain-fork baselines,
exact policy/source identities, complete trace, and before/after native
receipts remain in the early and full artifacts. No new grant was required.

## Independent diagnostic comparison

`INDEPENDENT_LINT_AUDIT.md` and its JSON record accept exact equality with
run `43967842639` for every complete normalized diagnostic array. All 112
primary lint cells and 108 positive repeats were parsed from raw streams.
All 196 assessment objects, exit statuses, effective input receipts, case
profiles, and source digests also match the preceding accepted run.

The earlier source-backed changes against run `43950476822` remain exactly
13 removed strict gglint `chanblock` findings and two removed native Protobuf
field-offset findings. There are no additions or unexplained changes.
Chi stays at 3/52/101 basic/standard/strict findings; its deferred send remains
reported. Native Protobuf retains all other 480 records. The peer report
preserves every removed location and complete normalized arrays.

The independently built gglint revision remains
`4456e61c4dbdf636fca2b5bd77787873e2d1c1e8`, with recorded executable SHA256
`3ab00d1c9df087cb673cb9014801fc82a4157b9ba14fc02a8afda81f2a4db989`.
Its build/source receipts and all 49 downloaded and 48 linked dependency
checksums agree with the pin. The artifact does not contain executable
binaries; the audit verifies the hosted identity receipts rather than claiming
to rehash a locally retained binary.

## Evidence integrity and limits

The runtime/report audit rehashed 952 distinct stdout/stderr files: 770 replay
streams and 182 preparation streams. It checked 476 recorded process results
for true integer exits, no timeout, and no launch error, and checked 18 native
identity receipts. Source and native tool identities stayed unchanged within
the run. The independent root audit separately rehashed all 770 replay streams,
proved exact 28-by-seven coverage, and compared all 196 assessments and 108
repeat input/assessment pairs. Both original ZIPs and every extracted member
are verified before publication.

| Retained item | Identity |
| --- | --- |
| Complete run / job | `43972897190` / `133669378368` |
| Full artifact | `14281572232`, 1,795,064 bytes, 1,145 entries |
| Full ZIP SHA256 | `f551ab4fdec3f21375fa386b811cb7a1e324e73d85d81934029649da5011f185` |
| Early artifact | `14279877567`, 37,872 bytes, 37 entries |
| Early ZIP SHA256 | `8e4cefd9e1fddc78cf9dce85fb7844ee0204bcbcbeed29afba31ac99657c328d` |
| Complete job log | 81,387 UTF-8 bytes |
| Complete job log SHA256 | `655604e8e5a5323cddeb1e02cb218f33690329b31c68167315fc4a86a9aa26c7` |

No local Go command ran during these audits. All checks operate on retained
hosted results and source/identity receipts. These results establish the stated
finite Linux/amd64 compilation, lint, and selected runtime coverage. They do
not establish whole-project runtime correctness for every input, support for
untested languages or platforms, successful analysis of decorder, or that every
retained lint warning is a real defect.
