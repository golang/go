# pyright: strict
from __future__ import annotations

import hashlib
import json
import sys
from collections import Counter
from pathlib import Path
from typing import cast


def obj(value: object) -> dict[str, object]:
    if not isinstance(value, dict):
        raise TypeError("expected an object")
    return cast(dict[str, object], value)


def rows(value: object) -> list[dict[str, object]]:
    if not isinstance(value, list):
        raise TypeError("expected an object array")
    return [obj(item) for item in cast(list[object], value)]


def read(path: Path) -> dict[str, object]:
    return obj(json.loads(path.read_text()))


def local(root: Path, value: object) -> Path:
    assert isinstance(value, str) and value.startswith("/home/runner/work/")
    return root / "full/artifact" / value.removeprefix("/home/runner/work/")


def named(root: Path, execution: dict[str, object]) -> Counter[tuple[str, str, str]]:
    path = local(root, execution["stdout"])
    assert hashlib.sha256(path.read_bytes()).hexdigest() == execution["stdout_sha256"]
    result: Counter[tuple[str, str, str]] = Counter()
    for line in path.read_text().splitlines():
        event = obj(json.loads(line))
        if "Test" in event:
            assert event["Action"] not in ("skip", "fail")
            if event["Action"] in ("run", "pass"):
                result[
                    (
                        cast(str, event["Package"]),
                        cast(str, event["Test"]),
                        cast(str, event["Action"]),
                    )
                ] += 1
    assert result and all(value == 1 for value in result.values())
    return result


def main(reference: Path, candidate: Path) -> None:
    left_audit = read(reference / "FINAL_AUDIT.json")
    right_audit = read(candidate / "FINAL_AUDIT.json")
    assert left_audit["accepted"] is True and right_audit["accepted"] is True
    assert left_audit["run_id"] == 43967842639 and right_audit["run_id"] == 43972897190
    paired: list[dict[str, object]] = []
    for part in ("backends", "ffi", "lint"):
        suffix = (
            Path("full/artifact/_temp/logos-corpus-evidence") / part / "report.json"
        )
        left, right = read(reference / suffix), read(candidate / suffix)
        assert left["runner_sha256"] == right["runner_sha256"]
        if part == "backends":
            pairs: list[tuple[str, dict[str, object], dict[str, object]]] = []
            for old, new in zip(rows(left["cases"]), rows(right["cases"]), strict=True):
                assert old["profile"] == new["profile"]
                assert old["source_digest"] == new["source_digest"]
                case_id = cast(str, obj(obj(old["profile"])["case"])["id"])
                pairs.extend(
                    (case_id, a, b)
                    for a, b in zip(
                        rows(old["stages"]), rows(new["stages"]), strict=True
                    )
                )
        else:
            assert left["source_digest"] == right["source_digest"]
            assert left["replay_sha256"] == right["replay_sha256"]
            pairs = [
                (part, a, b)
                for a, b in zip(rows(left["rows"]), rows(right["rows"]), strict=True)
                if part != "lint" or cast(str, a["label"]).startswith("runtime-")
            ]
        for case_id, old, new in pairs:
            key = "label" if part == "lint" else "stage"
            assert old[key] == new[key]
            before, after = obj(old["run"]), obj(new["run"])
            assert before["returncode"] == after["returncode"] == 0
            for field in ("command", "cwd", "environment"):
                assert before[field] == after[field]
            old_names, new_names = named(reference, before), named(candidate, after)
            assert old_names == new_names
            inventory = [
                {"package": package, "test": test, "action": action, "count": count}
                for (package, test, action), count in sorted(new_names.items())
            ]
            paired.append(
                {
                    "profile": case_id,
                    "stage": old[key],
                    "named_runs": sum(
                        count
                        for (_, _, action), count in new_names.items()
                        if action == "run"
                    ),
                    "named_passes": sum(
                        count
                        for (_, _, action), count in new_names.items()
                        if action == "pass"
                    ),
                    "inventory": inventory,
                }
            )
    assert len(paired) == 21
    for part in ("fixtures", "language"):
        suffix = (
            Path("full/artifact/_temp/logos-corpus-evidence") / part / "report.json"
        )
        left, right = read(reference / suffix), read(candidate / suffix)
        assert left["runner_sha256"] == right["runner_sha256"]
        if part == "language":
            assert left["source_digest"] == right["source_digest"]
            assert left["ejected_digest"] == right["ejected_digest"]
        else:
            for old, new in zip(rows(left["cases"]), rows(right["cases"]), strict=True):
                assert (
                    old["case"] == new["case"]
                    and old["source_digest"] == new["source_digest"]
                )
    result = {
        "reference_run": left_audit["run_id"],
        "candidate_run": right_audit["run_id"],
        "reference_head": left_audit["head"],
        "candidate_head": right_audit["head"],
        "accepted": True,
        "compared_named_test_invocations": len(paired),
        "named_runs_per_complete_replay": sum(
            cast(int, row["named_runs"]) for row in paired
        ),
        "named_passes_per_complete_replay": sum(
            cast(int, row["named_passes"]) for row in paired
        ),
        "fixture_named_execution_claimed": False,
        "rows": paired,
    }
    (candidate / "CROSS_RUN_RUNTIME_AUDIT.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print(
        json.dumps(
            {key: value for key, value in result.items() if key != "rows"}, indent=2
        )
    )


if __name__ == "__main__":
    main(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
