from __future__ import annotations

import base64
import hashlib
import json
import re
import sys
from collections import Counter
from pathlib import Path
from typing import cast

HELPERS = Path("/workspace/scratch/d8d410ec882d/logos-stability-final/misc/logos-dogfood")
sys.path.insert(0, str(HELPERS))
from run import Case

Pair = tuple[str, str]
CELLS = (("oracle", ""), ("go", ""), ("logos", ""), ("logos-lint", ""),
         ("gglint", "basic"), ("gglint", "standard"), ("gglint", "strict"))
FFI_NAMES = {"TestCallGoFromSharedLib", "TestNestedDlopenCall",
             "TestNewCallbackFloat64AndIntMix", "TestNewCallbackInt64ResultWithStackArgs",
             "TestRegisterFunc_StackAlignment", "TestRegisterFunc_StackCallback",
             "TestSimpleDlsym", "TestSyscallN"}
SQL_NAMES = {"TestNamedParameters", "TestMemDB", "TestBinding", "TestBeginMode",
             "TestMultiStmtQueryStringRoundtrip", "TestExecReturningMultiRow", "TestMutexWakeOnce",
             "TestBinding/DB", "TestBinding/Prepare",
             *(f"TestBeginMode/{journal}/{mode}" for journal in ("delete", "wal")
               for mode in ("deferred", "immediate", "exclusive"))}


def obj(value: object) -> dict[str, object]:
    if not isinstance(value, dict):
        raise TypeError("expected an object")
    return cast(dict[str, object], value)


def rows(value: object) -> list[dict[str, object]]:
    if not isinstance(value, list):
        raise TypeError("expected an object array")
    return [obj(item) for item in cast(list[object], value)]


def read(path: Path) -> dict[str, object]:
    return obj(json.loads(path.read_text()))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def content_sum(path: Path) -> str:
    digest = hashlib.sha256()
    for file in sorted(item for item in path.rglob("*") if item.is_file()):
        assert not file.is_symlink()
        relative = file.relative_to(path).as_posix()
        assert "\n" not in relative
        digest.update(f"{sha(file)}  {relative}\n".encode())
    return "h1:" + base64.b64encode(digest.digest()).decode()


def stable(value: object) -> object:
    if isinstance(value, dict):
        return {key: stable(child) for key, child in obj(value).items()
                if key not in ("run", "version_run")}
    if isinstance(value, list):
        return [stable(child) for child in cast(list[object], value)]
    return value


def main(root: Path) -> None:
    artifact = root / "full/artifact"
    evidence = artifact / "_temp/logos-corpus-evidence"
    metadata = read(root / "metadata/initial.json")
    reports = {name: read(evidence / name / "report.json") for name in
               ("corpus", "fixtures", "backends", "ffi", "language", "lint", "tools-probe", "tools-unlimited")}
    preparation = read(artifact / "_temp/logos-corpus-inputs/preparation.json")
    early = read(root / "early/artifact/tools-unlimited/report.json")
    native = obj(obj(early["native_before"])["toolchain"])
    checked: dict[str, str] = {}
    native_receipts = 0
    process_receipts = 0

    def local(value: object) -> Path:
        assert isinstance(value, str) and value.startswith("/home/runner/work/")
        result = artifact / value.removeprefix("/home/runner/work/")
        assert result.resolve().is_relative_to(artifact.resolve())
        return result

    def scan(value: object) -> None:
        nonlocal native_receipts, process_receipts
        if isinstance(value, dict):
            record = obj(value)
            for stream in ("stdout", "stderr"):
                if stream in record and f"{stream}_sha256" in record:
                    path = local(record[stream])
                    digest = sha(path)
                    assert digest == record[f"{stream}_sha256"], path
                    checked[path.relative_to(artifact).as_posix()] = digest
            if "command" in record and "returncode" in record:
                process_receipts += 1
                assert type(record["returncode"]) is int and record["returncode"] in (0, 1)
                assert record["timed_out"] is False and record["error"] == ""
            if record.get("goroot") == "/home/runner/work/LoGOs/LoGOs" and "tools" in record:
                native_receipts += 1
                assert record["source_revision"] == metadata["head"]
                assert record["source_status"] == ""
                assert record["compiler_source_h1"] == native["compiler_source_h1"]
                assert record["tools"] == native["tools"]
            for child in record.values():
                scan(child)
        elif isinstance(value, list):
            for child in cast(list[object], value):
                scan(child)

    for report in (*reports.values(), preparation):
        assert report["complete"] is True
        scan(report)

    def events(execution: dict[str, object]) -> Counter[Pair]:
        assert execution["returncode"] == 0
        started: Counter[Pair] = Counter()
        passed: Counter[Pair] = Counter()
        for line in local(execution["stdout"]).read_text().splitlines():
            event = obj(json.loads(line))
            action = event["Action"]
            assert action in {"start", "run", "output", "pass", "skip", "pause", "cont", "build-output"}
            assert "FailedBuild" not in event
            if "Test" in event:
                name, package = event["Test"], event["Package"]
                assert isinstance(name, str) and name
                assert isinstance(package, str) and package
                assert action != "skip"
                if action == "run":
                    started[(package, name)] += 1
                if action == "pass":
                    passed[(package, name)] += 1
        assert started and started == passed
        assert all(count == 1 for count in started.values())
        return started

    corpus = reports["corpus"]
    acceptance = read(evidence / "corpus/acceptance.json")
    assert acceptance["accepted"] is True
    assert acceptance["report_sha256"] == sha(evidence / "corpus/report.json")
    assert acceptance["checker_sha256"] == sha(HELPERS / "accept_corpus.py")
    assert corpus["runner_sha256"] == sha(HELPERS / "run.py")
    manifest = artifact / "LoGOs/LoGOs/misc/logos-dogfood/corpus-ci.json"
    assert corpus["manifest_sha256"] == sha(manifest) == sha(HELPERS / "corpus-ci.json")
    frozen_cases = [Case.parse(value) for value in cast(list[object], json.loads(manifest.read_text()))]
    assert len(frozen_cases) == 28 and corpus["case_count"] == 28
    assert corpus["operation_override"] == "build"
    counts: Counter[str] = Counter()
    repeat_count = 0
    source_map = {case_id: source["source_digest"] for source in rows(preparation["sources"])
                  for case_id in cast(list[str], source["case_ids"])}
    assert preparation["source_count"] == 26 and preparation["case_count"] == 28
    assert all(source["status"] == "ready" for source in rows(preparation["sources"]))
    driver_paths = {name: obj(value)["path"] for name, value in obj(corpus["tools"]).items()}
    for row, case in zip(rows(corpus["cases"]), frozen_cases, strict=True):
        assert Case.parse(row["case"]) == case and row["status"] == "finished"
        assert row["source_digest"] == source_map[case.id]
        if case.logos_policy:
            saved = obj(row["logos_policy"])
            assert saved["sha256"] == case.logos_policy_sha256 == sha(local(saved["saved_path"]))
        stage_rows = rows(row["stages"])
        assert tuple((item["stage"], item["mode"]) for item in stage_rows) == CELLS
        for item in stage_rows:
            stage, mode = cast(str, item["stage"]), cast(str, item["mode"])
            execution = obj(item["run"])
            status = cast(str, obj(item["assessment"])["status"])
            counts[status] += 1
            env = obj(execution["environment"])
            assert env["CGO_ENABLED"] == str(case.cgo)
            assert env["GOFLAGS"] == "-mod=readonly -buildvcs=false -p=2"
            assert "GOEXPERIMENT" not in env
            assert execution["cwd"] == "/home/runner/work/_temp/logos-corpus-evidence/corpus/work/" + case.id
            if stage in ("oracle", "go", "logos"):
                flags = [f"-tags={','.join(case.tags)}"] if case.tags else []
                assert execution["command"] == [driver_paths[stage], "build", *flags, *case.patterns]
            if case.id == "decorder":
                assert status in {"load-failed", "upstream-failed", "uncompared"}
                assert execution["returncode"] == 1 and "repeat" not in item
            else:
                assert status in {"pass", "clean", "findings"}
                if stage in ("logos-lint", "gglint"):
                    repeat_count += 1
                    repeat = obj(item["repeat"])
                    assert item["inputs"] == item["repeat_inputs"]
                    assert all(execution[key] == repeat[key] for key in ("command", "cwd", "environment"))
                else:
                    assert execution["returncode"] == 0
    assert repeat_count == 108
    assert dict(counts) == corpus["counts"] == acceptance["counts"]
    assert sum(counts.values()) == 196
    assert acceptance["known_failed_load_cells"] == 7
    assert acceptance["incomplete_analysis_cases"] == ["decorder"]

    backend = reports["backends"]
    assert backend["accepted"] is True and backend["unchanged"] is True
    assert backend["source_before"] == backend["source_after"] == {
        "revision": metadata["head"], "src_status": "", "src_tree": metadata["source_tree"]}
    assert stable(backend["tools_before"]) == stable(backend["tools_after"])
    expected_counts = {"xxhash-asm-core": 159, "xxhash-purego-core": 159,
                       "xxhash-plugin-cgo": 223, "sqlite3-cgo": 3, "modernc-sqlite": 15}
    runtime: dict[str, object] = {}
    for row in rows(backend["cases"]):
        case = obj(obj(row["profile"])["case"])
        name, module = cast(str, case["id"]), cast(str, case["module"])
        assert row["accepted"] is True and row["source_digest"] == row["source_after_digest"]
        previous: Counter[Pair] | None = None
        observed: dict[str, object] = {}
        assert [stage["stage"] for stage in rows(row["stages"])] == ["oracle", "go", "logos"]
        for stage in rows(row["stages"]):
            label = cast(str, stage["stage"])
            assert stage["accepted"] is True and stage["event_error"] == ""
            execution = obj(stage["run"])
            actual = events(execution)
            assert len(actual) == expected_counts[name]
            saved = obj(stage["events"])
            assert Counter(tuple(pair) for pair in cast(list[list[str]], saved["started"])) == actual
            assert Counter(tuple(pair) for pair in cast(list[list[str]], saved["passed"])) == actual
            assert saved["failures"] == [] and saved["skips"] == []
            if previous is not None:
                assert actual == previous
            previous = actual
            if name == "modernc-sqlite":
                assert set(actual) == {(module, value) for value in SQL_NAMES}
                if label == "logos":
                    assert obj(stage["preparation"])["policy_sha256"] == "5666c90bc1f25d5f0d7d0e5b53e80c2fa8e7ebe341286f7d7b0b1c5651513096"
            elif name == "sqlite3-cgo":
                assert set(actual) == {(module, value) for value in ("TestOpen", "TestClose", "TestInsert")}
            else:
                assert (module, "TestAll") in actual
            env = obj(execution["environment"])
            argv = cast(list[str], execution["command"])
            inputs = obj(stage["preparation"])
            if name == "xxhash-plugin-cgo":
                assert (module + "/dynamic", "TestDynamic") in actual
                assert env["GOEXPERIMENT"] == "none"
                assert ("-O=1" in argv) == (label == "logos")
                if label == "logos":
                    assert inputs["plugin_config_content"] == "[build]\narena = false\n"
                    assert inputs["plugin_config_sha256"] == "2ae10a1fe10a8e72ac145fc13e7692747bd06c626ec91a403e9c19d4a4a30e21"
                else:
                    assert inputs == {"effective_source_digest": row["source_digest"]}
            else:
                assert "GOEXPERIMENT" not in env and "plugin_config_content" not in inputs
            observed[label] = {"named_runs": len(actual), "named_passes": len(actual),
                               "seconds": execution["seconds"], "command": argv}
        runtime[name] = observed

    ffi = reports["ffi"]
    assert ffi["source_revision"] == metadata["head"]
    for row in rows(ffi["rows"]):
        actual = events(obj(row["run"]))
        assert row["status"] == "pass" and row["exact_execution"] is True
        assert len(actual) == 8 and {name for _, name in actual} == FFI_NAMES
        assert set(actual) == {(cast(str, obj(ffi["case"])["module"]), name) for name in FFI_NAMES}
        assert row["failed_or_skipped"] == []
    fixtures = reports["fixtures"]
    assert fixtures["counts"] == {"pass": 6}
    static_fixture_inventory: dict[str, list[str]] = {}
    fixture_driver_receipts: list[dict[str, object]] = []
    for row in rows(fixtures["cases"]):
        case = obj(row["case"])
        source = HELPERS / cast(str, case["source"])
        assert content_sum(source) == row["source_digest"]
        static_fixture_inventory[cast(str, case["id"])] = sorted(
            name for path in source.rglob("*_test.go")
            for name in re.findall(r"(?m)^func (Test\w+)\(t \*testing\.T\)", path.read_text()))
        for stage in rows(row["stages"]):
            execution = obj(stage["run"])
            assert execution["returncode"] == 0
            assert execution["command"] == [driver_paths[cast(str, stage["stage"])], "test", "-count=1", "-short", "-timeout=595s", "./..."]
            assert obj(stage["assessment"])["status"] == "pass"
            assert re.fullmatch(r"ok\s+" + re.escape(cast(str, case["module"])) + r"\s+[0-9.]+s\s*", local(execution["stdout"]).read_text())
            fixture_driver_receipts.append({
                "case": case["id"], "stage": stage["stage"], "command": execution["command"],
                "stdout": local(execution["stdout"]).read_text(),
                "stderr": local(execution["stderr"]).read_text(),
                "returncode": execution["returncode"],
            })
            assert fixture_driver_receipts[-1]["stderr"] == ""
    language = reports["language"]
    assert language["source_revision"] == metadata["head"]
    assert content_sum(evidence / "language/ejected") == language["ejected_digest"]
    for row in rows(language["rows"]):
        assert row["status"] == "pass" and obj(row["run"])["returncode"] == 0
        if row["label"] != "eject":
            assert local(obj(row["run"])["stdout"]).read_bytes() == b"language semantics ok\n"
    lint = reports["lint"]
    expected_lint = json.loads((evidence / "lint/expected.json").read_text())
    for row in rows(lint["rows"]):
        execution = obj(row["run"])
        assert row["status"] == "pass"
        if cast(str, row["label"]).startswith("runtime-"):
            actual = events(execution)
            assert len(actual) == 2
            assert {package for package, _ in actual} == {"example.com/logos-dogfood/lint"}
            assert {name for _, name in actual} == {"TestExecutedCloseForms", "TestShadowedPanicReturnsTypedNil"}
        else:
            assert execution["returncode"] == 1 and row["exact_match"] is True
            actual_records = [obj(json.loads(line)) for line in local(execution["stderr"]).read_text().splitlines()]
            for record in actual_records:
                record["file"] = Path(cast(str, record["file"])).name
            assert actual_records == expected_lint
    assert (evidence / "tools-probe/report.json").read_bytes() == (root / "early/artifact/tools-probe/report.json").read_bytes()
    assert (evidence / "tools-unlimited/report.json").read_bytes() == (root / "early/artifact/tools-unlimited/report.json").read_bytes()
    assert "4456e61c4dbdf636fca2b5bd77787873e2d1c1e8" in (evidence / "gglint-source.txt").read_text()
    gglint_sha = cast(str, obj(obj(corpus["tools"])["gglint"])["sha256"])
    assert (evidence / "gglint.sha256").read_text().split()[0] == gglint_sha
    assert "vcs.revision=4456e61c4dbdf636fca2b5bd77787873e2d1c1e8" in (evidence / "gglint-build-info.txt").read_text()
    result: dict[str, object] = {
        "run_id": metadata["run_id"], "head": metadata["head"], "tree": metadata["tree"],
        "source_tree": metadata["source_tree"], "accepted": True,
        "case_count": 28, "distinct_inputs": 26, "primary_cells": 196,
        "accepted_positive_cases": 27, "known_incomplete_case": "decorder",
        "counts": dict(counts), "lint_repeats": repeat_count,
        "raw_streams_rehashed": len(checked), "process_receipts_checked": process_receipts,
        "native_identity_receipts_checked": native_receipts,
        "source_and_native_tools_stable": True,
        "preparation_commands": len(rows(preparation["commands"])),
        "runtime": runtime, "ffi_named_runs_and_passes_per_driver": 8,
        "semantic_and_c_abi_driver_cells": 6, "language_rows_passed": 3,
        "fixture_named_test_execution_observed": False,
        "fixture_output_kind": "package summaries only; no -json or -v",
        "fixture_static_test_inventory": static_fixture_inventory,
        "fixture_driver_receipts": fixture_driver_receipts,
        "exact_native_lint_diagnostic_runs": 2, "native_lint_runtime_tests_per_driver": 2,
        "tools_reviewed_profile_build_passed": True,
        "gglint_revision": "4456e61c4dbdf636fca2b5bd77787873e2d1c1e8",
        "gglint_sha256": gglint_sha,
        "reports": {name: sha(evidence / name / "report.json") for name in reports},
        "preparation_report_sha256": sha(artifact / "_temp/logos-corpus-inputs/preparation.json"),
        "acceptance_sha256": sha(evidence / "corpus/acceptance.json"),
        "job_log_sha256": sha(root / "full/corpus-job.raw.log"),
        "job_log_bytes": (root / "full/corpus-job.raw.log").stat().st_size,
        "limits": ["Decorder remains an explicitly declared upstream loading incompatibility.",
                   "Compilation and valid lint reports do not establish whole-project runtime correctness.",
                   "Semantic and C ABI fixtures have successful package summaries but no observed per-test events.",
                   "Plugin runtime uses the documented compatible profile.",
                   "These results apply to the exact recorded revision and source tree."]}
    (root / "FINAL_AUDIT.json").write_text(json.dumps(result, indent=2) + "\n")
    (root / "RECORDED_LOGS.sha256").write_text("".join(f"{digest}  full/artifact/{path}\n" for path, digest in sorted(checked.items())))
    print(json.dumps({key: value for key, value in result.items() if key not in ("runtime", "reports", "limits")}, indent=2))


if __name__ == "__main__":
    main(Path(sys.argv[1]).resolve())
