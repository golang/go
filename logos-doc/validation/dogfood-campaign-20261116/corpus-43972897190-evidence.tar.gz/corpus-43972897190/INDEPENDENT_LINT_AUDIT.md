# Independent final lint audit: corpus run 43972897190

## Disposition

Accepted. The complete normalized diagnostic arrays for corrected run
`43972897190` are exactly equal to accepted run `43967842639`. There is no added,
removed, or otherwise changed diagnostic between those two runs. The earlier
source-backed 13 gglint removals and two Protobuf removals against baseline
`43950476822` therefore remain intact, with no new unexplained change.

This is a read-only audit of retained matrix streams, invocation/source/tool
receipts, and diagnostic equality. It executed no Go, changed no repository
source, and left the downloaded artifact unchanged. Runtime and whole-job
audits are recorded separately in this evidence bundle.

## Exact identities

| Input | Identity |
| --- | --- |
| Corrected corpus head | `090bac0f2dbb1a1105d4bcb156fc31ed7c025177` |
| Corrected root tree | `bef78b17491bafdaf72f6926cc1482a6d7ff814b` |
| Corrected source tree | `6a650366141c23a154f6e0b153767527e520a58f` |
| Comparison head | `3b2073eb98e488c411f52ba7cd723e8622c8cdfe` |
| Comparison source tree | `ee5ae95824022485b74d4e3186a1540ef7124f76` |
| Rebuilt gglint head | `4456e61c4dbdf636fca2b5bd77787873e2d1c1e8` |
| gglint root tree | `dfb46c72af5ce9695844c5d567cbb8aab1568183` |

The source-only difference is the two `.Complete()` suffix removals in
`referencefree_zero_array_logos_test.go`. Production code, corpus manifest,
package patterns, tags, cgo settings, reviewed policies, runner, acceptance
checker, corpus workflow, and gglint pin are unchanged. The corrected source
receipt and native toolchain metadata identify the actual corrected head;
the comparison result is not inferred merely from this source difference.

Artifact `14281572232`, `dogfood-43972897190-1.zip`, is 1,795,064 bytes with
SHA-256 `f551ab4fdec3f21375fa386b811cb7a1e324e73d85d81934029649da5011f185`.
All 1,145 extracted files were independently compared byte-for-byte with their
original ZIP members. The corrected corpus report SHA-256 is
`cd71c87c797b9ee552d386068cee57ba6d0302b1b09fb1effde5630b668b5248`.

## Complete matrix checks

- Both reports contain exactly 28 finished cases, 26 source inputs, and all
  196 primary build/lint cells.
- All 112 primary lint cells were independently parsed from their raw streams.
  Each of the 108 positive lint cells has an exact matching repeat, for 220
  lint invocations including the four explicit incomplete controls.
- All 608 matrix stdout/stderr hashes in each report were recomputed. Exact
  diagnostic fields and types, nested fixes and related information, package
  banners, config notices, duplicate JSON keys, and exit contracts were checked.
- Every command was bound to its private source copy, requested mode, full
  package patterns, tags, cgo setting, readonly/offline flags, Go driver, and
  gglint `tests = true` configuration. Repeat commands, environment, input
  identities, and exit statuses match.
- All 196 assessment objects, process exits, and effective input receipts
  match the preceding accepted run. All case profiles and source digests also
  match exactly.
- Every complete normalized diagnostic multiset matches across runs. Sorting
  removes incidental record order only; full fields and duplicate multiplicity
  are preserved. Every positive cell has zero duplicate findings.

The resulting primary counts remain 81 successful builds, 98 valid lint cells
with findings, 10 valid clean lint cells, one declared upstream compilation
failure, two uncompared candidate builds, and four incomplete lint cells.
The seven incomplete cells all belong to decorder and retain the pinned
x/tools v0.20.0 negative-array-length incompatibility. They are not accepted
as successful compilation or complete analysis.

## Preserved changes against the older baseline

The preceding independent audit's JSON hash is
`5fef3826905ea6910b632e33a03ad3c1ad6487806443816f21636eb680cfe10f`.
That file was rehashed, and its full normalized arrays were compared directly
with this audit's arrays. The equality carries forward its independently
reviewed source contexts and exact removed records:

| Cell | Older baseline | Both accepted replays | Preserved removal |
| --- | ---: | ---: | --- |
| Chi, gglint strict | 102 | 101 | `middleware/throttle.go:95:17` |
| modernc SQLite, gglint strict | 775 | 773 | `stmt.go:101:9`, `:294:9` |
| TOML, gglint strict | 125 | 124 | `lex.go:82:16` |
| x/tools, gglint strict | 3,970 | 3,963 | Seven direct select/default communications |
| modernc libc, gglint strict | 5,634 | 5,632 | `libc_musl.go:357:8`, `:475:14` |
| Protobuf, native lint | 482 | 480 | `internal/impl/presence.go:110:8`, `:137:8` |

The x/tools locations are `go/ssa/task.go:40:7`,
`internal/gopathwalk/walk.go:315:10`, `internal/jsonrpc2_v2/conn.go:121:7`,
`:270:8`, `:394:7`, `:404:7`, and `internal/jsonrpc2_v2/net.go:102:7`.
All 13 gglint removals are direct communications in selects with default cases.
Chi's deferred send at line 97 and x/tools' nested deferred receive at
`walk.go:321` remain reported. Chi basic/standard stay at 3/52.

Protobuf preserves all other 480 native findings, including their complete
metadata. Its two removed records remain the frozen same-object field-offset
warnings. Its three build stages passed in the older baseline as well; this
is a lint precision correction. Every other full diagnostic multiset remains
unchanged from baseline `43950476822`.

## Rebuilt executable and dependency receipts

The corrected gglint source/tree receipt and Go 1.27.4 version/build information
match the pinned source. Its build info is byte-identical to the preceding
accepted corpus build and records trimpath and `vcs.modified=false`.
All 49 downloaded module checksums match the committed `go.sum`, and all 48
linked dependency checksums match those downloads. Its recorded binary SHA-256
is unchanged:

```text
3ab00d1c9df087cb673cb9014801fc82a4157b9ba14fc02a8afda81f2a4db989
```

The checksum receipt and replay metadata agree. The executable is absent from
the artifact, so this check binds the retained hosted receipts rather than
claiming a local rehash of that executable. All six native executable receipts
and the stock-Go tool receipts also match the preceding run. The corrected raw
job log is retained with SHA-256
`655604e8e5a5323cddeb1e02cb218f33690329b31c68167315fc4a86a9aa26c7`.

## Reproduction

`audit_lint.py` is a byte-identical copy of the previously reviewed audit script,
SHA-256 `984f62927db6f15f5be8b1680a61f5a9f4e4657bf3e79ee5808c545aacb1b879`.
Its strict Pyright/Ruff-verified code was not changed for this comparison.
The following is the recorded local invocation from this evidence directory.
The workspace path identifies the retained local checkout layout; it is not a
generally available external path. Reproduction elsewhere requires the two
extracted evidence directories and an equivalent reviewed source checkout
layout, including `gglint-chanblock-default` at the recorded tree, with the
workspace argument adjusted accordingly.

```sh
uv run --offline --no-project --no-config --python 3.12 --no-python-downloads \
  python audit_lint.py \
  --baseline ../corpus-43967842639/full/artifact/_temp/logos-corpus-evidence \
  --candidate full/artifact/_temp/logos-corpus-evidence \
  --workspace /workspace/scratch/d8d410ec882d \
  --output INDEPENDENT_LINT_AUDIT.json --expect-equal
```

The JSON retains all corrected normalized arrays, both reports' checked stream
hashes, an empty diagnostic-change list, and the tool/dependency receipts.
`INDEPENDENT_LINT_AUDIT.sha256` binds the report, this note, and the audit script.
This evidence establishes the specified finite Linux/amd64 replay; it does not
certify every retained warning as a true defect or infer untested platforms.
