module github.com/gosuda/loGos/rt

go 1.27.0
