//line main.lgo:1:1
package main

import _logos_rt "github.com/gosuda/loGos/rt"

//line main.lgo:3:1
import (
//line main.lgo:4:1
	"errors"
//line main.lgo:5:1
	"fmt"
//line main.lgo:6:1
)

//line main.lgo:8:1
var failure = errors.New("expected")

//line main.lgo:9:1
var calls int

//line main.lgo:10:1
var assigned int

//line main.lgo:12:1
func fallback() int {
//line main.lgo:13:1
	calls++
//line main.lgo:14:1
	return 17
//line main.lgo:15:1
}

//line main.lgo:17:1
func maybe(n int) _logos_rt.Option[int] {
//line main.lgo:18:1
	if n < 0 {
//line main.lgo:19:1
		return _logos_rt.Option[int]{}
//line main.lgo:20:1
	}
//line main.lgo:21:1
	return _logos_rt.Option[int]{Value: n, Present: true}
//line main.lgo:22:1
}

//line main.lgo:24:1
func load(fail bool) (int, error) {
//line main.lgo:25:1
	if fail {
//line main.lgo:26:1
		return 99, failure
//line main.lgo:27:1
	}
//line main.lgo:28:1
	return 42, nil
//line main.lgo:29:1
}

//line main.lgo:31:1
func assign(fail bool) error {
//line main.lgo:32:1
	{
		var _logos_e0 error
		assigned, _logos_e0 = load(fail)
		if _logos_e0 != nil {
			_logos_rt.TraceErr(_logos_e0, &_logos_site_main_ea90e208_0)
			return _logos_e0
		}
	}

//line main.lgo:33:1
	return nil
//line main.lgo:34:1
}

//line main.lgo:37:1
func checkOption(n int) {
//line main.lgo:38:1
	calls = 0
//line main.lgo:39:1
	got := func() int {
		if _logos_v := maybe(n); _logos_v.Present {
			return _logos_v.Value
		}
		return fallback()
	}()
//line main.lgo:40:1
	if n < 0 {
//line main.lgo:41:1
		if got != 17 || calls != 1 {
//line main.lgo:42:1
			panic("absent option must evaluate fallback exactly once")
//line main.lgo:43:1
		}
//line main.lgo:44:1
	} else if got != n || calls != 0 {
//line main.lgo:45:1
		panic("present option must not evaluate fallback")
//line main.lgo:46:1
	}
//line main.lgo:47:1
}

//line main.lgo:49:1
func checkSwitch(n int) {
//line main.lgo:50:1
	branch := func() int {
		switch n {
//line main.lgo:51:1
		case -3, -2, -1:
			return -1
//line main.lgo:52:1
		case 0:
			return 0
//line main.lgo:53:1
		default:
			return 1
//line main.lgo:54:1
		}
	}()
//line main.lgo:55:1
	if branch*n < 0 || (branch == 0) != (n == 0) {
//line main.lgo:56:1
		panic("switch expression selected the wrong branch")
//line main.lgo:57:1
	}
//line main.lgo:58:1
}

//line main.lgo:60:1
func main() {
//line main.lgo:61:1
	for n := -3; n <= 3; n++ {
//line main.lgo:62:1
		checkOption(n)
//line main.lgo:63:1
		checkSwitch(n)
//line main.lgo:64:1
	}
//line main.lgo:65:1
	if err := assign(false); err != nil || assigned != 42 {
//line main.lgo:66:1
		panic("successful try assignment")
//line main.lgo:67:1
	}
//line main.lgo:68:1
	if err := assign(true); err != failure || assigned != 99 {
//line main.lgo:69:1
		panic("failed try assignment must store the returned value")
//line main.lgo:70:1
	}
//line main.lgo:71:1
	fmt.Println("language semantics ok")
//line main.lgo:72:1
}

var _logos_site_main_ea90e208_0 = _logos_rt.Site{File: "main.lgo", Line: 32}
