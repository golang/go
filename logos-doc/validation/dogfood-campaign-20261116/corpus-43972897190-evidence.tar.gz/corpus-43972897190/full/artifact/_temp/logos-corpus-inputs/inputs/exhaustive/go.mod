module github.com/nishanths/exhaustive

go 1.26.0

require (
	golang.org/x/tools v0.52.0
	rsc.io/script v0.0.2
)

require (
	golang.org/x/mod v0.42.0 // indirect
	golang.org/x/sync v0.24.0 // indirect
)
