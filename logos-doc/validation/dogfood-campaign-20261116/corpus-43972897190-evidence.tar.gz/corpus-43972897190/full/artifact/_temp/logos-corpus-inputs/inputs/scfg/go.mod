// Deprecated: this module has moved to codeberg.org/emersion/go-scfg
module git.sr.ht/~emersion/go-scfg

go 1.15

require github.com/davecgh/go-spew v1.1.1
