module example.com/logos-dogfood/language

go 1.27.0

require github.com/gosuda/loGos/rt v0.0.0

replace github.com/gosuda/loGos/rt v0.0.0 => ./_logos_deps/rt
