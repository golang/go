# pyright: strict
from __future__ import annotations

import json
from collections import Counter
from hashlib import sha256
from pathlib import Path, PurePosixPath
from typing import cast

type Json = None | bool | int | float | str | list[Json] | dict[str, Json]


def object_value(value: Json) -> dict[str, Json]:
    assert isinstance(value, dict), "expected JSON object"
    return value


def list_value(value: Json) -> list[Json]:
    assert isinstance(value, list), "expected JSON array"
    return value


def string_value(value: Json) -> str:
    assert isinstance(value, str), "expected JSON string"
    return value


def read_json(path: Path) -> dict[str, Json]:
    return object_value(cast(Json, json.loads(path.read_text())))


def walk_streams(value: Json, root: Path, seen: dict[str, str]) -> int:
    count = 0
    if isinstance(value, dict):
        for stream in ("stdout", "stderr"):
            key = f"{stream}_sha256"
            if key not in value:
                continue
            recorded = PurePosixPath(string_value(value[stream]))
            relative = recorded.relative_to(
                "/home/runner/work/_temp/logos-corpus-evidence"
            )
            assert ".." not in relative.parts
            digest = string_value(value[key])
            path = root / str(relative)
            assert path.is_file() and not path.is_symlink(), relative
            assert sha256(path.read_bytes()).hexdigest() == digest, relative
            if str(relative) in seen:
                assert seen[str(relative)] == digest, relative
            seen[str(relative)] = digest
            count += 1
        for child in value.values():
            count += walk_streams(child, root, seen)
    elif isinstance(value, list):
        for child in value:
            count += walk_streams(child, root, seen)
    return count


def assessments(report: dict[str, Json]) -> dict[tuple[str, str, str], dict[str, Json]]:
    result: dict[tuple[str, str, str], dict[str, Json]] = {}
    for case_value in list_value(report["cases"]):
        case = object_value(case_value)
        case_id = string_value(object_value(case["case"])["id"])
        for stage_value in list_value(case["stages"]):
            stage = object_value(stage_value)
            key = (case_id, string_value(stage["stage"]), string_value(stage["mode"]))
            assert key not in result, key
            result[key] = object_value(stage["assessment"])
    return result


def main() -> None:
    evidence = Path(__file__).resolve().parent
    root = evidence / "full/artifact/_temp/logos-corpus-evidence"
    reports = tuple(sorted(root.glob("*/report.json")))
    expected_reports = {
        "backends",
        "corpus",
        "ffi",
        "fixtures",
        "language",
        "lint",
        "tools-probe",
        "tools-unlimited",
    }
    assert {path.parent.name for path in reports} == expected_reports
    streams: dict[str, str] = {}
    references = sum(walk_streams(read_json(path), root, streams) for path in reports)
    assert references == len(streams) == 770

    report_path = root / "corpus/report.json"
    report = read_json(report_path)
    acceptance = read_json(root / "corpus/acceptance.json")
    assert report["complete"] is True and acceptance["accepted"] is True
    assert report["case_count"] == acceptance["case_count"] == 28
    assert report["operation_override"] == "build"
    assert (
        report["runner_sha256"]
        == "c2f2d0635450cc854c4fc7b4cf4a813d0b2e11a355bc960899bb85618efe9929"
    )
    assert (
        acceptance["checker_sha256"]
        == "56146fab4da8433c4607381190ecc502493092bb4be645d2c2480bb41d387396"
    )
    assert sha256(report_path.read_bytes()).hexdigest() == acceptance["report_sha256"]
    primary = assessments(report)
    expected_counts = {
        "pass": 81,
        "findings": 98,
        "clean": 10,
        "upstream-failed": 1,
        "uncompared": 2,
        "load-failed": 4,
    }
    counts = Counter(string_value(value["status"]) for value in primary.values())
    assert len(primary) == acceptance["primary_cells"] == 196
    assert dict(counts) == acceptance["counts"] == report["counts"] == expected_counts
    assert acceptance["accepted_positive_cases"] == 27
    assert acceptance["incomplete_analysis_cases"] == ["decorder"]
    assert acceptance["known_failed_load_cells"] == 7
    expected_stages = {
        ("oracle", ""),
        ("go", ""),
        ("logos", ""),
        ("logos-lint", ""),
        ("gglint", "basic"),
        ("gglint", "standard"),
        ("gglint", "strict"),
    }
    repeats = 0
    for case_value in list_value(report["cases"]):
        case = object_value(case_value)
        case_id = string_value(object_value(case["case"])["id"])
        assert {
            (stage, mode)
            for identifier, stage, mode in primary
            if identifier == case_id
        } == expected_stages
        for stage_value in list_value(case["stages"]):
            stage = object_value(stage_value)
            assessment = object_value(stage["assessment"])
            status = string_value(assessment["status"])
            if case_id == "decorder":
                assert status in {"upstream-failed", "uncompared", "load-failed"}
                continue
            assert status in {"pass", "findings", "clean"}
            run = object_value(stage["run"])
            assert run["timed_out"] is False and run["error"] == ""
            assert type(run["returncode"]) is int
            if status == "pass":
                assert run["returncode"] == 0
                continue
            assert stage["repeat_assessment"] == assessment
            repeat = object_value(stage["repeat"])
            assert repeat["timed_out"] is False and repeat["error"] == ""
            assert repeat["returncode"] == run["returncode"]
            assert stage["repeat_inputs"] == stage["inputs"]
            repeats += 1
    assert repeats == 108
    original = read_json(
        evidence.parent
        / "corpus-43967842639/full/artifact/_temp/logos-corpus-evidence/corpus/report.json"
    )
    assert primary == assessments(original)
    output = {
        "run": 43972897190,
        "head": "090bac0f2dbb1a1105d4bcb156fc31ed7c025177",
        "reports": len(reports),
        "verified_stream_references": references,
        "unique_stream_files": len(streams),
        "report_sha256": acceptance["report_sha256"],
        "primary_cells": len(primary),
        "counts": dict(counts),
        "accepted_positive_cases": 27,
        "incomplete_analysis_cases": ["decorder"],
        "exact_repeat_assessments_and_inputs": repeats,
        "reported_primary_assessments_equal_to_run": 43967842639,
        "raw_diagnostic_comparison": "separate independent lint audit",
        "targets": [
            {
                "case": key[0],
                "stage": key[1],
                "mode": key[2],
                "status": value["status"],
                "diagnostics": value["diagnostics"],
            }
            for key, value in primary.items()
            if key[0] in {"chi", "protobuf", "tools"}
        ],
        "local_go_execution": False,
    }
    destination = evidence / "ROOT_REPORT_AUDIT.json"
    destination.write_text(json.dumps(output, indent=2) + "\n")
    print(
        json.dumps(
            {
                "path": str(destination),
                "sha256": sha256(destination.read_bytes()).hexdigest(),
                "streams": references,
                "cells": len(primary),
                "repeats": repeats,
            }
        )
    )


if __name__ == "__main__":
    main()
