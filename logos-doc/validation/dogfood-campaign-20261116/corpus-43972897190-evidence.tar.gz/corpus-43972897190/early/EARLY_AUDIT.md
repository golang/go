# Corrected-source early audit: run 43972897190

The corrected run's early strict and unlimited tools captures completed with
the expected capability denial. All 126 complete diagnostic blocks match the
original run 43967842639, including their full call chains. There is no newly
exposed package, sink, or permission requirement.

| Item | Recorded identity |
| --- | --- |
| Head | `090bac0f2dbb1a1105d4bcb156fc31ed7c025177` |
| Repository tree | `bef78b17491bafdaf72f6926cc1482a6d7ff814b` |
| Source tree | `6a650366141c23a154f6e0b153767527e520a58f` |
| Run / job | `43972897190` / `133669378368` |
| Artifact | `14279877567`, `tools-probe-43972897190-1` |
| ZIP SHA256 | `8e4cefd9e1fddc78cf9dce85fb7844ee0204bcbcbeed29afba31ac99657c328d` |
| ZIP size / entries | 37,872 bytes / 37 entries |
| Strict report SHA256 | `ba8f4bb0a5d16e9a0f01d34159dce0f448da12b6ae65a211d43895ad2908acdf` |
| Unlimited report SHA256 | `5d2994d505faf5883f55bf7b9b101f01ffb1618215e30e95cd9291d7936f8f92` |

GitHub's exact commit/tree comparison shows that the only `src/` change from
the original corpus revision is the removal of two nonexistent `.Complete()`
calls in a types2 test fixture. There is no production, corpus helper, profile,
pin, or dogfood workflow change. The workflow blob remains
`9f716b8f6320c955720a5dd9fe905af28686757d`. The API source comparison is retained
under `metadata/SOURCE_DELTA.json`.

The baseline contains three exact `build ./...` commands. Stock Go and the
plain fork passed with empty stdout and stderr. The LoGOs build under the
original strict policy exited one with the recorded capability diagnostics.
The independent audit verified the baseline report hash, exact profile and
source digests, private working directories, stage-specific PATH/cache, and
full recorded environment. All 26 distinct recorded output streams rehash
correctly.

The separate command `logos build -ldflags=-e ./...` completed in 20.813 seconds
with exit one, no timeout, no process error, and no error-limit truncation.
Its report says `complete: true`, `build_succeeded: false`, and explicitly
does not accept the corpus. The original strict policy SHA256 remains
`005ba0707611025ef364004190601f0f103ab28ab97da9a6acd81e034d7f4d3f`.

The limited trace has 42 errors and 78 warnings. Its complete bytes are
unchanged from the original run, SHA256
`f17aa775d75242f461630680225642406030f3c81bbfec436b0609164ada4073`.
The unlimited trace has 48 errors and 78 warnings, SHA256
`1a98b9317a98a91115d2ac23ca8fc23721c9eeceeaf9724934b4e37b2c3d9b1b`.
Its byte order differs from the original unlimited log, but its full
package-qualified diagnostic block multiset is identical. All six extra
`syscall.Connect` paths beyond the limited trace retain the exact previously
reviewed owners and chains.

The new before/after source receipts are stable. All six installed native
executable hashes are also identical to the original corpus run. The
compiler-source digest is now
`h1:6ANF3115HvWFYqBuVITWIaWjdsY9NsJI+jIQELY4K5s=`, reflecting the test-fixture
source correction; it is stable within this run. These measurements are kept
separate from the older revision's source receipts.

`EARLY_AUDIT.json`, `RECORDED_LOGS.sha256`, `DOWNLOAD.json`, and the original ZIP
retain the verification results. `audit_early.py` records the read-only checks.
No local Go command was executed. The full 196-cell and runtime acceptance
steps were still running when this early audit was written; their later
results require the separate full artifact.
