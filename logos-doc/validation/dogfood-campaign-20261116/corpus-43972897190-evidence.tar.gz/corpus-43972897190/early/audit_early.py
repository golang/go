from __future__ import annotations

import hashlib
import json
import re
import subprocess
import tomllib
from collections import Counter
from pathlib import Path
from typing import cast

ROOT = Path(__file__).resolve().parent
ARTIFACT = ROOT / "artifact"
REPOSITORY = Path("/workspace/scratch/d8d410ec882d/logos-stability-final")
HELPERS = REPOSITORY / "misc/logos-dogfood"
HOSTED = "/home/runner/work/_temp/logos-corpus-evidence/"
HEAD = "090bac0f2dbb1a1105d4bcb156fc31ed7c025177"
TREE = "bef78b17491bafdaf72f6926cc1482a6d7ff814b"
SOURCE = "6a650366141c23a154f6e0b153767527e520a58f"
POLICY = "005ba0707611025ef364004190601f0f103ab28ab97da9a6acd81e034d7f4d3f"
CHECKED: dict[str, str] = {}


def object_value(value: object) -> dict[str, object]:
    if not isinstance(value, dict):
        raise TypeError("expected JSON object")
    return cast(dict[str, object], value)


def read_report(path: Path) -> dict[str, object]:
    return object_value(json.loads(path.read_text()))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def local_path(value: object) -> Path:
    if not isinstance(value, str) or not value.startswith(HOSTED):
        raise ValueError(f"unexpected hosted evidence path: {value}")
    path = ARTIFACT / value.removeprefix(HOSTED)
    if not path.resolve().is_relative_to(ARTIFACT.resolve()):
        raise ValueError("evidence path escaped artifact root")
    return path


def check_streams(value: object) -> None:
    if isinstance(value, dict):
        record = object_value(value)
        for stream in ("stdout", "stderr"):
            if stream in record and f"{stream}_sha256" in record:
                path = local_path(record[stream])
                expected = record[f"{stream}_sha256"]
                actual = digest(path)
                assert expected == actual, path
                CHECKED[path.relative_to(ARTIFACT).as_posix()] = actual
        for child in record.values():
            check_streams(child)
    elif isinstance(value, list):
        for child in cast(list[object], value):
            check_streams(child)


def stable_toolchain(value: object) -> dict[str, object]:
    return {key: item for key, item in object_value(value).items() if key != "run"}


def git_value(*args: str) -> str:
    return subprocess.check_output(
        ("git", "-C", str(REPOSITORY), *args), text=True
    ).strip()


DIAGNOSTIC = re.compile(
    r"^(ERROR|WARNING) \[(capabilities::[^\]]+)\]: "
    r"Transitive dependency '([^']+)' reaches '([^']+)'$",
    re.MULTILINE,
)
FRAME = re.compile(r"^\s+\d+\.\s+(?:-> )?(.+?)\s+at ", re.MULTILINE)


def diagnostics(text: str) -> list[tuple[tuple[str, ...], str]]:
    records: list[tuple[tuple[str, ...], str]] = []
    binary = ""
    for block in text.split("\n\n"):
        for line in block.splitlines():
            if line.startswith("# "):
                binary = line[2:]
        match = DIAGNOSTIC.search(block)
        if match is not None:
            records.append(((binary, *match.groups()), block[match.start():]))
    return records


def main() -> None:
    baseline_path = ARTIFACT / "tools-probe/report.json"
    baseline = read_report(baseline_path)
    unlimited = read_report(ARTIFACT / "tools-unlimited/report.json")
    for report in (baseline, unlimited):
        check_streams(report)
    # The API comparison proves the locally reviewed corpus helpers are unchanged.
    metadata = read_report(ROOT.parent / "metadata/initial.json")
    delta = read_report(ROOT.parent / "metadata/SOURCE_DELTA.json")
    assert metadata["head"] == HEAD and metadata["tree"] == TREE
    assert metadata["source_tree"] == SOURCE
    assert metadata["workflow_blob"] == "9f716b8f6320c955720a5dd9fe905af28686757d"
    assert delta["head"] == HEAD
    assert delta["base"] == "3b2073eb98e488c411f52ba7cd723e8622c8cdfe"
    assert delta["corpus_or_workflow_changed"] is False
    source_delta = cast(list[dict[str, object]], delta["src_delta"])
    assert len(source_delta) == 1
    assert source_delta[0]["path"] == "src/cmd/compile/internal/types2/referencefree_zero_array_logos_test.go"
    assert source_delta[0]["sha"] == "9ded64e582ede0d4b8c6268b9c2d6703bb0ebcc6"
    assert git_value("rev-parse", "HEAD^{tree}") == TREE
    assert git_value("rev-parse", "HEAD:src") == SOURCE
    assert (ARTIFACT / "logos-source.txt").read_text().splitlines() == [HEAD, SOURCE]
    assert baseline["complete"] is True and baseline["case_count"] == 1
    assert baseline["operation_override"] == "build"
    assert baseline["runner_sha256"] == digest(HELPERS / "run.py")
    assert baseline["manifest_sha256"] == digest(HELPERS / "corpus-permissions.json")
    assert unlimited["runner_sha256"] == baseline["runner_sha256"]
    assert unlimited["probe_sha256"] == digest(HELPERS / "probe_tools.py")
    assert object_value(unlimited["baseline"])["sha256"] == digest(baseline_path)
    assert local_path(object_value(unlimited["baseline"])["path"]) == baseline_path
    cases = cast(list[object], baseline["cases"])
    assert len(cases) == 1
    row = object_value(cases[0])
    manifest = cast(list[dict[str, object]], json.loads((HELPERS / "corpus-permissions.json").read_text()))
    case = next(value for value in manifest if value["id"] == "tools")
    assert row["case"] == case == unlimited["case"]
    assert row["status"] == "finished"
    assert row["source_digest"] == unlimited["source_digest"] == case["sum"]
    for relative in ("tools-probe/inputs/tools/logos.toml", "tools-unlimited/inputs/tools/logos.toml"):
        assert digest(ARTIFACT / relative) == POLICY == digest(HELPERS / "policies/tools.toml")
    before, after = object_value(unlimited["native_before"]), object_value(unlimited["native_after"])
    assert before["drivers"] == after["drivers"]
    assert before["source_tree"] == after["source_tree"] == SOURCE
    native = stable_toolchain(before["toolchain"])
    assert native == stable_toolchain(after["toolchain"])
    assert native["source_revision"] == HEAD and native["source_status"] == ""
    tools = object_value(baseline["tools"])
    versions = object_value(baseline["versions"])
    assert set(tools) == {"oracle", "go", "logos"}
    for name in ("go", "logos"):
        assert tools[name] == object_value(before["drivers"])[name]
        assert stable_toolchain(object_value(versions[name])["toolchain"]) == native
    oracle = object_value(tools["oracle"])
    assert oracle["path"] == "/home/runner/work/_temp/oracle/bin/go"
    assert oracle["sha256"] == "de0ae3e082ce7599eae4fb69fa2ef1e43b8f31ffd3fce62cdf81930aa9005050"
    assert object_value(object_value(versions["oracle"])["toolchain"])["goroot"] == "/home/runner/work/_temp/oracle"
    stages = [object_value(value) for value in cast(list[object], row["stages"])]
    assert [stage["stage"] for stage in stages] == ["oracle", "go", "logos"]
    run = object_value(unlimited["run"])
    environment = object_value(run["environment"])
    logos_path = object_value(tools["logos"])["path"]
    assert isinstance(logos_path, str)
    inherited_path = cast(str, environment["PATH"]).removeprefix(str(Path(logos_path).parent) + ":")
    for stage in stages:
        name = cast(str, stage["stage"])
        execution = object_value(stage["run"])
        tool = object_value(tools[name])
        assert execution["command"] == [tool["path"], "build", "./..."]
        assert execution["cwd"] == HOSTED + "tools-probe/work/tools"
        assert type(execution["returncode"]) is int
        assert execution["returncode"] == (1 if name == "logos" else 0)
        assert execution["timed_out"] is False and execution["error"] == ""
        assert object_value(stage["assessment"])["status"] == ("candidate-failed" if name == "logos" else "pass")
        expected_environment = {
            **environment,
            "PATH": str(Path(cast(str, tool["path"])).parent) + ":" + inherited_path,
            "GOCACHE": "/home/runner/work/_temp/corpus-cache/" + name,
        }
        assert execution["environment"] == expected_environment
        expected_inputs = unlimited["inputs"] if name == "logos" else {"effective_source_digest": case["sum"]}
        assert stage["inputs"] == expected_inputs
    assert run["command"] == [logos_path, "build", "-ldflags=-e", "./..."]
    assert run["cwd"] == HOSTED + "tools-unlimited/work"
    assert type(run["returncode"]) is int and run["returncode"] == 1
    assert run["timed_out"] is False and run["error"] == ""
    assert unlimited["complete"] is True and unlimited["build_succeeded"] is False
    assert unlimited["jobs"] == baseline["jobs"] == 2
    assert unlimited["timeout_seconds"] == baseline["timeout_seconds"] == 600
    assert unlimited["inherited_gogc"] == {"present": True, "value": "50"}
    assert environment["GOMAXPROCS"] == "2" and environment["GOMEMLIMIT"] == "2GiB"
    assert environment["GOPROXY"] == "off" and environment["GOSUMDB"] == "off"
    old_path = Path("/workspace/scratch/d8d410ec882d/recovery-evidence/corpus-43950476822-final/artifact/_temp/logos-corpus-evidence/tools-probe/logs/tools/logos.stderr")
    strict_path = ARTIFACT / "tools-probe/logs/tools/logos.stderr"
    assert strict_path.read_bytes() == old_path.read_bytes()
    limited_text = strict_path.read_text()
    complete_text = (ARTIFACT / "tools-unlimited/build.stderr").read_text()
    limited, full = diagnostics(limited_text), diagnostics(complete_text)
    limited_counts = Counter(key for key, _ in limited)
    full_counts = Counter(key for key, _ in full)
    assert not (limited_counts - full_counts)
    added = full_counts - limited_counts
    expected_packages = {"golang.org/x/telemetry/internal/" + suffix for suffix in ("configstore", "counter", "crashmonitor", "mmap", "telemetry", "upload")}
    assert len(added) == 6 and sum(added.values()) == 6
    assert {key[3] for key in added} == expected_packages
    assert all(key[1:3] == ("ERROR", "capabilities::unauthorized_net") and key[4] == "syscall.Connect" for key in added)
    assert "too many errors" in limited_text and "too many errors" not in complete_text
    assert not re.search(r"(?m)^(?:panic:|fatal error:|signal:|SIG[A-Z]+:)|internal compiler error", complete_text)
    chains = dict(limited)
    common_prefixes: dict[str, int] = {}
    for key, block in full:
        if key in added:
            existing = (*key[:-1], "net.sysSocket")
            old_chain = FRAME.findall(chains[existing])
            new_chain = FRAME.findall(block)
            end = old_chain.index("net.socket()") + 1
            assert old_chain[:end] == new_chain[:end]
            common_prefixes[key[3]] = end
    policy = tomllib.loads((HELPERS / "policies/tools-build.toml").read_text())
    grants = cast(dict[str, list[str]], policy["capabilities"])
    errors = [key for key, _ in full if key[1] == "ERROR"]
    for key in errors:
        grant = "transitive_net_allowlist" if key[2].endswith("_net") else "transitive_exec_allowlist"
        assert key[3] in grants[grant]
    previous = ROOT.parents[1] / "corpus-43967842639/early/artifact"
    previous_unlimited = read_report(previous / "tools-unlimited/report.json")
    previous_native = object_value(previous_unlimited["native_before"])
    assert previous_native["drivers"] == before["drivers"]
    assert object_value(previous_native["toolchain"])["tools"] == native["tools"]
    assert Counter(diagnostics((previous / "tools-unlimited/build.stderr").read_text())) == Counter(full)
    result: dict[str, object] = {
        "previous_run": 43967842639,
        "all_126_complete_diagnostic_blocks_equal_previous": True,
        "all_six_native_executable_hashes_equal_previous": True,
        "source_delta_is_two_test_fixture_api_suffix_removals": True,
        "run_id": 43972897190, "head": HEAD, "tree": TREE, "src_tree": SOURCE,
        "early_artifact_id": 14279877567, "raw_streams_rehashed": len(CHECKED),
        "source_and_six_native_tool_identities_stable": True,
        "baseline_exact_stock_and_fork_builds_pass": True,
        "baseline_profile_environment_command_source_binding_verified": True,
        "strict_report_sha256": digest(baseline_path),
        "unlimited_report_sha256": digest(ARTIFACT / "tools-unlimited/report.json"),
        "strict_stderr_sha256": digest(strict_path),
        "unlimited_stderr_sha256": digest(ARTIFACT / "tools-unlimited/build.stderr"),
        "unlimited_capture_complete": True, "strict_build_succeeded": False,
        "limited_counts": dict(Counter(key[1] for key, _ in limited)),
        "unlimited_counts": dict(Counter(key[1] for key, _ in full)),
        "new_packages": [], "new_connect_packages": sorted(expected_packages),
        "existing_socket_path_prefix_frame_counts": common_prefixes,
        "every_observed_denial_covered_by_reviewed_profile": True,
        "positive_profile_build_accepted": None,
        "limits": ["Diagnostic capture only; full corpus replay is still running.", "Reachability is not observed network execution."]
    }
    (ROOT / "EARLY_AUDIT.json").write_text(json.dumps(result, indent=2) + "\n")
    (ROOT / "RECORDED_LOGS.sha256").write_text("".join(f"{value}  artifact/{name}\n" for name, value in sorted(CHECKED.items())))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
