#!/usr/bin/env python3
# pyright: strict
"""Independently audit retained corpus lint streams without executing Go."""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import posixpath
import re
import subprocess
import tomllib
from collections import Counter
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import cast

HOST = PurePosixPath("/home/runner/work/_temp/logos-corpus-evidence")
PIN = "4456e61c4dbdf636fca2b5bd77787873e2d1c1e8"
TREE = "dfb46c72af5ce9695844c5d567cbb8aab1568183"
RUNNER_SHA = "c2f2d0635450cc854c4fc7b4cf4a813d0b2e11a355bc960899bb85618efe9929"
CELLS = {("oracle", ""), ("go", ""), ("logos", ""), ("logos-lint", "")} | {
    ("gglint", mode) for mode in ("basic", "standard", "strict")
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def obj(value: object) -> dict[str, object]:
    require(isinstance(value, dict), "expected object")
    result = cast(dict[object, object], value)
    require(all(isinstance(key, str) for key in result), "non-string object key")
    return cast(dict[str, object], result)


def seq(value: object) -> tuple[object, ...]:
    require(isinstance(value, list), "expected array")
    return tuple(cast(list[object], value))


def text(value: object) -> str:
    require(isinstance(value, str), "expected string")
    return cast(str, value)


def integer(value: object, minimum: int = 0) -> int:
    require(type(value) is int and value >= minimum, "invalid integer")
    return cast(int, value)


def pairs(values: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in values:
        require(key not in result, f"duplicate JSON key: {key}")
        result[key] = value
    return result


def invalid_constant(value: str) -> object:
    raise ValueError(f"non-finite JSON number: {value}")


def decode(raw: str) -> object:
    return cast(
        object,
        json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid_constant),
    )


def read(path: Path) -> dict[str, object]:
    return obj(decode(path.read_text()))


def sha(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def encoded(record: dict[str, object], cwd: str) -> str:
    return json.dumps(record, sort_keys=True, separators=(",", ":")).replace(
        cwd, "<source>"
    )


def digest(records: tuple[str, ...]) -> str:
    return hashlib.sha256("\n".join(records).encode()).hexdigest()


def actual(root: Path, hosted: object) -> Path:
    relative = PurePosixPath(text(hosted)).relative_to(HOST)
    require(".." not in relative.parts, "escaping captured path")
    path = root.joinpath(*relative.parts)
    require(
        path.resolve().is_relative_to(root.resolve()) and not path.is_symlink(),
        "invalid capture path",
    )
    return path


def finding(record: dict[str, object]) -> None:
    required = {"rule", "path", "line", "column", "message"}
    optional = {"check", "end_line", "end_column", "related", "fixes", "fixable"}
    require(
        required <= set(record) <= required | optional,
        "unknown/missing gglint finding fields",
    )
    for key in ("rule", "path", "message"):
        require(bool(text(record[key])), f"empty finding {key}")
    integer(record["line"], 1)
    integer(record["column"], 1)
    for key in ("end_line", "end_column"):
        if key in record:
            integer(record[key], 1)
    if "check" in record:
        require(bool(text(record["check"])), "empty check")
    if "fixable" in record:
        require(record["fixable"] is True, "noncanonical fixable value")
    if "fixes" in record:
        require(bool(seq(record["fixes"])), "empty fixes")
        for value in seq(record["fixes"]):
            require(bool(text(value)), "empty fix description")
    if "related" in record:
        require(bool(seq(record["related"])), "empty related information")
        for value in seq(record["related"]):
            item = obj(value)
            require(
                set(item) == {"path", "line", "column", "message"},
                "bad related information",
            )
            for key in ("path", "message"):
                require(bool(text(item[key])), "empty related string")
            integer(item["line"], 1)
            integer(item["column"], 1)


def native(record: dict[str, object]) -> None:
    require(
        set(record)
        == {
            "schema_version",
            "severity",
            "rule_id",
            "file",
            "span",
            "message",
            "provenance",
            "autofix_candidates",
        },
        "native diagnostic fields",
    )
    require(record["schema_version"] == "1.0", "native schema version")
    require(record["severity"] in ("warn", "deny", "forbid"), "native severity")
    text(record["rule_id"])
    for key in ("file", "message"):
        require(bool(text(record[key])), f"empty native {key}")
    span = obj(record["span"])
    require(
        set(span)
        == {
            "start_line",
            "start_col",
            "end_line",
            "end_col",
            "byte_offset",
            "byte_len",
        },
        "native span fields",
    )
    for value in span.values():
        integer(value)
    provenance = obj(record["provenance"])
    require(
        set(provenance) == {"origin_expr", "origin_line", "inferred_type"},
        "native provenance fields",
    )
    integer(provenance["origin_line"])
    text(provenance["origin_expr"])
    text(provenance["inferred_type"])
    for value in seq(record["autofix_candidates"]):
        fix = obj(value)
        require(set(fix) == {"description", "replacement"}, "native fix fields")
        require(bool(text(fix["description"])), "empty native fix description")
        text(fix["replacement"])
    if not record["rule_id"]:
        require(
            record["severity"] == "deny" and record["autofix_candidates"] == [],
            "compiler error metadata",
        )
        require(
            provenance == {"origin_expr": "", "origin_line": 0, "inferred_type": ""},
            "compiler error provenance",
        )
        require(
            span["start_line"] == span["end_line"]
            and span["start_col"] == span["end_col"]
            and span["byte_len"] == 0,
            "compiler error span",
        )


def raw_run(
    root: Path, run: dict[str, object], hashes: dict[str, str]
) -> tuple[str, str]:
    require(
        type(run["returncode"]) is int and run["returncode"] in (0, 1),
        "unexpected process status",
    )
    require(
        run["timed_out"] is False and run["error"] == "", "capture failed or timed out"
    )
    streams: list[str] = []
    for kind in ("stdout", "stderr"):
        path = actual(root, run[kind])
        value = sha(path)
        require(value == run[f"{kind}_sha256"], f"capture digest mismatch: {path}")
        relative = path.relative_to(root).as_posix()
        require(relative not in hashes, f"capture reused: {relative}")
        hashes[relative] = value
        streams.append(path.read_text())
    return streams[0], streams[1]


def invocation(
    root: Path,
    report: dict[str, object],
    case: dict[str, object],
    stage: str,
    mode: str,
    run: dict[str, object],
) -> None:
    cid = text(case["id"])
    tools = obj(report["tools"])
    tool = "logos" if stage == "logos-lint" else stage
    binary = text(obj(tools[tool])["path"])
    cwd = str(HOST / "corpus" / "work" / cid)
    require(run["cwd"] == cwd, "unexpected private source directory")
    patterns = tuple(text(value) for value in seq(case["patterns"]))
    tags = tuple(text(value) for value in seq(case["tags"]))
    flags = (f"-tags={','.join(tags)}",) if tags else ()
    if stage == "gglint":
        config = str(HOST / "corpus" / "config" / f"{cid}.toml")
        command = (
            binary,
            "run",
            "-config",
            config,
            "-mode",
            mode,
            "-format",
            "json",
            *patterns,
        )
        parsed = obj(tomllib.loads(actual(root, config).read_text()))
        require(
            parsed == {"run": {"tests": True, "build_tags": list(tags)}},
            "gglint config changed",
        )
    elif stage == "logos-lint":
        command = (binary, "lint", "--json-diagnostics", *flags, *patterns)
    else:
        command = (binary, "build", *flags, *patterns)
    require(
        tuple(text(v) for v in seq(run["command"])) == command,
        "invocation differs from full pinned case",
    )
    env = obj(run["environment"])
    expected = {
        "CC": "gcc",
        "CXX": "g++",
        "CGO_ENABLED": str(case["cgo"]),
        "GOENV": "off",
        "GOFLAGS": "-mod=readonly -buildvcs=false -p=2",
        "GOMAXPROCS": "2",
        "GOMEMLIMIT": "2GiB",
        "GOPROXY": "off",
        "GOSUMDB": "off",
        "GOTELEMETRY": "off",
        "GOTOOLCHAIN": "local",
        "GOWORK": "off",
        "GOMODCACHE": "/home/runner/work/_temp/logos-corpus-inputs/modules",
        "GOCACHE": f"/home/runner/work/_temp/corpus-cache/{tool}",
    }
    for key, value in expected.items():
        require(env.get(key) == value, f"execution environment differs: {key}")
    require(
        not {"GOROOT", "GOEXPERIMENT", "GODEBUG"} & set(env), "unexpected Go overrides"
    )
    driver = text(obj(tools["oracle"])["path"]) if stage == "gglint" else binary
    require(
        text(env["PATH"]).split(":")[0] == str(PurePosixPath(driver).parent),
        "incorrect Go driver precedence",
    )


def records(
    stdout: str,
    stderr: str,
    stage: str,
    mode: str,
    run: dict[str, object],
    case: dict[str, object],
) -> tuple[dict[str, object], ...]:
    if stage == "gglint":
        document = obj(decode(stdout))
        require(
            set(document) == {"mode", "config", "findings"}
            and document["mode"] == mode,
            "gglint envelope",
        )
        config = posixpath.normpath(
            posixpath.join(text(run["cwd"]), text(document["config"]))
        )
        require(
            config == str(HOST / "corpus" / "config" / f"{text(case['id'])}.toml"),
            "reported gglint config",
        )
        require(
            stderr == f"gglint: config {text(document['config'])}\n",
            "unrecognized gglint stderr",
        )
        result = tuple(obj(value) for value in seq(document["findings"]))
        for record in result:
            finding(record)
        expected = int(bool(result))
    else:
        require(stdout == "", "native lint wrote stdout")
        rows: list[dict[str, object]] = []
        header = False
        for line in stderr.splitlines():
            if not line.strip():
                continue
            if re.fullmatch(r"# \S+(?: \[\S+\])?", line):
                require(not header, "consecutive package banners")
                header = True
                continue
            record = obj(decode(line))
            native(record)
            rows.append(record)
            header = False
        require(not header, "trailing package banner")
        result = tuple(rows)
        expected = int(any(row["severity"] in ("deny", "forbid") for row in result))
    require(run["returncode"] == expected, "diagnostics and exit status differ")
    return result


@dataclass(frozen=True)
class Capture:
    report: dict[str, object]
    cases: dict[str, dict[str, object]]
    lint: dict[tuple[str, str, str], tuple[str, ...]]
    hashes: dict[str, str]
    lint_runs: int
    repeats: int


def inspect(root: Path) -> Capture:
    report = read(root / "corpus/report.json")
    require(
        report["complete"] is True
        and report["case_count"] == 28
        and report["sources"] == 26,
        "incomplete case matrix",
    )
    require(
        report["modes"] == ["basic", "standard", "strict"]
        and report["stages"] == ["oracle", "go", "logos", "logos-lint", "gglint"],
        "incomplete stage matrix",
    )
    require(
        report["runner_sha256"] == RUNNER_SHA
        and report["operation_override"] == "build"
        and report["jobs"] == 2
        and report["timeout_seconds"] == 600,
        "runner/profile drift",
    )
    cases: dict[str, dict[str, object]] = {}
    lint: dict[tuple[str, str, str], tuple[str, ...]] = {}
    hashes: dict[str, str] = {}
    counts: Counter[str] = Counter()
    lint_runs = 0
    repeats = 0
    for value in seq(report["cases"]):
        row = obj(value)
        case = obj(row["case"])
        cid = text(case["id"])
        require(
            cid not in cases and row["status"] == "finished",
            "duplicate/unfinished case",
        )
        cases[cid] = row
        seen: set[tuple[str, str]] = set()
        for value in seq(row["stages"]):
            entry = obj(value)
            stage, mode = text(entry["stage"]), text(entry["mode"])
            require((stage, mode) not in seen, "duplicate stage")
            seen.add((stage, mode))
            run = obj(entry["run"])
            invocation(root, report, case, stage, mode, run)
            stdout, stderr = raw_run(root, run, hashes)
            assessment = obj(entry["assessment"])
            counts[text(assessment["status"])] += 1
            inputs = obj(entry["inputs"])
            if stage not in ("logos", "logos-lint") or not case["logos_policy"]:
                require(
                    inputs == {"effective_source_digest": row["source_digest"]},
                    "source identity changed",
                )
            else:
                policy = root / "corpus/inputs" / cid / "logos.toml"
                require(
                    inputs["policy_sha256"]
                    == case["logos_policy_sha256"]
                    == sha(policy),
                    "policy identity changed",
                )
            if stage not in ("gglint", "logos-lint"):
                continue
            parsed = records(stdout, stderr, stage, mode, run, case)
            normalized = tuple(
                sorted(encoded(record, text(run["cwd"])) for record in parsed)
            )
            lint[(cid, stage, mode)] = normalized
            lint_runs += 1
            require(assessment["diagnostics"] == len(parsed), "record count differs")
            if cid == "decorder":
                require(
                    assessment["status"] == "load-failed"
                    and run["returncode"] == 1
                    and "repeat" not in entry,
                    "incomplete control relabeled",
                )
                errors = [
                    record
                    for record in parsed
                    if record.get("rule", record.get("rule_id")) in ("typecheck", "")
                ]
                require(
                    len(errors) == 1
                    and errors[0]["message"]
                    == "invalid array length -delta * delta (constant -256 of type int64)",
                    "different decorder failure",
                )
                continue
            require(
                not any(
                    record.get("rule", record.get("rule_id")) in ("typecheck", "")
                    for record in parsed
                ),
                "incomplete positive analysis",
            )
            require(
                assessment["status"] == ("findings" if parsed else "clean")
                and assessment["reason"] == "",
                "incorrect lint assessment",
            )
            require(
                assessment["normalized_sha256"] == digest(normalized),
                "normalized digest differs",
            )
            duplicates = len(normalized) - len(set(normalized))
            require(
                assessment["duplicate_diagnostics"] == duplicates,
                "duplicate count differs",
            )
            require(stage != "gglint" or duplicates == 0, "duplicate gglint findings")
            repeated = obj(entry["repeat"])
            require(
                entry["repeat_inputs"] == inputs
                and entry["repeat_assessment"] == assessment,
                "repeat inputs/results differ",
            )
            for key in ("command", "cwd", "environment", "returncode"):
                require(
                    repeated[key] == run[key],
                    f"repeat invocation/status differs: {key}",
                )
            invocation(root, report, case, stage, mode, repeated)
            again = records(
                *raw_run(root, repeated, hashes), stage, mode, repeated, case
            )
            require(
                tuple(
                    sorted(encoded(record, text(repeated["cwd"])) for record in again)
                )
                == normalized,
                "repeat diagnostics differ",
            )
            lint_runs += 1
            repeats += 1
        require(seen == CELLS, f"missing/extra stage: {cid}")
    require(
        len(cases) == 28 and len(lint) == 112 and lint_runs == 220 and repeats == 108,
        "incomplete lint inventory",
    )
    require(
        dict(counts) == report["counts"] and sum(counts.values()) == 196,
        "reported counts differ",
    )
    return Capture(report, cases, lint, hashes, lint_runs, repeats)


def compare(before: Capture, after: Capture) -> list[dict[str, object]]:
    require(before.lint.keys() == after.lint.keys(), "lint inventory changed")
    changes: list[dict[str, object]] = []
    for key in sorted(before.lint):
        left, right = Counter(before.lint[key]), Counter(after.lint[key])
        if left != right:
            changes.append(
                {
                    "case": key[0],
                    "stage": key[1],
                    "mode": key[2],
                    "before": sum(left.values()),
                    "after": sum(right.values()),
                    "removed": [
                        decode(value) for value in sorted((left - right).elements())
                    ],
                    "added": [
                        decode(value) for value in sorted((right - left).elements())
                    ],
                }
            )
    return changes


def expected_removals(changes: list[dict[str, object]]) -> None:
    expected = {
        ("chi", "middleware/throttle.go", 95, 17),
        ("modernc-sqlite", "stmt.go", 101, 9),
        ("modernc-sqlite", "stmt.go", 294, 9),
        ("toml", "lex.go", 82, 16),
        ("tools", "go/ssa/task.go", 40, 7),
        ("tools", "internal/gopathwalk/walk.go", 315, 10),
        ("tools", "internal/jsonrpc2_v2/conn.go", 121, 7),
        ("tools", "internal/jsonrpc2_v2/conn.go", 270, 8),
        ("tools", "internal/jsonrpc2_v2/conn.go", 394, 7),
        ("tools", "internal/jsonrpc2_v2/conn.go", 404, 7),
        ("tools", "internal/jsonrpc2_v2/net.go", 102, 7),
        ("modernc-libc", "libc_musl.go", 357, 8),
        ("modernc-libc", "libc_musl.go", 475, 14),
    }
    observed: set[tuple[str, str, int, int]] = set()
    for change in changes:
        for value in seq(change["removed"]):
            record = obj(value)
            if change["stage"] == "gglint":
                observed.add(
                    (
                        text(change["case"]),
                        text(record["path"]),
                        integer(record["line"]),
                        integer(record["column"]),
                    )
                )
                continue
            span = obj(record["span"])
            line = integer(span["start_line"])
            require(line in (110, 137), "unexpected Protobuf location")
            expected_native: dict[str, object] = {
                "schema_version": "1.0",
                "severity": "deny",
                "rule_id": "correctness::arena_pointer_escape",
                "file": "<source>/internal/impl/presence.go",
                "span": {
                    "start_line": line,
                    "start_col": 8,
                    "end_line": line,
                    "end_col": 44,
                    "byte_offset": 3993 if line == 110 else 5196,
                    "byte_len": 36,
                },
                "message": "uintptr(unsafe.Pointer(&template.a)) keeps the address of a frame object as an integer the compiler cannot track; keep an unsafe.Pointer",
                "provenance": {
                    "origin_expr": "",
                    "origin_line": 0,
                    "inferred_type": "",
                },
                "autofix_candidates": [],
            }
            require(record == expected_native, "unexpected Protobuf diagnostic")
    require(observed == expected, "unexpected chanblock removal location")


def git(root: Path, *args: str) -> str:
    return subprocess.run(
        ("git", "-C", str(root), *args),
        check=True,
        capture_output=True,
        text=True,
        timeout=30,
    ).stdout.strip()


def source_receipts(
    workspace: Path, capture: Capture, changes: list[dict[str, object]]
) -> list[dict[str, object]]:
    receipts: list[dict[str, object]] = []
    for change in changes:
        cid = text(change["case"])
        row = capture.cases[cid]
        case = obj(row["case"])
        prefix = ""
        if case["source_kind"] == "git":
            root = workspace / "corpus-sources" / text(case["source"])
            require(
                git(root, "rev-parse", "HEAD") == case["revision"],
                "local source commit differs",
            )
            require(
                git(root, "remote", "get-url", "origin").removesuffix(".git")
                == text(case["upstream"]).removesuffix(".git"),
                "local source origin differs",
            )
            require(
                not git(root, "status", "--porcelain", "--untracked-files=all"),
                "local source dirty",
            )
            files = tuple(git(root, "ls-files", "-z").rstrip("\0").split("\0"))
        else:
            module, version = text(case["module"]), text(case["version"])
            escaped = "".join("!" + c.lower() if c.isupper() else c for c in module)
            root = workspace / "modcache" / f"{escaped}@{version}"
            info = read(
                workspace
                / "modcache/cache/download"
                / escaped
                / "@v"
                / f"{version}.info"
            )
            require(
                info["Version"] == version
                and obj(info["Origin"])["Hash"] == case["revision"],
                "local module origin differs",
            )
            files = tuple(
                sorted(
                    p.relative_to(root).as_posix()
                    for p in root.rglob("*")
                    if not p.is_dir()
                )
            )
            prefix = f"{module}@{version}/"
        summary = hashlib.sha256()
        for name in sorted(files):
            require(
                not (root / name).is_symlink() and "\n" not in name,
                "unsafe source filename",
            )
            summary.update(f"{sha(root / name)}  {prefix}{name}\n".encode())
        h1 = "h1:" + base64.b64encode(summary.digest()).decode("ascii")
        require(
            h1 == row["source_digest"], f"local source bytes differ from corpus: {cid}"
        )
        contexts: list[dict[str, object]] = []
        for value in seq(change["removed"]):
            record = obj(value)
            path = text(record.get("path", record.get("file"))).removeprefix(
                "<source>/"
            )
            line = integer(
                record["line"]
                if "line" in record
                else obj(record["span"])["start_line"],
                1,
            )
            source = root / path
            lines = source.read_text().splitlines()
            start, end = max(1, line - 8), min(len(lines), line + 18)
            contexts.append(
                {
                    "path": path,
                    "line": line,
                    "sha256": sha(source),
                    "context_first_line": start,
                    "context": lines[start - 1 : end],
                }
            )
        receipts.append(
            {
                "case": cid,
                "module": case["module"],
                "version": case["version"],
                "revision": case["revision"],
                "source_h1": h1,
                "file_count": len(files),
                "contexts": contexts,
            }
        )
    return receipts


def tools_receipt(workspace: Path, root: Path, capture: Capture) -> dict[str, object]:
    require(
        (root / "gglint-source.txt").read_text().splitlines() == [PIN, TREE],
        "gglint source pin/tree differs",
    )
    local = workspace / "gglint-chanblock-default"
    require(
        git(local, "rev-parse", "HEAD^{tree}") == TREE
        and not git(local, "status", "--porcelain"),
        "reviewed local gglint tree differs",
    )
    info = (root / "gglint-build-info.txt").read_text()
    require(
        info.startswith("/home/runner/work/_temp/gglint: go1.27.4\n"),
        "gglint build toolchain",
    )
    for item in (
        f"\tbuild\tvcs.revision={PIN}\n",
        "\tbuild\tvcs.modified=false\n",
        "\tbuild\t-trimpath=true\n",
    ):
        require(item in info, "gglint build provenance absent")
    require(
        (root / "gglint-build.txt").read_text() == "",
        "unexpected gglint build diagnostics",
    )
    receipt = (root / "gglint.sha256").read_text().split()
    gg = obj(obj(capture.report["tools"])["gglint"])
    require(receipt == [gg["sha256"], gg["path"]], "gglint binary receipt differs")
    require(
        obj(obj(capture.report["versions"])["gglint"])["text"]
        == "gglint v0.0.0-20261116214551-4456e61c4dbd go1.27.4",
        "gglint executable version differs",
    )
    sums = {tuple(line.split()) for line in (local / "go.sum").read_text().splitlines()}
    decoder = json.JSONDecoder(object_pairs_hook=pairs, parse_constant=invalid_constant)
    remaining = (root / "gglint-downloads.json").read_text().lstrip()
    downloaded: dict[tuple[str, str], str] = {}
    while remaining:
        value, end = decoder.raw_decode(remaining)
        item = obj(cast(object, value))
        require("Error" not in item, "dependency download failed")
        module, version, checksum = (
            text(item["Path"]),
            text(item["Version"]),
            text(item["Sum"]),
        )
        require(
            (module, version, checksum) in sums
            and (module, f"{version}/go.mod", text(item["GoModSum"])) in sums,
            "download differs from committed go.sum",
        )
        require((module, version) not in downloaded, "duplicate dependency download")
        downloaded[(module, version)] = checksum
        remaining = remaining[end:].lstrip()
    dependencies = 0
    for line in info.splitlines():
        if line.startswith("\tdep\t"):
            _, _, module, version, checksum = line.split("\t")
            require(
                downloaded[(module, version)] == checksum,
                "binary dependency differs from pinned download",
            )
            dependencies += 1
    names = (
        "gglint-source.txt",
        "gglint-fetch.txt",
        "gglint-build.txt",
        "gglint-build-info.txt",
        "gglint-downloads.json",
        "gglint.sha256",
        "go-archive.txt",
    )
    return {
        "commit": PIN,
        "tree": TREE,
        "binary_sha256": receipt[0],
        "binary_retained_in_artifact": False,
        "binary_receipts_consistent": True,
        "go_version": "go1.27.4",
        "downloaded_modules": len(downloaded),
        "linked_modules": dependencies,
        "receipts": {name: sha(root / name) for name in names},
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--expect-equal", action="store_true")
    args = parser.parse_args()
    baseline_root = cast(Path, args.baseline)
    candidate_root = cast(Path, args.candidate)
    workspace = cast(Path, args.workspace)
    output = cast(Path, args.output)
    same = cast(bool, args.expect_equal)
    baseline, candidate = inspect(baseline_root), inspect(candidate_root)
    changes = compare(baseline, candidate)
    changed_case_fields: dict[str, list[str]] = {}
    for cid, row in candidate.cases.items():
        old = baseline.cases[cid]
        require(
            old["source_digest"] == row["source_digest"],
            "upstream source bytes changed",
        )
        left, right = obj(old["case"]), obj(row["case"])
        keys = [
            key
            for key in sorted(set(left) | set(right))
            if left.get(key) != right.get(key)
        ]
        if keys:
            changed_case_fields[cid] = keys
    if same:
        require(
            not changes and not changed_case_fields, "unexpected corrected-run delta"
        )
    else:
        require(
            changed_case_fields == {"tools": ["logos_policy", "logos_policy_sha256"]},
            "unexpected source/profile delta",
        )
        require(
            all(change["added"] == [] for change in changes),
            "unexpected new diagnostic",
        )
        expected = {
            ("chi", "gglint", "strict"): 1,
            ("modernc-sqlite", "gglint", "strict"): 2,
            ("toml", "gglint", "strict"): 1,
            ("tools", "gglint", "strict"): 7,
            ("modernc-libc", "gglint", "strict"): 2,
            ("protobuf", "logos-lint", ""): 2,
        }
        require(
            {
                (text(c["case"]), text(c["stage"]), text(c["mode"])): len(
                    seq(c["removed"])
                )
                for c in changes
            }
            == expected,
            "unexpected diagnostic delta inventory",
        )
        require(
            all(
                obj(r)["rule"] == "chanblock"
                for c in changes
                if c["stage"] == "gglint"
                for r in seq(c["removed"])
            ),
            "non-chanblock gglint delta",
        )
        expected_removals(changes)
    report: dict[str, object] = {
        "schema_version": 1,
        "accepted": True,
        "scope": "read-only retained lint-stream, invocation, source-pin and delta audit; no Go execution",
        "baseline": str(baseline_root),
        "candidate": str(candidate_root),
        "report_sha256": {
            "baseline": sha(baseline_root / "corpus/report.json"),
            "candidate": sha(candidate_root / "corpus/report.json"),
        },
        "matrix_cells_per_run": 196,
        "lint_cells_per_run": 112,
        "positive_lint_cells_per_run": 108,
        "incomplete_decorder_cells_per_run": 4,
        "lint_invocations_per_run": candidate.lint_runs,
        "repeat_pairs_per_run": candidate.repeats,
        "raw_stream_hashes_per_run": len(candidate.hashes),
        "changed_case_fields": changed_case_fields,
        "diagnostic_changes": changes,
        "source_receipts": source_receipts(workspace, candidate, changes),
        "gglint": tools_receipt(workspace, candidate_root, candidate),
        "normalized_arrays": {
            "|".join(key): [decode(value) for value in values]
            for key, values in sorted(candidate.lint.items())
        },
        "raw_streams": {"baseline": baseline.hashes, "candidate": candidate.hashes},
    }
    output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(
        json.dumps(
            {
                key: report[key]
                for key in (
                    "accepted",
                    "matrix_cells_per_run",
                    "lint_cells_per_run",
                    "lint_invocations_per_run",
                    "repeat_pairs_per_run",
                    "raw_stream_hashes_per_run",
                    "changed_case_fields",
                )
            }
        )
    )
    print(f"diagnostic delta cells: {len(changes)}")


if __name__ == "__main__":
    main()
