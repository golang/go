# Completed upstream result at 9909feb2

The [upstream job](https://github.com/gosuda/LoGOs/actions/runs/43951103189/job/133593504486)
completed with failure at 2026-11-16 21:43:12 UTC. The candidate was exactly
`9909feb26fe92b124f17c11fdf0022be7a643188`, with source tree
`df267333b1d5c5727e2477215a6807cae52f8e18`.

The complete [raw job log](upstream.raw.log) contains 264,190 UTF-8 bytes and
264,188 characters. Every character was read back and compared against the
GitHub API result. SHA256:
`3844f43ee5aabd686240db91f65c986ececaaedfe85f8641cb030b200a43c191`.
The saved [completed job metadata](jobs-completed.json) records each independent
step's final outcome.

The [artifact ZIP](logos-upstream-43951103189-1.zip), artifact `14274507833`, has
32,067 bytes and SHA256
`7be2f648a9c9789a3140e0c2525c8e5775f5b7ce054568d82e7d3c2313079ae0`.
All ten entries were safely extracted. Their hashes and the independent result
checks are recorded in [independent-upstream-audit.json](independent-upstream-audit.json).

## Completed partitions

| Partition | Numeric exits: driver / capture | Observed result |
| --- | --- | --- |
| Exact `cmd/go`, timeout scale 4 | 0 / 0 | Passed in 1533.587 seconds. |
| Every other dist entry, timeout scale 1 | 1 / 0 | Two packages failed; details below. |

The unchanged inventory contains 666 unique dist names. The two selected sets
contain 1 and 665 names; they are disjoint and their union equals the complete
inventory. Its recorded SHA256 is
`5b4fb09e6d180e745995ec1d7ac4f614750b9633c996894acf07a59812dcdfd4`.
This proves selection coverage. It does not turn the failed complement into
successful execution.

The first package failure was `cmd/compile/internal/logos` at 20:59:12 UTC,
after 240.173 seconds. It reproduces the already preserved SIMD defects:
the generated consumer cannot import `simd/internal/bridge` or resolve `simd`,
and the LoGOs producer emits twelve explicit parameter masks of `1` where the
frozen real SIMD checks require `0`. The receiver flags retain their expected
true/true/false values. No earlier unrelated failing package appears in the
complete log.

The second failure was the complete `cmd/internal/testdir` package at
21:17:23 UTC. Its package alarm fired after ten minutes; the reported duration
was 600.050 seconds. No individual fixture assertion failure preceded this
alarm. Four fixtures were active:

| Fixture | Active age at the package alarm |
| --- | --- |
| `Test/logos/run/json_key_dispatch_shape.lgo` | 1 second |
| `Test/logos/run/json_marshal_test.lgo` | 17 seconds |
| `Test/logos/run/json_static_encoder_v1_test.lgo` | 37 seconds |
| `Test/rangegen.go` | 76 seconds |

The stack also contains 37 `testing.(*T).Parallel` wait frames. The active
LoGOs fixtures are waiting for their normal child commands through the existing
harness. The complete LoGOs-only fixture command in the independent unit job
passed in 355.656 seconds under its 60-minute package cap.

## Capacity assessment

The evidence supports an aggregate package deadline: substantial fixture work
remained queued, one fixture started only a second before the alarm, and none
of the four active fixtures had run for ten minutes. It does not establish a
test-specific hang. A bounded larger package budget still needs a successful
complete run; this observation alone is not a pass.

The exact dist name is `cmd/internal/testdir:0_1`. In this source,
`cmd/dist/test.go` registers the normal fixture suite with one default shard,
names it through the package plus `%d_%d` variant, and gives it no explicit
timeout. `goTest.buildArgs` therefore leaves Go's ten-minute default at scale 1
and supplies a twenty-minute timeout at scale 2. The fixture harness queues its
cases through `t.Parallel`.

The recommended retry is a third complete dist partition for the coherent
normal testdir shard set, using scale 2 and a 25-minute step bound. The complete
`cmd/go` partition keeps scale 4; all remaining entries keep scale 1. The new
selection proof must show three disjoint sets whose union is still the original
unfiltered inventory. No fixture, assertion, skip, builder identity, or sharding
setting needs to change.

The original two-way inventory, raw logs, timeout stack, and numeric exits are
retained without modification. This audit ran no Go command locally.
