# Native CI at 9909feb2

## Exact evidence and outcome

The unit job in [run 43951103189](https://github.com/gosuda/LoGOs/actions/runs/43951103189) completed with failure. The independent scripts and upstream jobs remained running at the latest recorded snapshot. No job was cancelled during this review.

- Head: `9909feb26fe92b124f17c11fdf0022be7a643188`.
- Tree: `59be5e6916c8b2b173a19f5f6a55e544ba81af80`.
- Source tree: `df267333b1d5c5727e2477215a6807cae52f8e18`.
- Unit job: `133593503956`.
- [Full raw unit log](unit.raw.log): 94,490 UTF-8 bytes, SHA256 `7ca5bf0702303e5c1a4b2429938e3f6dbc116e7a8b4cd0800a787dbc4da18baa`. Its complete 94,488-character text was independently read back and matched the retrieved job log exactly.
- [Latest job snapshot](jobs-205635.json), recorded 2026-11-16 20:56:35 UTC.
- [Original artifact ZIP](logos-unit-43951103189-1.zip), artifact `14272030204`: 37,203 bytes, SHA256 `d4aa5e7a0aebd40acb5c832af3bc3d62599061014a0f1c7ae1ecfab82498e2fa`. The 40 entries, totalling 283,173 uncompressed bytes, were checked for absolute paths, traversal and symlinks before extraction. See [download record](unit-artifact-download.json).

The first command in the unit step was the compact-environment wrapper followed by `go test -count=1 -short` over the declared LoGOs package list. It failed in `cmd/compile/internal/logos`, specifically `TestCompileSIMDTaggedMethodFacts`. Subsequent commands within that same shell step did not execute. Those unexecuted commands include the logos/LSP race tests and the runtime metrics/arena variants; they are not counted as passing.

Independent later steps passed: explicit seven-event Wasm execution, compiler fixtures, formatting, vet, native lint with zero issues, tagged-package controls, ld/work/test race invariants, generation controls, and the two intended regression negative controls. The tagged-method step failed in its real compiler integration phase.

## Independent artifact accounting

The raw JSONL files were parsed directly, separately from the hosted acceptance reports.

| Phase | Named runs | Named passes | Named failures | Meaning |
| --- | ---: | ---: | ---: | --- |
| Wasm | 7 | 7 | 0 | All required runtime controls executed |
| Tagged package old-production negative | 2 | 0 | 2 | Expected regression rejected |
| Tagged package candidate | 150 | 150 | 0 | Positive controls passed |
| Tagged method old-codec negative | 2 | 0 | 2 | Expected grammar regression rejected |
| Tagged method old-package-guard negative | 1 | 0 | 1 | Expected lazy-scope regression rejected |
| Tagged method facts | 72 | 72 | 0 | Codec and writer controls passed |
| Tagged method logos | 17 | 14 | 3 | Real compiler root and both driver children failed |

There were no skip events in these seven transcripts. Each negative transcript also ended with its expected package failure. Source/tool snapshots before and after each helper are equal. The installed driver SHA256 is `88da8bd9d078e7a9c71973f5ea6e937fa5720670b349088321fe9c2821b2c905`; compiler is `0d4d73bf90c0db65971ad63c7dd6b3518a6b3a062d9f4d6735d652bc3efde9f4`; linker is `5175844b844d061ab94197916f4963803e1d369fc7b52baea86d06c602cefbfa`.

The later environment-normalization and generator-identity failures in the full log are intentional mutation controls. After removing those overlays, `cmd/go/internal/test` and `go/types` passed again. These expected failures must not be presented as candidate regressions.

Reports and events are under [artifact/logos-regression-evidence](artifact/logos-regression-evidence). The tagged-package report is named `acceptance.json`; the Wasm and tagged-method reports are named `report.json`.

## Concrete tagged-method failures

The frozen real source is `src/simd/testdata/iface/iface.go`, SHA256 `00adc9cf8b53e4e78ef162d7675b847b11f688b0cdab9ce18739b9a79a5571dd`. Its copy was checked unchanged. The frozen compiler test is SHA256 `16ac4b0eb928d29b23dfe12d7bb11311db4c8b6f7bdf4d6e805983c59366cf5c`.

Both installed drivers failed a normal `build -p=1 ./consumer` with:

```text
consumer/consumer.go:1:1: could not import simd/internal/bridge (open : no such file or directory)
consumer/consumer.go:1:1: undefined: simd
```

This is not a manual importer/export-map lookup in the test. The archive map is used only to locate the producer archive for reading facts. The consumer is an ordinary source package importing the real producer; the compiler dependency failure is under separate investigation.

The logos profile also emitted `ParamMutated:1` for all twelve expected records: Foo, Bar and Qux across simd0, simd128, simd256 and simd512. Their separate receiver flags matched the frozen expectations: true, true and false respectively. Plain fork Go emitted no mutation summaries, as required.

## Mutation-mask contract and source-derived cause

The receiver does not consume mask bit zero. `facts/write_const.go:funcMutations` includes it for taint tracking but explicitly skips it before incrementing the mask bit. The first explicit parameter consumes bit zero. Serialization stores `ReceiverMutated` separately; the call consumer reads `sig.Params()` using the same explicit-parameter indices. SPEC section 5 defines separate receiver and parameter summaries, and existing `TestEmitGoParamMutatedFacts` requires `(*Counter).SetN` to have parameter mask zero even though its receiver is written.

The source-derived defect is in `types2.logosReferenceFreeAlong`: its array branch recursively tests the element type even when the array length is zero. The SIMD marker chain is:

- `simd.Float32s` contains a blank `_simd` field.
- `simd._simd` is defined from `bridge.ZeroSized`.
- `bridge.ZeroSized` contains `[0]func(*ZeroSized) *ZeroSized`.
- The fixed-width amd64 vector types have analogous v128/v256/v512 markers containing `[0]func()`.

These zero-length arrays store no function or pointer values. The current predicate nevertheless reports the enclosing value as reference-bearing. In Qux, returning the value therefore marks the first parameter. In Foo and Bar, the unknown standard-library Add parameter summary causes `markMention(x.Field)`, which marks x for the same reason.

A narrow proposed repair is to classify arrays with exactly `Len()==0` as reference-free, retaining recursion for every other length. Pointers or slices of zero-length arrays must remain reference-bearing, as must positive-length arrays containing references. This is a proposal from source review, not an executed repair. New frozen controls should prove those boundaries before implementation. No existing expectation or real SIMD source was changed, and no local Go command was run.

The exact current production files used in this trace are preserved in [mask-source](mask-source), with [hash manifest](mask-source/manifest.json). Their bytes were retrieved from the exact failing head. The local fact writer was independently compared with the remote bytes and matched.

