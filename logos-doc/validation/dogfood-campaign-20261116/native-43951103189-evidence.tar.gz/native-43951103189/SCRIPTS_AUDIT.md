# Native scripts at 9909feb2

GitHub job [133593504756](https://github.com/gosuda/LoGOs/actions/runs/43951103189/job/133593504756)
completed successfully at 2026-11-16 21:03:41 UTC. Its exact source was
`9909feb26fe92b124f17c11fdf0022be7a643188`, with source tree
`df267333b1d5c5727e2477215a6807cae52f8e18`.

The complete [raw log](scripts.raw.log) was fetched again from the job API and
compared with the saved file: all 44,147 characters, including the initial BOM,
match. Its 44,149 UTF-8 bytes have SHA256
`d503aa2003244f4190c550755bb533692f29b6d2acc326507def70a1f78c68bf`.
The retained [artifact ZIP](logos-scripts-43951103189-1.zip) has 16,830 bytes and
SHA256 `286e0f13dcb5369a0f395088a98048b6cd3c6bf007227db90bd580af7190865f`.

## Observed checks

- The broad `cmd/go -run 'Script/^logos_'` invocation passed in 1040.622 seconds.
- The separate race invocation for external-test ownership, inherited test
  experiments, plugins, and test cache behavior passed in 26.699 seconds.
- The inline-context gate rebuilt the old linker through its frozen overlay,
  observed the intended failure, restored the candidate linker, and passed the
  same frozen script with the candidate.

The [independent artifact audit](independent-scripts-audit.json) checks the raw
events and statuses. Both inline phases contain exactly one run and one result
for `TestScript` and `TestScript/logos_cap_inline_context`. The old-linker phase
exits 1 with both named tests failing and the safe dependency incorrectly blamed
for `syscall.Socket`. The candidate exits 0 with both passing. Both stderr files
are empty; neither phase contains a skipped or additional named test.

The original negative witness includes inline diagnostics for both copies of
`sync.(*Once).Do`. The archived old linker hash differs from the installed
candidate and matches the hash recorded during negative execution. All four
tool hashes match before and after restoration. The source identities and
tracked diffs are unchanged, and the runner summary records `link_replaced=0`.

This audit only reads hosted evidence. It does not execute Go locally. The unit
job remains failed for the separately documented zero-array and SIMD import
defects. At the latest saved [job snapshot](jobs-212708.json), the upstream
complement had failed and the independent complete `cmd/go` partition was still
running; its failure cause is not yet established by a complete job log.
