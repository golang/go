# Native run 43951103189: final evidence bundle

This bundle preserves the complete observed result of
[run 43951103189](https://github.com/gosuda/LoGOs/actions/runs/43951103189).
It is evidence from the original candidate, separate from all proposed repairs.

| Identity | Value |
| --- | --- |
| Candidate | `9909feb26fe92b124f17c11fdf0022be7a643188` |
| Root tree | `59be5e6916c8b2b173a19f5f6a55e544ba81af80` |
| Source tree | `df267333b1d5c5727e2477215a6807cae52f8e18` |

## Final results

| Job | Final result | What the evidence establishes |
| --- | --- | --- |
| Unit, `133593503956` | Failure | Known real SIMD import and mutation-mask failures. Independent Wasm, compiler fixture, lint, component, and negative-control steps completed. |
| Scripts, `133593504756` | Success | Broad native scripts, race subprocess controls, and the old-linker negative plus restored-candidate positive control passed their gates. |
| Upstream, `133593504486` | Failure | Complete `cmd/go` passed in 1533.587s. The complement reproduced the SIMD failures and reached the complete compiler-fixture package's 600s alarm. |

All three complete raw job logs, original artifact ZIPs, extracted artifact
contents, final job metadata, and earlier timestamped snapshots are included.
The raw log files preserve the full decoded API text and were compared with
their API results after writing. Original artifact hashes are recorded in the
three `*-artifact-download.json` files. No job was cancelled by this review.

The older `README.md` is the preserved unit-stage investigation, including its
then-pending job statuses and proposed repair. The final results here supersede
that historical status. `SCRIPTS_AUDIT.md` and `UPSTREAM_AUDIT.md` contain the
later detailed audits. The three `independent-*-audit.json` files record checks
performed directly on the saved raw evidence.

## Exact coverage and limits

The unit helper transcripts contain 7 Wasm passes, 150 tagged-package candidate
passes, 72 tagged-method codec/writer passes, and 17 tagged-method compiler
identities with 14 passes and 3 failures. The old package, codec, and lazy-scope
negatives each produce exactly their expected failures. No skips appear in
those transcripts. The original candidate reports remain failed where they
failed. Later commands in the first failing unit shell step did not execute;
the unit-stage audit lists them explicitly.

The scripts artifact preserves two exact named results for each inline-context
phase. The old linker exits 1 and falsely attributes `syscall.Socket` to the
safe dependency. The restored candidate exits 0 with both named tests passing.
The broad scripts and independent race subprocess gate also pass.

The upstream inventory has 666 unique entries. The original two-way split is
disjoint and complete: exact `cmd/go` plus 665 complement entries. The retained
numeric driver/capture exits are `0/0` and `1/0`, respectively. The complement
contains exactly two failing package results: `cmd/compile/internal/logos` and
`cmd/internal/testdir`. Selection coverage is not a claim that the failed
compiler-fixture package completed.

The compiler-fixture timeout occurred with four active cases aged 1, 17, 37,
and 76 seconds and 37 parallel wait frames. The separate LoGOs-only fixture
command passed in 355.656s. Exact timeout/scheduling source from the failing
commit is archived in `capacity-source`, with source URLs and hashes. This
supports a bounded capacity retry; it does not prove that retry will pass.
The proposed third complete testdir partition at scale 2 remains pending.

## Source and tool receipts

The unit Wasm, tagged-package, and tagged-method helpers have equal before/after
source and tool receipts. The scripts inline-context helper also has equal
source receipts and identical restored hashes for all four tools. Its negative
linker hash is recorded separately and differs from the candidate.

| Tool | Candidate SHA256 in the unit and scripts receipts |
| --- | --- |
| `go` and `logos` | `88da8bd9d078e7a9c71973f5ea6e937fa5720670b349088321fe9c2821b2c905` |
| `compile` | `0d4d73bf90c0db65971ad63c7dd6b3518a6b3a062d9f4d6735d652bc3efde9f4` |
| `link` | `5175844b844d061ab94197916f4963803e1d369fc7b52baea86d06c602cefbfa` |

The upstream job records the exact checkout and full commands, inventory,
profiles, logs, and exits. It did not capture an equivalent after-run binary
receipt; the unit/scripts identity result is not extended to that job.

## Verify or reproduce the bundle

`SHA256SUMS` covers every other file in this directory. The included Python
script checks file inventory, containment, hashes, and absence of symlinks.
It runs no Go command.

```sh
PYTHONDONTWRITEBYTECODE=1 uv run --no-project --no-config --python 3.12.14 --no-python-downloads python repack.py
PYTHONDONTWRITEBYTECODE=1 uv run --no-project --no-config --python 3.12.14 --no-python-downloads python repack.py --output ../native-43951103189-evidence.tar.gz
```

The output must be a new file outside this directory. The archive uses sorted
paths, fixed permissions, zero UID/GID and timestamps, a fixed root name, and a
zero gzip timestamp. Packaging used Python 3.12.14 and zlib 1.3.2. Two local
repacks were compared for byte equality. This bundling step executes only
Python and filesystem checks; it does not rerun or relabel any hosted result.
