# Installed environment and runtime acceptance

These checks use the fresh toolchain built from LoGOs commit
`22ab6f7a169e905d9fde5e345db101735a321486`, source tree
`8d74f82a97b8509400372ae4818525f19e7105ef`. The build and installed-gate reports
record the same identities:

| Artifact | SHA-256 |
| --- | --- |
| `go` and `logos` | `d29b8a33f824d49b12186a2673ece7c7830561543c47eb8ea142901d6bfff091` |
| Compiler | `b624b78adb119ce41e6d3bad6869da0dcc2bbf660f270f79d7caecf3198fc9b2` |
| Linker | `2661514a2720fb12b65dc842cd896a01eff71ac37477f68932dd8493fc032617` |

## Environment/cache package

The complete `cmd/go/internal/test` package passes its uncached normal run
(78.141 seconds including compilation), race run (82.818 seconds), and vet
(8.694 seconds). The report requires actual JSON `run` and `pass` events for
`TestLogosTestExperimentEnv`, `TestLogosTestExperimentCache`, and
`TestLogosTestExperimentEnvNames`. It does not accept an empty test selection.

Evidence: `installed/unit/report.json` and its raw stdout/stderr files.

## Native scripts

The two exact frozen scripts pass under the race-enabled cmd/go harness,
`-parallel=1`, and CPU affinity 0. They execute seven environment profiles and
three plugin controls. The plugin controls build a real plugin in a plain-Go
subprocess, open it, check the exported function type, and require result 42.
There are no skipped script tests. The complete successful invocation took
172.408 seconds.

Evidence: `installed/scripts-valid-vcs/report.json` and its raw logs. The
original frozen test hashes and all driver/compiler/linker/assembler/cgo hashes
match before and after both successful installed gates. The source directory
remains clean.

### Earlier environment failure retained

The first native-script invocation passed all seven environment profiles but
failed at the plugin script's first ordinary-Go control. Its child `go build`
reported `error obtaining VCS status: exit status 128`. It did not reach the
logos plugin controls. That complete failed report is retained unchanged at
`installed/scripts/report.json`.

An independent probe established that both official stock Go and fork Go fail
the Git lookup in that temporary context and succeed inside a valid isolated
Git context. The successful retry used
`/workspace/scratch/d8d410ec882d/tmp-logos-vcs` and included `/usr/local/bin` in
PATH. It changed no production source, frozen test, assertion, plugin profile,
or VCS stamping flag. The probe is recorded separately under
`installed-audit/git-probe-repaired/` in the workspace.

The initial scratch runner is preserved at `installed/runner-initial.py`,
SHA-256 `72a8d61374e4fcdd2ab9ba7e086d89ac74bd85b001ece70723ece2d58433367f`.
The current runner records its own hash in each later report.

The cmd/go script harness constructs a new allowlisted environment and omits
`GOMAXPROCS`, `GOMEMLIMIT`, and `GOFLAGS`. CPU affinity therefore bounds its
child compiler concurrency; the outer memory target does not constrain those
script children. The successful report states this resource scope explicitly.

## xxhash runtime comparison

All nine commands passed against the exact source pin
`ab37246c889f9db16b606fda1c232d659df9271d`. Every candidate has a passing stock
baseline in this same report. JSON events require the root `TestAll` execution
and, in the plugin configuration, the actual `TestDynamic` execution.

| Configuration | Stock Go | Fork Go | logos | Test/subtest pass events per driver |
| --- | --- | --- | --- | ---: |
| Complete root suite, assembly, cgo disabled | Pass, 1.439 s | Pass, 1.375 s | Pass, 42.414 s | 159 |
| Complete root suite, purego tag, cgo disabled | Pass, 3.155 s | Pass, 2.842 s | Pass, 3.600 s | 159 |
| All packages, cgo enabled, matched plugin profile | Pass, 19.719 s | Pass, 12.243 s | Pass, 12.739 s | 223 |

The plugin supplement explicitly selects `-O=1` for the logos host to match
the original upstream plain-Go child. The first two configurations retain
their normal optimization defaults. All stages retain the already recorded
replay flags `-mod=readonly -buildvcs=false -p=1`; no new stamping override was
introduced to make a native script pass. The original mixed-O2/O1 plugin
failure remains a separate result and is not superseded by this comparison.

Each all-package invocation also reports one package-level `skip` event for
`github.com/cespare/xxhash/v2/xxhsum`, which has no tests. It is not a skipped
`TestDynamic` or another skipped test function. The two root configurations
have no skip events.

Evidence: `tmp-logos-vcs/corpus-runtime-xxhash/report.json`, its logs,
`context.json`, and the exact scratch runner snapshot `runner.py`. These paths
are relative to the original workspace. The source and all tool identities
match before and after the replay.

## Purego FFI runtime comparison

The unchanged published `replay_ffi.py` passes under all three drivers at exact
upstream pin `cfb65d5afce13c34d118c6cf769bc866a00adecb`:

| Driver | Result | Time | Named test executions |
| --- | --- | ---: | ---: |
| Stock Go | Pass | 2.127 s | 8 |
| Fork Go | Pass | 1.937 s | 8 |
| logos | Pass | 1.730 s | 8 |

All eight named tests start and pass in every driver, with no skips or failed
subtests. They exercise symbol lookup, nested C++ loading, a native call,
callbacks from C, mixed floating-point and integer arguments, stack arguments
and callback results, and stack alignment. The report therefore proves 24
named test executions across the three drivers, with a successful stock
baseline. A full purego suite pass is not claimed. Earlier session observations
of credential/all-thread syscall failures remain outside these eight-test
results.

The published runner and its assertions remain unchanged. Its existing
one-worker, 384 MiB memory target and recorded replay flags are retained.
Both the private work directory and temporary directory inherit the valid
isolated Git context. Evidence is under
`tmp-logos-vcs/corpus-runtime-ffi/`, including raw outputs, per-stage tool
identities, context provenance, and end-of-run C/C++ compiler, linker, and libc
version fingerprints.

## Final identity check

`final-identity.json` verifies the live driver/compiler/linker/assembler/cgo
files against all successful reports, verifies the original frozen tests and
source tree, rechecks pristine xxhash/purego source hashes, and records hashes
for the complete reports. The installed source remains clean at the exact
commit and source tree above. The initial failed script report is retained
alongside the successful retry.

The complete upstream `run.bash` regression gate and cross-platform runtime
execution are separate claims and are not established by these results.
