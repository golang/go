# Focused corpus recovery

The restored LoGOs checkout is PR #71 head
`22ab6f7a169e905d9fde5e345db101735a321486`. Its `src` Git tree is
`8d74f82a97b8509400372ae4818525f19e7105ef`. The source directory is clean.
The published corpus manifest SHA-256 is
`328c7de4fc02755244d319099bdc00c400821cc7dd0aa5f78ee2ae2f933e5aa3`.

## Restored inputs

The four exact Git commits below were fetched successfully from their recorded
upstream hosts. HEAD, origin, clean worktree, and tracked-file content hashes
were checked with the published corpus runner. Every content hash matches the
corresponding record in the published initial-corpus summary.

| Source | Full commit | Tracked files |
| --- | --- | ---: |
| cespare/xxhash | `ab37246c889f9db16b606fda1c232d659df9271d` | 24 |
| ebitengine/purego | `cfb65d5afce13c34d118c6cf769bc866a00adecb` | 195 |
| mattn/go-sqlite3 | `4cddc794daa0340d50de741dae025421bbdbba0c` | 109 |
| GitLab cznic/sqlite | `92d72a45bcb65ab33bbe79c8667f2b8b529ae902` | 2,022 |

`recovered-sources.json` contains the complete source identities, content hashes,
paths, and manifest identity. The first three modules have no external module
requirements. Their focused assembly, purego-tag, plugin, FFI, and cgo runtime
checks need the recorded toolchains and the installed C/C++ compilers.

The pinned modernc SQLite dependency download completed with exit status zero
in 23.212 seconds and empty stderr. It used stock Go 1.27.4, the official module
proxy and checksum database, one worker, and a 256 MiB Go memory target. Its
full command, environment, download metadata, and output hashes are under
`dependency-download/`. The command operated on a verified private source copy.
`go mod verify` subsequently reported `all modules verified`; both `go.mod` and
`go.sum` remained byte-identical to the pinned checkout.

## Published evidence recovered

The initial corpus archive and its README, summary, and external payload hash
list pass their published SHA-256 verification. The archive preserves three
completed initial campaigns: default-policy builds, permission builds, and
the 78-cell gglint report matrix. It has 723 regular files. Those compiler
campaigns executed no upstream test commands; their outcomes must not be
counted as runtime tests.

The branch also preserves the earlier fixture, language, lint, and SQLite
runtime reports, plus the synthetic plugin RED/GREEN and optimization-causality
evidence. These results retain their original toolchain identities.

The later local xxhash runtime report, twelve-cell dependency replay, and
interrupted final sweep were not present in the recovered branch or archive.
Earlier observations of those runs survive in the session record, but their
raw local artifacts cannot be represented as recovered evidence. New replays
use new output directories and do not revise those observations.

## Installed acceptance preparation

`replay_installed.py` prepares uncached normal/race/vet environment gates,
both native script gates, and a nine-command xxhash runtime comparison. It
records required JSON test run/pass events, frozen test hashes, source-tree
identity, and installed driver/compiler/linker/assembler/cgo identities before
and after each report. The current runner passes Ruff and strict Pyright.

The xxhash plugin comparison explicitly selects `-O=1` for its logos host to
match the unmodified upstream plain-Go child. Assembly and purego root cases
retain their normal defaults. This supplemental profile does not replace or
reclassify the original mixed-O2/O1 plugin failure. The original plugin test,
its correction rationale, and causal controls remain in
`logos-doc/validation/test-experiments/`.

The published `replay_ffi.py` will independently require all eight named
upstream FFI tests to execute and pass without skips under stock Go, fork Go,
and logos. The SQLite runtime and reviewed-policy replay scripts remain
available for their separately recorded configured and default-policy results.

At the time this recovery record was prepared, the fresh fork build was still
running and no new focused runtime or installed gate had been executed.
Subsequent installed results are recorded separately in `INSTALLED.md`.
