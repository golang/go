#!/usr/bin/env python3
# pyright: strict
"""Record installed environment gates and a separate matched-O1 xxhash replay."""

from __future__ import annotations

import argparse
import sys
from dataclasses import asdict
from pathlib import Path
from typing import cast

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parent
ROOT = WORKSPACE / "LoGOs"
HARNESS = ROOT / "misc/logos-dogfood"
sys.path.insert(0, str(HARNESS))

from run import (
    Assessment,
    Case,
    Run,
    assess_build,
    copy_source,
    decode,
    execute,
    file_hash,
    git,
    obj,
    save_report,
    string,
    toolchain_identity,
    verify_source,
)

BINARIES = {
    "oracle": WORKSPACE / "toolchains/go/bin/go",
    "go": ROOT / "bin/go",
    "logos": ROOT / "bin/logos",
}
TEMP = WORKSPACE / "tmp-logos-vcs"
FROZEN = ROOT / "logos-doc/validation/test-experiments/tests-corrected.sha256"


def environment(stage: str, cgo: int = 1) -> dict[str, str]:
    return {
        "PATH": f"{BINARIES[stage].parent}:/usr/local/bin:/usr/bin:/bin",
        "GOCACHE": str(WORKSPACE / "corpus-cache" / stage),
        "GOMODCACHE": str(WORKSPACE / "modcache"),
        "GOTOOLCHAIN": "local",
        "GOWORK": "off",
        "GOENV": "off",
        "GOPROXY": "off",
        "GOSUMDB": "off",
        "GOTELEMETRY": "off",
        "CGO_ENABLED": str(cgo),
        "GOFLAGS": "-mod=readonly -buildvcs=false -p=1",
        "GOMAXPROCS": "1",
        "GOMEMLIMIT": "256MiB",
        "TMPDIR": str(TEMP),
        "CC": "/usr/bin/cc",
        "CXX": "/usr/bin/c++",
        "GOOS": "linux",
        "GOARCH": "amd64",
        "GOAMD64": "",
        "GOEXPERIMENT": "",
    }


def source_identity() -> dict[str, object]:
    status = git(ROOT, "status", "--porcelain", "--untracked-files=all", "--", "src")
    if status:
        raise ValueError(f"candidate source has local changes: {status}")
    frozen: dict[str, str] = {}
    for line in FROZEN.read_text().splitlines():
        expected, relative = line.split(maxsplit=1)
        actual = file_hash(ROOT / relative)
        if actual != expected:
            raise ValueError(f"frozen test changed: {relative}")
        frozen[relative] = actual
    return {
        "revision": git(ROOT, "rev-parse", "HEAD"),
        "src_tree": git(ROOT, "rev-parse", "HEAD:src"),
        "src_status": status,
        "frozen_tests": frozen,
    }


def identities(out: Path, phase: str, include_stock: bool) -> dict[str, object]:
    result: dict[str, object] = {}
    for stage, binary in BINARIES.items():
        if stage == "oracle" and not include_stock:
            continue
        identity = toolchain_identity(
            binary, environment(stage), ROOT / "src", out / "tools" / f"{phase}-{stage}"
        )
        expected_root = binary.parent.parent
        if identity.get("goroot") != str(expected_root):
            raise ValueError(f"unexpected toolchain root for {stage}: {identity}")
        for name, tool in obj(identity["tools"]).items():
            if not obj(tool).get("sha256"):
                raise ValueError(f"missing installed tool: {stage}/{name}")
        identity["driver_sha256"] = file_hash(binary)
        result[stage] = identity
    return result


def test_events(run: Run, required: tuple[tuple[str, str], ...]) -> dict[str, object]:
    records = [
        obj(decode(line))
        for line in Path(run.stdout).read_text().splitlines()
        if line.strip()
    ]
    started = [
        (row.get("Package"), row.get("Test"))
        for row in records
        if row.get("Action") == "run"
    ]
    passed = [
        (row.get("Package"), row.get("Test"))
        for row in records
        if row.get("Action") == "pass" and "Test" in row
    ]
    missing = [
        list(pair) for pair in required if pair not in started or pair not in passed
    ]
    failed = [row for row in records if row.get("Action") == "fail"]
    skipped = [row for row in records if row.get("Action") == "skip"]
    return {
        "started_count": len(started),
        "passed_count": len(passed),
        "required": [list(pair) for pair in required],
        "missing_required_run_or_pass": missing,
        "failures": failed,
        "skips": skipped,
        "package_passes": sorted(
            string(row["Package"])
            for row in records
            if row.get("Action") == "pass" and "Test" not in row
        ),
        "accepted": run.returncode == 0
        and not run.error
        and not run.timed_out
        and bool(started)
        and not missing
        and not failed,
    }


def native(mode: str, out: Path, report: dict[str, object]) -> bool:
    required = tuple(
        ("cmd/go/internal/test", name)
        for name in (
            "TestLogosTestExperimentEnv",
            "TestLogosTestExperimentCache",
            "TestLogosTestExperimentEnvNames",
        )
    )
    checks = (
        (
            (
                "normal",
                (
                    "test",
                    "-json",
                    "-count=1",
                    "-short",
                    "-timeout=10m",
                    "cmd/go/internal/test",
                ),
                required,
            ),
            (
                "race",
                (
                    "test",
                    "-json",
                    "-count=1",
                    "-race",
                    "-short",
                    "-timeout=10m",
                    "cmd/go/internal/test",
                ),
                required,
            ),
            ("vet", ("vet", "cmd/go/internal/test"), ()),
        )
        if mode == "unit"
        else (
            (
                "scripts",
                (
                    "test",
                    "-json",
                    "-count=1",
                    "-race",
                    "-parallel=1",
                    "-timeout=20m",
                    "cmd/go",
                    "-run",
                    "Script/^logos_test_(experiment_env|plugin_experiment)$",
                ),
                (
                    ("cmd/go", "TestScript/logos_test_experiment_env"),
                    ("cmd/go", "TestScript/logos_test_plugin_experiment"),
                ),
            ),
        )
    )
    rows: list[dict[str, object]] = []
    report["rows"] = rows
    accepted = True
    prefix = ("/usr/bin/taskset", "-c", "0") if mode == "scripts" else ()
    for name, args, required_tests in checks:
        print(f"starting {mode}/{name}", flush=True)
        run = execute(
            (*prefix, str(BINARIES["go"]), *args),
            ROOT / "src",
            environment("go"),
            out / "logs" / name,
            1500,
        )
        row: dict[str, object] = {"name": name, "run": asdict(run)}
        passed = run.returncode == 0 and not run.error and not run.timed_out
        if required_tests:
            events = test_events(run, required_tests)
            row["events"] = events
            passed = passed and events["accepted"] is True
        row["accepted"] = passed
        accepted = accepted and passed
        rows.append(row)
        save_report(out / "report.json", report)
        print(
            f"finished {mode}/{name}: accepted={passed}, seconds={run.seconds}",
            flush=True,
        )
    return accepted


def xxhash(out: Path, report: dict[str, object]) -> bool:
    manifest = HARNESS / "corpus-runtime.json"
    parsed = decode(manifest.read_text())
    if not isinstance(parsed, list):
        raise TypeError("expected manifest array")
    cases = [Case.parse(value) for value in cast(list[object], parsed)]
    rows: list[dict[str, object]] = []
    report.update(
        {
            "rows": rows,
            "manifest_sha256": file_hash(manifest),
            "supplemental_profile": "logos host uses explicit -O=1 only in the cgo plugin case; upstream child remains plain go default O1; original unconfigured failure remains separate",
        }
    )
    accepted = True
    for case in cases:
        source = verify_source(
            case, WORKSPACE / "corpus-sources", WORKSPACE / "modcache", HARNESS
        )
        baseline: Assessment | None = None
        required = ((case.module, "TestAll"),)
        if case.id == "xxhash-plugin-cgo":
            required += ((case.module + "/dynamic", "TestDynamic"),)
        for stage, binary in BINARIES.items():
            work = TEMP / f"{out.name}-{case.id}-{stage}"
            copy_source(source, work)
            profile = (
                ("-O=1",) if stage == "logos" and case.id == "xxhash-plugin-cgo" else ()
            )
            tags = ("-tags=" + ",".join(case.tags),) if case.tags else ()
            command = (
                str(binary),
                "test",
                *profile,
                *tags,
                "-json",
                "-count=1",
                "-short",
                "-timeout=10m",
                *case.patterns,
            )
            print(f"starting {case.id}/{stage}", flush=True)
            run = execute(
                command,
                work,
                environment(stage, case.cgo),
                out / "logs" / case.id / stage,
                900,
            )
            events = test_events(run, required)
            assessment = assess_build(run, stage, baseline)
            if stage == "oracle":
                baseline = (
                    assessment
                    if events["accepted"] is True
                    else Assessment(
                        "upstream-failed", "required test execution proof failed"
                    )
                )
            passed = assessment.status == "pass" and events["accepted"] is True
            rows.append(
                {
                    "case": asdict(case),
                    "source_digest": source.digest,
                    "stage": stage,
                    "run": asdict(run),
                    "assessment": asdict(assessment),
                    "events": events,
                    "accepted": passed,
                }
            )
            accepted = accepted and passed
            save_report(out / "report.json", report)
            print(
                f"finished {case.id}/{stage}: accepted={passed}, seconds={run.seconds}",
                flush=True,
            )
        if (
            verify_source(
                case, WORKSPACE / "corpus-sources", WORKSPACE / "modcache", HARNESS
            ).digest
            != source.digest
        ):
            raise ValueError("upstream source changed during execution")
    return accepted


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("unit", "scripts", "xxhash"))
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    mode = string(args.mode)
    out = cast(Path, args.out).resolve()
    out.mkdir(parents=True, exist_ok=False)
    TEMP.mkdir(parents=True, exist_ok=True)
    source_before = source_identity()
    before = identities(out, "before", mode == "xxhash")
    report: dict[str, object] = {
        "complete": False,
        "accepted": False,
        "mode": mode,
        "runner_sha256": file_hash(Path(__file__)),
        "harness_sha256": file_hash(HARNESS / "run.py"),
        "source_before": source_before,
        "tools_before": before,
        "resource_scope": (
            "outer process has explicit Go resource limits; cmd/go scripts reset "
            "their environment, so child processes retain CPU affinity 0 but do "
            "not inherit GOMEMLIMIT or GOFLAGS"
            if mode == "scripts"
            else "one package worker, GOMAXPROCS=1, GOMEMLIMIT=256MiB"
        ),
    }
    save_report(out / "report.json", report)
    accepted = xxhash(out, report) if mode == "xxhash" else native(mode, out, report)
    after = identities(out, "after", mode == "xxhash")
    source_after = source_identity()
    keys = ("driver_sha256", "tools", "compiler_source_h1")
    unchanged = all(
        all(obj(before[name]).get(key) == obj(after[name]).get(key) for key in keys)
        for name in before
    ) and all(
        source_before[key] == source_after[key]
        for key in ("src_tree", "src_status", "frozen_tests")
    )
    report.update(
        {
            "complete": True,
            "accepted": accepted and unchanged,
            "unchanged": unchanged,
            "tools_after": after,
            "source_after": source_after,
        }
    )
    save_report(out / "report.json", report)
    print(
        f"complete {mode}: accepted={report['accepted']}, unchanged={unchanged}",
        flush=True,
    )
    if report["accepted"] is not True:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
