# Fresh installed LoGOs validation

Validation date: 2026-11-16 UTC. This directory records a fresh complete toolchain
build and focused installed gates for the combined graph, test-package ownership,
and test-subprocess environment repairs. Earlier RED and mutation-probe evidence
remains in the published branch's validation directories.

## Results

| Gate | Result | Wall time | Evidence |
|---|---|---:|---|
| Fresh `src/make.bash`, official Go 1.27.4 bootstrap | PASS, empty stderr | 676.635 s | [report](build/report.json), [log](build/make.stdout), [runner](build/run_gates.py) |
| Installed `go version` and `logos version` | PASS, Go 1.27.4 | 0.016 s combined | [component report](components-vcs/report.json) |
| Full `cmd/link/internal/ld`, `-count=1 -short` | PASS | 20.679 s | [output](components-vcs/ld.stdout) |
| Full `cmd/go/internal/work`, `-count=1 -short -race` | PASS | 6.261 s | [output](components-vcs/work-race.stdout) |
| Vet of both packages | PASS, empty output | 2.161 s | [component report](components-vcs/report.json) |
| Seven native capability scripts, `-count=1 -short -race` | 7 PASS, 0 skipped | 266.186 s | [report](scripts/report.json), [verbose output](scripts/capability-scripts-race.stdout), [runner](scripts/run_gates.py) |

The script set is `logos_cap_reloc`, `logos_cap_xtest_owner`,
`logos_cap_test_scope`, `logos_cap_shortest_frames`, `logos_cap_inline`,
`logos_cap_policy`, and `logos_cap_chains`. It verifies first-party external-test
ownership while retaining nested-dependency and ordinary `_test`-suffix denial
controls. The plain-Go controls also pass.

Each successful stage records the exact command and environment. Build and
component limits were `GOMAXPROCS=2`, `GOMEMLIMIT=512MiB`, `GOGC=25`, and
`GOFLAGS=-p=1`. Script execution additionally used `taskset -c 0` because its
child environment does not inherit the outer Go resource variables. All stages
used disk caches and private disk temporary directories.

## Exact identities

The checkout was clean before and after every completed stage. Both test reports
record `source_stable=true` and `tools_stable=true`.

| Input | Identity |
|---|---|
| Published commit | `22ab6f7a169e905d9fde5e345db101735a321486` |
| Repository tree | `f802c40618db24a1ff630189bd8052a9436540de` |
| `src` tree | `8d74f82a97b8509400372ae4818525f19e7105ef` |
| Installed `bin/go` and `bin/logos`, SHA-256 | `d29b8a33f824d49b12186a2673ece7c7830561543c47eb8ea142901d6bfff091` |
| Installed compiler, SHA-256 | `b624b78adb119ce41e6d3bad6869da0dcc2bbf660f270f79d7caecf3198fc9b2` |
| Installed linker, SHA-256 | `2661514a2720fb12b65dc842cd896a01eff71ac37477f68932dd8493fc032617` |
| Official bootstrap `bin/go`, SHA-256 | `de0ae3e082ce7599eae4fb69fa2ef1e43b8f31ffd3fce62cdf81930aa9005050` |

The [build report](build/report.json) also records bootstrap compiler/linker
hashes and the individual production and frozen-test source hashes. Before the
build, all four candidate executable paths were absent.

## Preserved VCS environment failure

The [original component run](components/report.json) failed only
`TestRISCVTrampolines`: its temporary module's child build could not obtain VCS
status. The [original output](components/ld.stdout) is retained. Minimal builds
under both available Git executables showed that Go selected the workspace
parent as its repository, where Git returned exit 128. The
[fork probes](git-probe/report.json) and
[official-Go reproduction](git-probe/oracle-original-report.json) preserve that
failure; changing Git executable alone did not fix it.

A local shared clone, without checked-out files, supplies valid existing Git
metadata around the disk temporary directory `tmp-logos-vcs`. Its HEAD is the
same pinned commit above. The [repaired-context probes](git-probe-repaired/report.json)
pass with both official Go and the installed fork. The unchanged full component
and script gates then pass in that context. No VCS-stamping flag, frozen test,
production source, or policy was changed for this repair.

## Scope still separate

These results cover the fresh complete build and the named installed gates.
The full upstream `run.bash --no-rebuild` milestone and real corpus runtime
replays require their own reports. The [full-gate preparation](upstream-gate-plan.md)
records prerequisites and a proposed isolated command; it is not a test result.
