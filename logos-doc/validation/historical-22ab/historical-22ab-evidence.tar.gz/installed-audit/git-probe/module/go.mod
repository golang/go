module gitprobe

go 1.27
