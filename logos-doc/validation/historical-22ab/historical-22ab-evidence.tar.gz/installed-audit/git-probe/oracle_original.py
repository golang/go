#!/usr/bin/env python3
# pyright: strict
"""Preserve the official oracle's matching workspace VCS failure."""

from __future__ import annotations

import sys
from dataclasses import asdict
from pathlib import Path

BASE = Path("/workspace/scratch/d8d410ec882d")
ROOT = BASE / "LoGOs"
sys.path.insert(0, str(ROOT / "misc/logos-dogfood"))

from run import decode, execute, obj, save_report, string  # noqa: E402


def main() -> None:
    out = BASE / "installed-audit/git-probe"
    target = out / "oracle-original-report.json"
    if target.exists():
        raise ValueError("oracle evidence already exists")
    previous = obj(decode((BASE / "installed-audit/components/report.json").read_text()))
    data = obj(previous["environment"])
    env = {key: string(value) for key, value in data.items()}
    env["GOROOT"] = str(BASE / "toolchains/go")
    env["GOCACHE"] = str(BASE / "cache-oracle")
    env["PATH"] = f"{BASE / 'toolchains/go/bin'}:/usr/local/bin:/usr/bin:/bin"
    run = execute(
        (str(BASE / "toolchains/go/bin/go"), "build", "-x", "-o", str(out / "oracle-original.bin"), "."),
        out / "module", env, out / "oracle-original", 120,
    )
    save_report(target, {"run": asdict(run)})
    print(f"oracle workspace build: {run.returncode}", flush=True)


if __name__ == "__main__":
    main()
