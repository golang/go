# Full upstream gate preparation

Status: running after the coordinated start signal. The
[execution report](upstream/report.json) and [runner](run_upstream.py) are the
authoritative record; no pass is claimed before that report is complete. Keep
the LoGOs checkout unchanged throughout the run.

## Required inputs

The installed source is commit `22ab6f7a169e905d9fde5e345db101735a321486`,
with `src` tree `8d74f82a97b8509400372ae4818525f19e7105ef`. The
[fresh-build report](build/report.json) records its installed binaries.

| Variable | Exact oracle | Verified local root | Reason |
|---|---|---|---|
| `UPROOT1272` | Official Go 1.27.2 | `/workspace/scratch/d8d410ec882d/toolchains/go1.27.2` | 186 LoGOs script files reference this ejection oracle, including hard existence and exact-version checks. |
| `UPROOT1273` | Official Go 1.27.3 | `/workspace/scratch/d8d410ec882d/toolchains/go1.27.3` | Nine LoGOs script files reference this ejection oracle. |
| `UPROOT1274` | Official Go 1.27.4 | `/workspace/scratch/d8d410ec882d/toolchains/go` | `cmd/internal/goparity` requires this exact behavior oracle; the wasm parity script also uses it. |

The Go 1.27.2 and 1.27.3 archive pins come from the committed
`.github/workflows/logos.yml` and are checked against the official download
metadata during recovery. Their authoritative verification report is outside this
evidence directory at `toolchains/recovery/oracles-verification.json`. The
original recovery report is retained beside it; the verification report also
explains and repairs an intermediate log-name collision without overwriting the
original evidence.

Available host tools include `/usr/bin/cc`, `/usr/bin/c++`, `/usr/local/bin/git`,
`/usr/bin/bash`, and `/usr/bin/perl`. The exact CI-pinned Node 26.13.1 was
recovered into `/workspace/scratch/d8d410ec882d/toolchains/node26`, and its
`--version` check returns `v26.13.1`. The official Linux x64 archive SHA-256 is
`5c063e46bab0fbc1c17cc445d7ff129cbdcd0471be6ed83b6ab864f8143bc864`; the installed
Node executable SHA-256 is
`d931c649850ffa7155b8ceffb400dc916ef325866e509cc52ae36e33e8fbb9a9`. The official
checksum file, extraction and version logs, and unchanged primary-runtime hash
are recorded in `toolchains/recovery/node26-report.json`. The primary Node
24.22.1 runtime remains unchanged. The proposed PATH prefers Node 26 and includes
the fork's `lib/wasm` so wasm tests can run. QEMU and SWIG were not found in the
inspected PATH; their guarded tests will report skips. These skips do not
establish cross-architecture execution or SWIG coverage.

Use the proven disk temporary directory `tmp-logos-vcs`, whose local shared Git
clone supplies a valid VCS context. The original workspace-parent failure and
the repaired stock/fork probes are indexed in the [README](README.md).

## Gate behavior established from source

`src/run.bash` checks for the installed `bin/go`, sets `GOENV=off`, gets the dist
environment, sets `GOPATH=/nonexist-gopath`, and invokes
`go tool dist test -rebuild "$@"`. `--no-rebuild` overrides the forced rebuild.
Without `GO_BUILDER_NAME`, `src/cmd/dist/test.go` still runs two convergence
installs and installs the command tools before testing. Record executable hashes
again afterward; the flag does not promise that installed files remain untouched.

Keep `GO_BUILDER_NAME` unset. It changes test selection, test-directory sharding,
and GOROOT permissions, and must not be fabricated to bypass convergence.
Keep the default short-mode selection: dist defaults to short tests, and adds
`-count=1` itself. It discovers `std` and `cmd`, registers compiler test-directory
tests, and adds cgo, race, API, crypto, and other platform variants. The default
short mode intentionally skips some expensive plugin/shared-library suites when
there is no builder name; the separate real plugin and FFI reports remain needed.

`src/cmd/dist/main.go` forces `maxbg=1` when `GOMAXPROCS=1`. Use that setting and
CPU affinity together: `cmd/go` script children drop the outer `GOMAXPROCS`,
`GOMEMLIMIT`, and `GOFLAGS`. The proposed timeout scale gives the full command
package enough time on a single CPU without changing which tests are selected.

## Isolated command

Both recovered oracle directories and their checksums were verified before
starting. The runner below records the full command and environment and enforces
the coordinated 1,800-second outer process-group deadline. An incomplete run is
recorded as a timeout, never as a pass. No test filter is applied.

```sh
uv run --no-project /workspace/scratch/d8d410ec882d/installed-audit/run_upstream.py
```

The underlying command and environment are:

```sh
cd /workspace/scratch/d8d410ec882d/LoGOs/src
env -u GOEXPERIMENT -u GODEBUG -u GO_BUILDER_NAME -u GO_TEST_SHORT \
  -u GO_GCFLAGS -u GO_TEST_ASMFLAGS \
  PATH=/workspace/scratch/d8d410ec882d/LoGOs/bin:/workspace/scratch/d8d410ec882d/LoGOs/lib/wasm:/workspace/scratch/d8d410ec882d/toolchains/go/bin:/workspace/scratch/d8d410ec882d/toolchains/node26/bin:/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin:/usr/local/bin:/usr/bin:/bin \
  GOROOT=/workspace/scratch/d8d410ec882d/LoGOs \
  GOTOOLCHAIN=local GOENV=off GOWORK=off \
  UPROOT1272=/workspace/scratch/d8d410ec882d/toolchains/go1.27.2 \
  UPROOT1273=/workspace/scratch/d8d410ec882d/toolchains/go1.27.3 \
  UPROOT1274=/workspace/scratch/d8d410ec882d/toolchains/go \
  CGO_ENABLED=1 CC=/usr/bin/cc CXX=/usr/bin/c++ \
  GOMAXPROCS=1 GOMEMLIMIT=512MiB GOGC=25 GOFLAGS=-p=1 \
  GOCACHE=/workspace/scratch/d8d410ec882d/cache-logos \
  GOMODCACHE=/workspace/scratch/d8d410ec882d/modcache \
  GOPROXY=https://proxy.golang.org,direct GOSUMDB=sum.golang.org \
  TMPDIR=/workspace/scratch/d8d410ec882d/tmp-logos-vcs \
  GO_TEST_SHARDS=1 GO_TEST_TIMEOUT_SCALE=12 \
  /usr/bin/taskset -c 0 bash ./run.bash --no-rebuild -k
```

`-k` keeps independent registered checks running after a failure while retaining
a failing exit status. It does not change test selection. Keep normal verified
module-download defaults available for registered tests such as historical FIPS
snapshots. Capture stdout, stderr, exit status, elapsed time, oracle identities,
resource settings, source status, and before/after installed binary hashes. Any
source change or changed executable requires explicit reconciliation with the
earlier installed evidence.
