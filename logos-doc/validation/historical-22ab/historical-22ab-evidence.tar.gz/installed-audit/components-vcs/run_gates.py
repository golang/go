#!/usr/bin/env python3
# pyright: strict
"""Record exact installed LoGOs gates without editing repository sources."""

from __future__ import annotations

import argparse
import sys
from dataclasses import asdict
from pathlib import Path

BASE = Path("/workspace/scratch/d8d410ec882d")
ROOT = BASE / "LoGOs"
BOOTSTRAP = BASE / "toolchains/go"
EXPECTED_HEAD = "22ab6f7a169e905d9fde5e345db101735a321486"
EXPECTED_SOURCE = "8d74f82a97b8509400372ae4818525f19e7105ef"
sys.path.insert(0, str(ROOT / "misc/logos-dogfood"))

from run import execute, file_hash, git, save_report  # noqa: E402

INPUTS = (
    "src/cmd/link/internal/ld/capabilities_chains_logos.go",
    "src/cmd/link/internal/ld/capabilities_logos.go",
    "src/cmd/link/internal/ld/capabilities_discovery_logos_test.go",
    "src/cmd/link/internal/ld/capabilities_testpkg_logos_test.go",
    "src/cmd/go/internal/work/logos_linkcap.go",
    "src/cmd/go/internal/work/exec.go",
    "src/cmd/go/internal/work/gc.go",
    "src/cmd/go/internal/test/logos_env.go",
    "src/cmd/go/testdata/script/logos_cap_xtest_owner.txt",
)
TOOLS = (
    "bin/go",
    "bin/logos",
    "pkg/tool/linux_amd64/compile",
    "pkg/tool/linux_amd64/link",
)


def snapshot() -> dict[str, object]:
    return {
        "head": git(ROOT, "rev-parse", "HEAD"),
        "tree": git(ROOT, "rev-parse", "HEAD^{tree}"),
        "source_tree": git(ROOT, "rev-parse", "HEAD:src"),
        "status": git(ROOT, "status", "--porcelain", "--untracked-files=all"),
        "inputs": {name: file_hash(ROOT / name) for name in INPUTS},
        "tools": {
            name: file_hash(ROOT / name) if (ROOT / name).is_file() else None
            for name in TOOLS
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("build", "components", "scripts"))
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    stage: str = args.stage
    out: Path = args.out.resolve() if args.out else BASE / "installed-audit" / stage
    out.mkdir(parents=True, exist_ok=True)
    target = out / "report.json"
    if target.exists():
        raise ValueError("report already exists; evidence must not be overwritten")
    before = snapshot()
    if before["head"] != EXPECTED_HEAD or before["source_tree"] != EXPECTED_SOURCE:
        raise ValueError("source differs from the reviewed published source")
    if before["status"]:
        raise ValueError("source checkout must be clean before validation")
    tmpdir = BASE / ("tmp-logos" if stage == "build" else "tmp-logos-vcs")
    tmpdir.mkdir(mode=0o700, parents=True, exist_ok=True)
    if stage != "build" and git(tmpdir, "rev-parse", "HEAD") != EXPECTED_HEAD:
        raise ValueError("temporary directory must use the pinned VCS context")
    cache = BASE / "cache-logos"
    cache.mkdir(parents=True, exist_ok=True)
    env = {
        "PATH": f"{ROOT / 'bin'}:{BOOTSTRAP / 'bin'}:/usr/local/bin:/usr/bin:/bin",
        "GOROOT_BOOTSTRAP": str(BOOTSTRAP),
        "GOTOOLCHAIN": "local",
        "GOENV": "off",
        "GOWORK": "off",
        "GOMAXPROCS": "2",
        "GOMEMLIMIT": "512MiB",
        "GOGC": "25",
        "GOFLAGS": "-p=1",
        "GOCACHE": str(cache),
        "GOMODCACHE": str(BASE / "modcache"),
        "GOPROXY": "off",
        "GOSUMDB": "off",
        "TMPDIR": str(tmpdir),
        "CGO_ENABLED": "1",
        "CC": "/usr/bin/cc",
        "CXX": "/usr/bin/c++",
        "UPROOT1274": str(BOOTSTRAP),
    }
    go = str(ROOT / "bin/go")
    commands: tuple[tuple[str, tuple[str, ...], float], ...]
    if stage == "build":
        env["GOBUILDTIMELOGFILE"] = str(out / "build-timing.log")
        commands = (("make", ("bash", "./make.bash"), 5400),)
    elif stage == "components":
        env["GOROOT"] = str(ROOT)
        commands = (
            ("go-version", (go, "version"), 30),
            ("logos-version", (str(ROOT / "bin/logos"), "version"), 30),
            (
                "ld",
                (go, "test", "-p=1", "-parallel=1", "-count=1", "-short",
                 "-timeout=15m", "cmd/link/internal/ld"),
                1200,
            ),
            (
                "work-race",
                (go, "test", "-p=1", "-parallel=1", "-count=1", "-short",
                 "-race", "-timeout=15m", "cmd/go/internal/work"),
                1200,
            ),
            (
                "vet",
                (go, "vet", "-p=1", "cmd/link/internal/ld", "cmd/go/internal/work"),
                900,
            ),
        )
    else:
        env["GOROOT"] = str(ROOT)
        commands = (
            (
                "capability-scripts-race",
                ("/usr/bin/taskset", "-c", "0", go, "test", "-v", "-p=1", "-parallel=1", "-count=1", "-short",
                 "-race", "-timeout=20m", "cmd/go", "-run",
                 "Script/^logos_cap_(xtest_owner|test_scope|chains|shortest_frames|inline|reloc|policy)$"),
                1500,
            ),
        )
    rows: list[dict[str, object]] = []
    report: dict[str, object] = {
        "complete": False,
        "stage": stage,
        "runner_sha256": file_hash(Path(__file__)),
        "before": before,
        "bootstrap_go_sha256": file_hash(BOOTSTRAP / "bin/go"),
        "bootstrap_compile_sha256": file_hash(BOOTSTRAP / "pkg/tool/linux_amd64/compile"),
        "bootstrap_link_sha256": file_hash(BOOTSTRAP / "pkg/tool/linux_amd64/link"),
        "environment": env,
        "temporary_context_head": git(tmpdir, "rev-parse", "HEAD") if stage != "build" else None,
        "rows": rows,
    }
    save_report(target, report)
    passed = True
    for name, command, timeout in commands:
        print(f"START {stage}/{name}", flush=True)
        run = execute(command, ROOT / "src", env, out / name, timeout)
        ok = run.returncode == 0 and not run.timed_out and not run.error
        rows.append({"name": name, "pass": ok, "run": asdict(run)})
        passed = passed and ok
        save_report(target, report)
        print(f"END {stage}/{name}: pass={ok}, seconds={run.seconds}", flush=True)
        if not ok:
            break
    after = snapshot()
    report["after"] = after
    stable = all(before[key] == after[key] for key in ("head", "tree", "source_tree", "status", "inputs"))
    report["source_stable"] = stable
    if stage != "build":
        report["tools_stable"] = before["tools"] == after["tools"]
        stable = stable and before["tools"] == after["tools"]
    report["complete"] = True
    report["pass"] = passed and stable
    save_report(target, report)
    return int(not (passed and stable))


if __name__ == "__main__":
    raise SystemExit(main())
