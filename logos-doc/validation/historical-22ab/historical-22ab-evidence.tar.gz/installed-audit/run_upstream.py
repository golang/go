#!/usr/bin/env python3
# pyright: strict
"""Record the unfiltered upstream regression gate on the frozen installation."""

from __future__ import annotations

from dataclasses import asdict
from pathlib import Path

from run_gates import BASE, EXPECTED_HEAD, EXPECTED_SOURCE, ROOT, snapshot
from run import execute, file_hash, git, save_report


def main() -> int:
    out = BASE / "installed-audit/upstream"
    out.mkdir(parents=True, exist_ok=False)
    target = out / "report.json"
    before = snapshot()
    if before["head"] != EXPECTED_HEAD or before["source_tree"] != EXPECTED_SOURCE or before["status"]:
        raise ValueError("upstream gate requires the clean frozen published source")
    temp = BASE / "tmp-logos-vcs"
    if git(temp, "rev-parse", "HEAD") != EXPECTED_HEAD:
        raise ValueError("temporary directory VCS context differs from the pinned source")
    oracle_roots = {
        "UPROOT1272": BASE / "toolchains/go1.27.2",
        "UPROOT1273": BASE / "toolchains/go1.27.3",
        "UPROOT1274": BASE / "toolchains/go",
    }
    node = BASE / "toolchains/node26/bin/node"
    env = {
        "PATH": f"{ROOT / 'bin'}:{ROOT / 'lib/wasm'}:{BASE / 'toolchains/go/bin'}:{BASE / 'toolchains/node26/bin'}:/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin:/usr/local/bin:/usr/bin:/bin",
        "GOROOT": str(ROOT),
        "GOTOOLCHAIN": "local",
        "GOENV": "off",
        "GOWORK": "off",
        "GO_BUILDER_NAME": "",
        "GO_TEST_SHORT": "",
        "GO_GCFLAGS": "",
        "GO_TEST_ASMFLAGS": "",
        "CGO_ENABLED": "1",
        "CC": "/usr/bin/cc",
        "CXX": "/usr/bin/c++",
        "GOMAXPROCS": "1",
        "GOMEMLIMIT": "512MiB",
        "GOGC": "25",
        "GOFLAGS": "-p=1",
        "GOCACHE": str(BASE / "cache-logos"),
        "GOMODCACHE": str(BASE / "modcache"),
        "GOPROXY": "https://proxy.golang.org,direct",
        "GOSUMDB": "sum.golang.org",
        "TMPDIR": str(temp),
        "GO_TEST_SHARDS": "1",
        "GO_TEST_TIMEOUT_SCALE": "12",
        **{name: str(path) for name, path in oracle_roots.items()},
    }
    command = ("/usr/bin/env", "-u", "GO_BUILDER_NAME", "-u", "GO_TEST_SHORT", "-u", "GO_GCFLAGS", "-u", "GO_TEST_ASMFLAGS", "/usr/bin/taskset", "-c", "0", "bash", "./run.bash", "--no-rebuild", "-k")
    report: dict[str, object] = {
        "complete": False,
        "scope": "full unfiltered run.bash default test selection with --no-rebuild and keep-going",
        "runner_sha256": file_hash(Path(__file__)),
        "run_bash_sha256": file_hash(ROOT / "src/run.bash"),
        "before": before,
        "oracle_driver_sha256": {name: file_hash(path / "bin/go") for name, path in oracle_roots.items()},
        "node_sha256": file_hash(node),
        "temporary_context_head": git(temp, "rev-parse", "HEAD"),
        "environment": env,
        "command": command,
        "timeout_seconds": 1800,
    }
    save_report(target, report)
    print("START full unfiltered upstream gate; outer timeout=1800s", flush=True)
    run = execute(command, ROOT / "src", env, out / "run", 1800)
    report["run"] = asdict(run)
    after = snapshot()
    report["after"] = after
    stable = all(before[key] == after[key] for key in ("head", "tree", "source_tree", "status", "inputs"))
    tools_stable = before["tools"] == after["tools"]
    report["source_stable"] = stable
    report["tools_stable"] = tools_stable
    report["complete"] = True
    report["pass"] = run.returncode == 0 and not run.timed_out and not run.error and stable and tools_stable
    report["status"] = "timeout" if run.timed_out else "pass" if report["pass"] else "failed"
    save_report(target, report)
    print(f"END full upstream gate: status={report['status']}, seconds={run.seconds}", flush=True)
    return int(not report["pass"])


if __name__ == "__main__":
    raise SystemExit(main())
