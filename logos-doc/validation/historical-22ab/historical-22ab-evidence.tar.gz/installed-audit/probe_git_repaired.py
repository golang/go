#!/usr/bin/env python3
# pyright: strict
"""Verify a pinned local clone supplies valid temporary-module VCS context."""

from __future__ import annotations

import sys
from dataclasses import asdict
from pathlib import Path

BASE = Path("/workspace/scratch/d8d410ec882d")
ROOT = BASE / "LoGOs"
TEMP = BASE / "tmp-logos-vcs"
sys.path.insert(0, str(ROOT / "misc/logos-dogfood"))

from run import decode, execute, git, obj, save_report, string  # noqa: E402


def main() -> None:
    out = BASE / "installed-audit/git-probe-repaired"
    out.mkdir(parents=True, exist_ok=False)
    work = TEMP / "verification-module"
    work.mkdir()
    (work / "go.mod").write_text("module gitprobe\n\ngo 1.27\n")
    (work / "main.go").write_text("package main\n\nfunc main() {}\n")
    previous = obj(decode((BASE / "installed-audit/components/report.json").read_text()))
    data = obj(previous["environment"])
    env = {key: string(value) for key, value in data.items()}
    env["TMPDIR"] = str(TEMP)
    env["PATH"] = f"{ROOT / 'bin'}:{BASE / 'toolchains/go/bin'}:/usr/local/bin:/usr/bin:/bin"
    rows: list[dict[str, object]] = []
    report: dict[str, object] = {
        "context_head": git(TEMP, "rev-parse", "HEAD"),
        "context_origin": git(TEMP, "remote", "get-url", "origin"),
        "context_root": git(work, "rev-parse", "--show-toplevel"),
        "rows": rows,
    }
    for name, toolroot, cache in (
        ("oracle", BASE / "toolchains/go", BASE / "cache-oracle"),
        ("candidate", ROOT, BASE / "cache-logos"),
    ):
        env["GOROOT"] = str(toolroot)
        env["GOCACHE"] = str(cache)
        command = (str(toolroot / "bin/go"), "build", "-x", "-o", str(out / f"{name}.bin"), ".")
        run = execute(command, work, env.copy(), out / name, 120)
        rows.append({"stage": name, "run": asdict(run)})
        save_report(out / "report.json", report)
        print(f"{name}: {run.returncode}", flush=True)


if __name__ == "__main__":
    main()
