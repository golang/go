#!/usr/bin/env python3
# pyright: strict
"""Seal a source and binary snapshot after dist reaches its test phase."""

from __future__ import annotations

from datetime import datetime, timezone

from run_gates import BASE, snapshot
from run import decode, file_hash, obj, save_report


def main() -> None:
    out = BASE / "installed-audit/upstream"
    target = out / "convergence.json"
    if target.exists():
        raise ValueError("convergence snapshot already exists")
    initial = obj(decode((out / "report.json").read_text()))
    before = obj(initial["before"])
    current = snapshot()
    output = (out / "run.stdout").read_bytes()
    if b"##### Testing packages." not in output:
        raise ValueError("dist has not yet reached package testing")
    retained = out / "convergence.stdout"
    retained.write_bytes(output)
    source_stable = all(before[key] == current[key] for key in ("head", "tree", "source_tree", "status", "inputs"))
    tools_stable = before["tools"] == current["tools"]
    report: dict[str, object] = {
        "observed_at": datetime.now(timezone.utc).isoformat(),
        "current": current,
        "source_stable": source_stable,
        "tools_stable": tools_stable,
        "retained_stdout": str(retained),
        "retained_stdout_sha256": file_hash(retained),
    }
    save_report(target, report)
    print(f"source_stable={source_stable}, tools_stable={tools_stable}", flush=True)
    if not source_stable or not tools_stable:
        raise ValueError("convergence changed the frozen source or installed binaries")


if __name__ == "__main__":
    main()
