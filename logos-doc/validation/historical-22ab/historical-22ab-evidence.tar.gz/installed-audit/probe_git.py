#!/usr/bin/env python3
# pyright: strict
"""Compare Git visibility for a temporary Go module without changing sources."""

from __future__ import annotations

import sys
from dataclasses import asdict
from pathlib import Path

BASE = Path("/workspace/scratch/d8d410ec882d")
ROOT = BASE / "LoGOs"
sys.path.insert(0, str(ROOT / "misc/logos-dogfood"))

from run import decode, execute, obj, save_report, string  # noqa: E402


def main() -> None:
    out = BASE / "installed-audit/git-probe"
    out.mkdir(parents=True, exist_ok=False)
    work = out / "module"
    work.mkdir()
    (work / "go.mod").write_text("module gitprobe\n\ngo 1.27\n")
    (work / "main.go").write_text("package main\n\nfunc main() {}\n")
    previous = obj(decode((BASE / "installed-audit/components/report.json").read_text()))
    data = obj(previous["environment"])
    env = {key: string(value) for key, value in data.items()}
    rows: list[dict[str, object]] = []
    for name, extra in (("native", ""), ("available", "/usr/local/bin:")):
        env["PATH"] = f"{ROOT / 'bin'}:{BASE / 'toolchains/go/bin'}:{extra}/usr/bin:/bin"
        for operation, command in (
            ("git-version", ("git", "--version")),
            ("git-root", ("git", "rev-parse", "--show-toplevel")),
            ("build", (str(ROOT / "bin/go"), "build", "-x", "-o", str(out / f"{name}.bin"), ".")),
        ):
            run = execute(command, work, env.copy(), out / f"{name}-{operation}", 120)
            rows.append({"variant": name, "operation": operation, "run": asdict(run)})
            save_report(out / "report.json", {"rows": rows})
            print(f"{name}/{operation}: {run.returncode}", flush=True)


if __name__ == "__main__":
    main()
