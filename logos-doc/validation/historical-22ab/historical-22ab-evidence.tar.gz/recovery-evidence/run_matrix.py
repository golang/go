#!/usr/bin/env python3
# pyright: strict
"""Replay the pinned native corpus and seal installation identities."""

from __future__ import annotations

import argparse
import sys
from dataclasses import asdict
from pathlib import Path

BASE = Path("/workspace/scratch/d8d410ec882d")
sys.path.insert(0, str(BASE / "installed-audit"))
from run_gates import EXPECTED_HEAD, EXPECTED_SOURCE, ROOT, snapshot  # noqa: E402
from run import execute, file_hash, git, save_report  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("profile", choices=("default", "permissions", "link-permissions"))
    args = parser.parse_args()
    profile: str = args.profile
    name = "corpus.json" if profile == "default" else f"corpus-{profile}.json"
    manifest = ROOT / "misc/logos-dogfood" / name
    out = BASE / "corpus-vcs" / f"native-{profile}"
    out.mkdir(parents=True, exist_ok=False)
    before = snapshot()
    if before["head"] != EXPECTED_HEAD or before["source_tree"] != EXPECTED_SOURCE or before["status"]:
        raise ValueError("matrix requires the clean frozen source")
    temp = BASE / "corpus-vcs/tmp"
    if git(temp, "rev-parse", "HEAD") != EXPECTED_HEAD:
        raise ValueError("temporary VCS context differs from the frozen source")
    environment = {
        "PATH": f"{BASE / 'toolchains/go/bin'}:/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin:/usr/local/bin:/usr/bin:/bin",
        "GOMAXPROCS": "1",
        "GOMEMLIMIT": "512MiB",
        "GOGC": "25",
        "GOTOOLCHAIN": "local",
        "GOENV": "off",
        "GOWORK": "off",
        "GOPROXY": "off",
        "GOSUMDB": "off",
        "TMPDIR": str(temp),
        "CC": "/usr/bin/cc",
        "CXX": "/usr/bin/c++",
    }
    command = (
        sys.executable, str(ROOT / "misc/logos-dogfood/run.py"),
        "--manifest", str(manifest),
        "--go-oracle", str(BASE / "toolchains/go/bin/go"),
        "--go-candidate", str(ROOT / "bin/go"),
        "--logos", str(ROOT / "bin/logos"),
        "--source-root", str(BASE / "corpus-sources"),
        "--module-cache", str(BASE / "modcache"),
        "--cache-root", str(BASE / "corpus-cache"),
        "--out", str(out), "--operation", "build", "--jobs", "1", "--timeout", "300",
    )
    context: dict[str, object] = {
        "complete": False, "profile": profile, "scope": "compile and native lint; upstream runtime tests are separate",
        "before": before, "launcher_environment": environment, "command": command,
        "wrapper_sha256": file_hash(Path(__file__)), "manifest_sha256": file_hash(manifest),
    }
    save_report(out / "context.json", context)
    print(f"START {profile} native matrix", flush=True)
    run = execute(command, ROOT, environment, out / "launcher", 7200)
    context["launcher"] = asdict(run)
    after = snapshot()
    context["after"] = after
    context["source_stable"] = all(before[key] == after[key] for key in ("head", "tree", "source_tree", "status", "inputs"))
    context["tools_stable"] = before["tools"] == after["tools"]
    context["complete"] = True
    save_report(out / "context.json", context)
    print(f"END {profile}: exit={run.returncode}; source stable={context['source_stable']}; tools stable={context['tools_stable']}", flush=True)
    return int(run.returncode != 0 or run.timed_out or bool(run.error) or not context["source_stable"] or not context["tools_stable"])


if __name__ == "__main__":
    raise SystemExit(main())
