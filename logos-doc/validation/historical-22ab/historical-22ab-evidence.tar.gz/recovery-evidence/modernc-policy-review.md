# Reviewed modernc runtime permissions

The pinned modernc SQLite source is GitLab commit
`92d72a45bcb65ab33bbe79c8667f2b8b529ae902`. The runtime comparisons use that
unchanged source with cgo disabled. A policy is copied only into the private
LoGOs work copy. Stock Go and the fork's Go driver receive pristine input.

## Successive policies

1. The default-policy replay denied the native build before tests started.
2. The existing unsafe-only policy, SHA-256
   `5b2a173a8d779e0a92587042884eddaa3a5c30a3ae11a1b913beb53cac4f6c12`,
   reached the linker and produced 21 capability denials. The complete inventory
   is in `modernc-link-denials.json`. No test execution is counted for this run.
3. A separate policy added execution and network grants for
   `golang.org/x/sys/unix` and `modernc.org/libc`. Its SHA-256 is
   `6bf8dd49574dc2340f9c30cd37e7fcd70f1fb90d7743f89df14ef0217a1c2f60`.
   That replay exposed three remaining execution denials in the test binary's
   `modernc.org/fileutil/ccgo` dependency. No test execution is counted.
4. The final separate test policy adds execution permission for that exact
   helper package. Its SHA-256 is
   `5666c90bc1f25d5f0d7d0e5b53e80c2fa8e7ebe341286f7d7b0b1c5651513096`.
   The unchanged `TestMutexWakeOnce` then ran and passed under LoGOs, matching
   the already passing stock-Go and fork-Go controls. The additional SQL replay
   uses the same policy and records its own commands and executed test events.

Every earlier policy and denial remains separate evidence. The final policy
retains the original six unsafe package grants and changes no severity, lint
setting, compiler option, or capability classification.

## Why the additional grants are required

SPEC section 11.1 treats a raw syscall entry as both an execution and a network
sink. Its caller can select the trap number, so permission for both capabilities
is required even when a reviewed wrapper uses a memory-related syscall. For
example, the pinned `golang.org/x/sys@v0.49.0/unix/zsyscall_linux.go` implements
`mremap` with `Syscall6(SYS_MREMAP, ...)`. The observed linker reports identify
`golang.org/x/sys/unix` and `modernc.org/libc` as direct dependency callers of
the protected entries. The test policy authorizes exactly those package paths.

The test binary also imports `modernc.org/fileutil/ccgo`. The pinned
`modernc.org/fileutil@v1.4.0/ccgo/util.go` defines `Shell`, which resolves a
command with `exec.LookPath`, constructs it with `exec.CommandContext`, and runs
it. Its module checksum is
`h1:j6ZzNTftVS054gi281TyLjHPp6CPHr2KCxEXjEbD6SM=`. The execution grant applies
to that package, including helper commands beyond the selected tests. It is an
explicit permission for this reviewed replay, not a claim that the package has
no process-launch capability or that every version is trusted.

## Runtime assertions

The extra SQL comparison selects unchanged upstream tests for named parameters,
an in-memory database larger than the old fixed heap, direct and prepared
parameter binding, transaction modes in delete and WAL journals, multi-statement
string lifetime, complete INSERT/UPDATE/DELETE RETURNING behavior, and the
two-contender mutex wake invariant. Its event checker requires all seven named
top-level tests and eight named subtests to run and pass, with no skipped or
failed test events. A successful compile alone cannot satisfy that check.

All results remain specific to the recorded Linux/amd64 host, source, policy,
toolchain hashes, invocation flags, and resource profile.
