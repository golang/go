#!/usr/bin/env python3
# pyright: strict
"""Compare unchanged pinned SQLite SQL tests under three installed drivers."""

from __future__ import annotations

import shutil
import sys
from dataclasses import asdict
from pathlib import Path
from typing import cast

BASE = Path("/workspace/scratch/d8d410ec882d")
ROOT = BASE / "LoGOs"
RUNNER = ROOT / "misc/logos-dogfood"
sys.path.insert(0, str(BASE / "installed-audit"))
sys.path.insert(0, str(RUNNER / "evidence/2026-11-16/runtime"))
from run_gates import EXPECTED_HEAD, EXPECTED_SOURCE, snapshot  # noqa: E402
from replay import test_events  # noqa: E402
from run import (  # noqa: E402
    Case, all_files, assess_build, copy_source, decode, environment, execute,
    file_hash, save_report, toolchain_identity, tree_hash, verify_source,
)

TESTS = (
    "TestNamedParameters", "TestMemDB", "TestBinding", "TestBeginMode",
    "TestMultiStmtQueryStringRoundtrip", "TestExecReturningMultiRow", "TestMutexWakeOnce",
)
EXPECTED = TESTS + ("TestBinding/DB", "TestBinding/Prepare") + tuple(
    f"TestBeginMode/{journal}/{mode}"
    for mode in ("deferred", "immediate", "exclusive")
    for journal in ("delete", "wal")
)
POLICY_SHA256 = "5666c90bc1f25d5f0d7d0e5b53e80c2fa8e7ebe341286f7d7b0b1c5651513096"


def main() -> int:
    out = BASE / "corpus-vcs/runtime/modernc-sql"
    out.mkdir(parents=True, exist_ok=False)
    before = snapshot()
    if before["head"] != EXPECTED_HEAD or before["source_tree"] != EXPECTED_SOURCE or before["status"]:
        raise ValueError("runtime comparison requires the clean frozen source")
    raw = decode((RUNNER / "corpus.json").read_text())
    if not isinstance(raw, list):
        raise TypeError("manifest must be an array")
    cases = tuple(Case.parse(item) for item in cast(list[object], raw))
    case = next(case for case in cases if case.id == "modernc-sqlite")
    source = verify_source(case, BASE / "corpus-sources", BASE / "modcache", RUNNER)
    policy = BASE / "recovery-evidence/modernc-link-tests-reviewed.toml"
    if file_hash(policy) != POLICY_SHA256:
        raise ValueError("reviewed policy differs from its recorded bytes")
    shutil.copyfile(policy, out / "policy.toml")
    tools = {
        "oracle": BASE / "toolchains/go/bin/go",
        "go": ROOT / "bin/go",
        "logos": ROOT / "bin/logos",
    }
    rows: list[dict[str, object]] = []
    report: dict[str, object] = {
        "complete": False, "before": before, "case": asdict(case),
        "source_digest": source.digest, "policy_sha256": POLICY_SHA256,
        "tests": TESTS, "expected_events": EXPECTED,
        "runner_sha256": file_hash(Path(__file__)),
        "corpus_runner_sha256": file_hash(RUNNER / "run.py"),
        "event_checker_sha256": file_hash(RUNNER / "evidence/2026-11-16/runtime/replay.py"),
        "rows": rows,
    }
    target = out / "report.json"
    save_report(target, report)
    baseline = None
    for name, binary in tools.items():
        env = environment(case, binary, BASE / "modcache", BASE / "corpus-cache" / name, 1)
        env.update(GOMEMLIMIT="512MiB", GOGC="25", TMPDIR=str(BASE / "corpus-vcs/tmp"), CC="/usr/bin/cc", CXX="/usr/bin/c++")
        identity = toolchain_identity(binary, env, RUNNER, out / "tools" / name)
        work = out / "work"
        copy_source(source, work)
        try:
            if name == "logos":
                destination = work / "logos.toml"
                if destination.exists():
                    raise ValueError("refuse to replace source-provided policy")
                shutil.copyfile(policy, destination)
            effective = tree_hash(work, all_files(work))
            command = (str(binary), "test", "-json", "-count=1", "-short", "-timeout=120s", "-run", "^(" + "|".join(TESTS) + ")$", ".")
            print(f"START modernc SQL {name}", flush=True)
            run = execute(command, work, env, out / name, 600)
            assessment = assess_build(run, name, baseline)
            if name == "oracle":
                baseline = assessment
            events = test_events(run, EXPECTED)
            passed = assessment.status == "pass" and events["exact_match"] is True
            rows.append({
                "driver": name, "driver_sha256": file_hash(binary), "toolchain": identity,
                "effective_input_digest": effective, "run": asdict(run),
                "assessment": asdict(assessment), "events": events,
                "status": "pass" if passed else "failed",
            })
            save_report(target, report)
            print(f"END modernc SQL {name}: {'pass' if passed else 'failed'}", flush=True)
        finally:
            shutil.rmtree(work)
    after = snapshot()
    report["after"] = after
    report["source_stable"] = all(before[key] == after[key] for key in ("head", "tree", "source_tree", "status", "inputs"))
    report["tools_stable"] = before["tools"] == after["tools"]
    report["complete"] = True
    save_report(target, report)
    return int(any(row["status"] != "pass" for row in rows) or not report["source_stable"] or not report["tools_stable"])


if __name__ == "__main__":
    raise SystemExit(main())
