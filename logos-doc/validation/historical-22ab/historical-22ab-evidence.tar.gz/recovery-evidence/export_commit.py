#!/usr/bin/env python3
# pyright: strict
"""Export one local commit for Git-data publication with an exact tree check.

Preconditions: the commit and its first parent exist; changed entries are blobs.
Postcondition: the payload describes every changed path without rename folding.
Binary blobs are identified separately and must be created before their tree.
"""

from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


def git(repo: Path, *arguments: str) -> bytes:
    return subprocess.check_output(("git", *arguments), cwd=repo)


def revision(repo: Path, expression: str) -> str:
    return git(repo, "rev-parse", "--verify", expression).decode().strip()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path)
    parser.add_argument("commit")
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    repo: Path = args.repo.resolve()
    commit: str = revision(repo, args.commit)
    out: Path = args.out.resolve()
    if out.exists():
        raise FileExistsError(out)
    parents = git(repo, "show", "-s", "--format=%P", commit).decode().strip().split()
    if not parents:
        raise ValueError("publication requires an existing parent")
    elements: list[dict[str, object]] = []
    binaries: list[dict[str, object]] = []
    paths = git(repo, "diff-tree", "--no-commit-id", "--no-renames", "-r", "--name-only", "-z", parents[0], commit)
    for raw_path in paths.split(b"\0"):
        if not raw_path:
            continue
        path = raw_path.decode("utf-8")
        raw_entry = git(repo, "ls-tree", "-z", commit, "--", path)
        if not raw_entry:
            elements.append({"path": path, "mode": "100644", "type": "blob", "sha": None})
            continue
        metadata, separator, entry_path = raw_entry.rstrip(b"\0").partition(b"\t")
        if not separator or entry_path != raw_path:
            raise ValueError(f"unexpected tree entry for {path}")
        mode, kind, oid = metadata.decode().split()
        if kind != "blob":
            raise ValueError(f"unsupported entry kind {kind}: {path}")
        data = git(repo, "cat-file", "blob", oid)
        element: dict[str, object] = {"path": path, "mode": mode, "type": kind}
        try:
            content = data.decode("utf-8")
            if "\0" in content:
                raise ValueError("NUL-containing blob")
        except (UnicodeDecodeError, ValueError):
            element["sha"] = oid
            binaries.append({"path": path, "sha": oid, "bytes": len(data)})
        else:
            element["content"] = content
        elements.append(element)
    result: dict[str, object] = {
        "commit": commit,
        "parents": parents,
        "base_tree": revision(repo, f"{parents[0]}^{{tree}}"),
        "tree": revision(repo, f"{commit}^{{tree}}"),
        "message": git(repo, "show", "-s", "--format=%B", commit).decode().rstrip(),
        "elements": elements,
        "binaries": binaries,
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, separators=(",", ":")) + "\n")
    print(f"{out}: {out.stat().st_size} bytes, {len(elements)} paths, {len(binaries)} binary blobs")


if __name__ == "__main__":
    main()
